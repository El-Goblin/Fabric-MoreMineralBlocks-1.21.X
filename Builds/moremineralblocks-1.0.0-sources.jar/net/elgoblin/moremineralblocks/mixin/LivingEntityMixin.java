package net.elgoblin.moremineralblocks.mixin;

import net.elgoblin.moremineralblocks.util.KillerToolSaver;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public class LivingEntityMixin {

    @Inject(method = "dropLoot", at = @At("HEAD"))
    private void captureTool(class_3218 world, class_1282 damageSource, boolean causedByPlayer, CallbackInfo ci) {
        if (damageSource.method_5529() instanceof class_1309 killer) {
            ((KillerToolSaver) this).setKillerTool(killer.method_6047());
        }
    }

    @Inject(method = "dropLoot", at = @At("TAIL"))
    private void clearTool(class_3218 world, class_1282 damageSource, boolean causedByPlayer, CallbackInfo ci) {
        ((KillerToolSaver) this).setKillerTool(class_1799.field_8037);
    }
}
