package net.elgoblin.moremineralblocks.mixin;

import net.elgoblin.moremineralblocks.client.ClientEvents;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
public class MouseMixin {

    @Shadow
    @Final
    private class_310 client;

    @Inject(
            method = "onMouseScroll",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        double delta = (this.client.field_1690.method_42439().method_41753() ? Math.signum(vertical) : vertical)
                * this.client.field_1690.method_41806().method_41753();

        if (ClientEvents.onScroll(delta)) ci.cancel();
    }
}