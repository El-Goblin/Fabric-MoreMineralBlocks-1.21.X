package net.elgoblin.moremineralblocks.mixin;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1927;
import net.minecraft.class_2338;


@Mixin(class_1927.class)
public class ExplosionMixin {

    @Shadow
    private net.minecraft.class_1937 world; // shadow the private field

    @Shadow
    private ObjectArrayList<class_2338> affectedBlocks; // shadow the private field

//    @Inject(
//            method = "collectBlocksAndDamageEntities",
//            at = @At("TAIL")
//    )
//    private void protectBlocksFromExplosion(CallbackInfo ci) {
//        if (!(world instanceof ServerWorld serverWorld)) return;
//
//        ProtectorManager manager = ProtectorManager.getProtectorManager(serverWorld.getServer());
//        affectedBlocks.removeIf(manager::isProtected);
//    }
}