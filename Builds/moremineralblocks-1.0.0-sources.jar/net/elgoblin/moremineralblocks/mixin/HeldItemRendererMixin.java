package net.elgoblin.moremineralblocks.mixin;

import net.elgoblin.moremineralblocks.client.InfiniteItemClientCache;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.minecraft.class_1799;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;


@Mixin(class_759.class)
public class HeldItemRendererMixin {

    @ModifyArg(
            method = "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/command/render/OrderedRenderCommandQueue;I)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/item/ItemModelManager;clearAndUpdate(Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/world/World;Lnet/minecraft/client/render/item/HeldItemContext;I)V"
            ),
            index = 1
    )
    private class_1799 replaceRenderedStack(class_1799 original) {
        if (original.method_31574(ModItems.DIMENSIONAL_POCKET)) {
            class_1799 replacement = InfiniteItemClientCache.mainStack;

            if (replacement != null && !replacement.method_7960()) {
                return replacement;
            }
        }

        return original;
    }
}