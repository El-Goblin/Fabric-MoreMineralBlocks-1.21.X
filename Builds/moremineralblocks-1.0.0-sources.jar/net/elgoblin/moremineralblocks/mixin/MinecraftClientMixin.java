package net.elgoblin.moremineralblocks.mixin;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.elgoblin.moremineralblocks.networking.DimensionPocketMiddleClickQueryPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftClientMixin {

    @Shadow
    public class_746 player;
    @Shadow public class_239 crosshairTarget;
    @Shadow public class_638 world;

    @Inject(method = "doItemPick", at = @At("HEAD"), cancellable = true)
    private void onDoItemPick(CallbackInfo ci) {
        if (this.player == null || this.crosshairTarget == null) {
            return;
        }

        if (this.crosshairTarget.method_17783() != class_239.class_240.field_1332) {return;}

        class_3965 blockHit = (class_3965) this.crosshairTarget;
        class_2680 state = this.world.method_8320(blockHit.method_17777());
        class_2248 block = state.method_26204();

        class_1799 selectedItem = player.method_5998(class_1268.field_5808);
        if (!selectedItem.method_31574(ModItems.DIMENSION_POCKET)) {
            selectedItem = player.method_5998(class_1268.field_5810);
        }
        if (!selectedItem.method_31574(ModItems.DIMENSION_POCKET)) {
            return;
        }

        ClientPlayNetworking.send(new DimensionPocketMiddleClickQueryPayload(selectedItem, block));
        ci.cancel();
    }
}