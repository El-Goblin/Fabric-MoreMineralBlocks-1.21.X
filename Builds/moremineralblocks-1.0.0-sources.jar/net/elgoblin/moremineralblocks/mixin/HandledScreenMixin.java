package net.elgoblin.moremineralblocks.mixin;

import net.elgoblin.moremineralblocks.client.InlineColorPanel;
import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.minecraft.class_11909;
import net.minecraft.class_1258;
import net.minecraft.class_1263;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1733;
import net.minecraft.class_1735;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Comparator;
import java.util.List;


@Mixin(class_465.class)
public class HandledScreenMixin {

    @Shadow protected class_1735 focusedSlot;
    @Shadow protected int x;
    @Shadow protected int y;
    @Shadow protected int backgroundWidth;
    @Shadow protected int backgroundHeight;

    @Unique
    private InlineColorPanel activeColorPanel = null;
    @Unique
    private class_1799 infiniteItemStack;

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void handleOverlayClicks(class_11909 click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {

        if (activeColorPanel != null && activeColorPanel.active) {

            // Click en el panel, lo mantengo como esta
            if (activeColorPanel.checkClick(click.comp_4798(), click.comp_4799())) {
                cir.setReturnValue(true);
                cir.cancel();
                return;
            }

            // Click en slot de inventario con el panel abierto.
            if (click.method_74245() == 0 && this.focusedSlot != null) {
                class_1703 handler = ((class_465<?>) (Object) this).method_17577();

                if (isContainerSlot(handler, this.focusedSlot)) {
                    int clickedSlotId = this.focusedSlot.field_7874;

                    this.activeColorPanel.toggleSlotAssignment(clickedSlotId);

                    cir.setReturnValue(true);
                    cir.cancel();
                    return;
                }
            }
        }

        if (click.method_74245() == 0 && this.focusedSlot != null && this.focusedSlot.method_7681()) {
            if (this.focusedSlot.method_7677().method_31574(ModItems.DIMENSIONAL_POCKET)) {

                class_1799 infiniteItem = this.focusedSlot.method_7677();

                infiniteItemStack = infiniteItem;

                class_2338 storagePosition = infiniteItem.method_58694(ModDataComponentTypes.LINKED_CHEST);
                class_2960 dimension = infiniteItem.method_58694(ModDataComponentTypes.SERVERWORLD);

                if (dimension != null && storagePosition != null) {
                    class_1703 handler = ((class_465<?>) (Object) this).method_17577();

                    if (handler instanceof class_1707 || handler instanceof class_1733) {

                        class_310 client = class_310.method_1551();

                        if (client.field_1765 instanceof class_3965 blockHitResult) {
                            class_2338 crosshairPos = blockHitResult.method_17777();
                            class_1937 world = client.field_1687;

                            if (world != null && world.method_27983().method_29177().equals(dimension)) {
                                class_2680 blockState = world.method_8320(crosshairPos);

                                if (blockState.method_26204() instanceof class_2281 chestBlock) {
                                    class_1263 clickedInventory = class_2281.method_17458(chestBlock, blockState, world, crosshairPos, true);
                                    if (clickedInventory instanceof class_1258 doubleChest) {
                                        if (world.method_8321(storagePosition) instanceof class_1263 linkedInventory) {
                                            if (!doubleChest.method_5405(linkedInventory)) {return;} //Es un cofre doble no vinculado
                                        }
                                    }
                                    else {
                                        if (!crosshairPos.equals(storagePosition)) {return;} // Es un cofre simple no vinculado
                                    }
                                }
                                else {
                                    if (!crosshairPos.equals(storagePosition)) {return;} // Es algo no vinculado
                                }
                                int panelX = this.x + this.backgroundWidth + 10;
                                int panelY = (int) (this.y + this.backgroundHeight * 0.66);

                                int currentItemColor = this.focusedSlot.method_7677().method_58695(ModDataComponentTypes.SELECTED_COLOR, 0);

                                this.activeColorPanel = new InlineColorPanel(panelX, panelY, this.focusedSlot.field_7874, currentItemColor);

                                cir.setReturnValue(true);
                                cir.cancel();
                            }
                        }
                    }
                }
            }
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void renderInlineOverlay(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (activeColorPanel != null && activeColorPanel.active) {
            activeColorPanel.render(context, mouseX, mouseY);
        }
    }

    @Inject(method = "drawSlot", at = @At("HEAD"))
    private void drawAssignedSlotColor(class_332 context, class_1735 slot, int x, int y, CallbackInfo ci) {
        if (this.activeColorPanel != null && this.activeColorPanel.active) {
            class_1703 handler = ((class_465<?>) (Object) this).method_17577();

            if (isContainerSlot(handler, slot)) {
                int selectedColorIndex = this.activeColorPanel.getSelectedColorIndex();

                if (this.activeColorPanel.isSlotAssignedToColor(slot.field_7874, selectedColorIndex)) {
                    int rawColor = this.activeColorPanel.getColorHex(selectedColorIndex);

                    int tintColor = (rawColor & 0x00FFFFFF) | 0xAA000000;
                    if (selectedColorIndex == 8) {tintColor = 0x80FFFFFF;}
                    context.method_25294(slot.field_7873, slot.field_7872, slot.field_7873 + 16, slot.field_7872 + 16, tintColor);
                }
            }
        }
    }

    @Inject(method = "removed", at = @At("HEAD"))
    private void onScreenClose(CallbackInfo ci) {
        if (this.activeColorPanel != null && this.activeColorPanel.active) {
            for (int i = 0 ; i < 16 ; i++) {
                List<Integer> group = infiniteItemStack.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(i)));
                if (group != null) {group.sort(Comparator.naturalOrder());}
            }
        }
    }

    @Unique
    private boolean isContainerSlot(class_1703 handler, class_1735 slot) {
        if (slot == null || slot.field_7871 == null) return false;

        if (slot.field_7871 instanceof net.minecraft.class_1661) {
            return false;
        }

        return handler instanceof class_1733 || handler instanceof class_1707;
    }
}