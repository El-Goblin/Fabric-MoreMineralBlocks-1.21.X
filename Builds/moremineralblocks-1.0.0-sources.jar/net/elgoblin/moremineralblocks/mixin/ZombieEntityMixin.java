package net.elgoblin.moremineralblocks.mixin;

import net.elgoblin.moremineralblocks.item.ModItems;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1642;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1642.class)
public class ZombieEntityMixin extends class_1588 {

    protected ZombieEntityMixin(class_1299<? extends class_1588> entityType, class_1937 world) {
        super(entityType, world);
    }

    @ModifyArg(method = "initEquipment",
    at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/ZombieEntity;equipStack(Lnet/minecraft/entity/EquipmentSlot;Lnet/minecraft/item/ItemStack;)V"),
    index = 1)
    private class_1799 replaceSwordForFlameberge(class_1799 originalEquipment) {
//        return new ItemStack(ModItems.FLAMEBERGE_LONGSWORD);
        if ((originalEquipment.method_7909() == class_1802.field_8699) && field_5974.method_43048(2)==0) {
            return new class_1799(ModItems.FLAMEBERGE_LONGSWORD);
        }
        else {
            return originalEquipment;
        }
    }
}
