package net.elgoblin.moremineralblocks.mixin;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.enchantment.ModEnchantments;
import net.elgoblin.moremineralblocks.util.ModTags;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;

@Mixin(class_2248.class)
public abstract class BlockMixin {

    private static final int[][] AVAILABLE_SLOTS_CACHE = new int[54][];

    @Inject(at = @At("RETURN"), method = "getDroppedStacks(Lnet/minecraft/block/BlockState;Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/entity/BlockEntity;Lnet/minecraft/entity/Entity;Lnet/minecraft/item/ItemStack;)Ljava/util/List;", cancellable = true)
    private static void carryDropsToLinkedChest(
            class_2680 state,
            class_3218 world,
            class_2338 pos,
            @Nullable class_2586 blockEntity,
            @Nullable class_1297 entity,
            class_1799 tool,
            CallbackInfoReturnable<List<class_1799>> cir) {

        if (!tool.method_7960() && tool.method_31573(ModTags.Items.LEGENDARY_TOOLS) && ModEnchantments.getLevel(tool, ModEnchantments.LINKER) > 0) {

            class_2338 storagePos = tool.method_58694(ModDataComponentTypes.LINKED_CHEST);
            class_2960 dimension = tool.method_58694(ModDataComponentTypes.SERVERWORLD);
            MinecraftServer server = world.method_8503();

            if (storagePos == null || dimension == null || server == null) {return;}

            class_3218 targetWorld = server.method_3847(class_5321.method_29179(class_7924.field_41223, dimension));
            if (targetWorld == null || !targetWorld.method_8477(storagePos)) {return;}

            class_2680 blockAtLinkedPosition = targetWorld.method_8320(storagePos);
            class_2248 inventoryBlock = blockAtLinkedPosition.method_26204();
            class_1263 deposit = null;

            if (inventoryBlock instanceof class_2281 chest) {
                deposit = class_2281.method_17458(chest, blockAtLinkedPosition, targetWorld, storagePos, true);
            }
            if (deposit == null && targetWorld.method_8321(storagePos) instanceof class_1263 otherInventory) {
                deposit = otherInventory;
            }
            if (deposit == null) {return;}

            List<class_1799> toDropAsUsual = new ArrayList<>();

            for (class_1799 drop : cir.getReturnValue()) {
                int remainder = insert(deposit, drop);

                if (remainder > 0) {
                    toDropAsUsual.add(drop);
                }
            }
            deposit.method_5431();
            cir.setReturnValue(toDropAsUsual);
        }
    }

    private static int insert(class_1263 to, class_1799 stack) {
        int invSize = to.method_5439();
        int firstEmptySpot = -1;

        for (int i = 0; i < invSize; i++) {
            class_1799 currentStack = to.method_5438(i);
            if (firstEmptySpot == -1 && currentStack.method_7960()) {
                firstEmptySpot = i;
            }
            if (canMergeItems(currentStack, stack)){
                stack = transfer(to, stack, i);
            }
        }
        if (stack.method_7960()) {
            return 0;
        }
        if (firstEmptySpot != -1) {
            stack = transfer(to, stack, firstEmptySpot);
        }
        return stack.method_7947();
    }

    private static class_1799 transfer(class_1263 deposit, class_1799 stack, int slot) {
        class_1799 receivingItemStack = deposit.method_5438(slot);
        if (canInsert(deposit, stack, slot)) {
            if (receivingItemStack.method_7960()) {
                deposit.method_5447(slot, stack);
                stack = class_1799.field_8037;
            }
            else if (canMergeItems(receivingItemStack, stack)) {
                int i = stack.method_7914() - receivingItemStack.method_7947();
                int j = Math.min(stack.method_7947(), i);
                stack.method_7934(j);
                receivingItemStack.method_7933(j);
            }
        }

        return stack;
    }

    private static boolean canInsert(class_1263 inventory, class_1799 stack, int slot) {
        return inventory.method_5437(slot, stack);
    }

    private static boolean canMergeItems(class_1799 first, class_1799 second) {
        return first.method_7947() <= first.method_7914() && class_1799.method_31577(first, second);
    }
}
