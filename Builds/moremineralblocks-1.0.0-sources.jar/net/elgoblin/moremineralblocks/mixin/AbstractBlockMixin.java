package net.elgoblin.moremineralblocks.mixin;

import net.elgoblin.moremineralblocks.util.ProtectorManager;
import net.minecraft.class_1799;
import net.minecraft.class_1927;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4970;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.BiConsumer;


@Mixin(class_4970.class)
public class AbstractBlockMixin {

    @Inject(
            method = "onExploded",
            at = @At("HEAD"),
            cancellable = true
    )
    private void protectBlocksFromExplosion(class_2680 state, class_3218 world, class_2338 pos, class_1927 explosion, BiConsumer<class_1799, class_2338> stackMerger, CallbackInfo ci) {
        MinecraftServer server = world.method_8503();
        if (server != null) {
            ProtectorManager manager = ProtectorManager.getProtectorManager(server);
            if (manager.isProtected(pos)) {
                ci.cancel();
            }
        }
    }
}