package net.elgoblin.moremineralblocks.mixin;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.enchantment.ModEnchantments;
import net.elgoblin.moremineralblocks.util.KillerToolSaver;
import net.elgoblin.moremineralblocks.util.ModTags;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2595;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(class_1297.class)
public abstract class EntityMixin implements KillerToolSaver {

    private class_1799 killerTool = class_1799.field_8037;
    private static final int[][] AVAILABLE_SLOTS_CACHE = new int[54][];


    @Override
    public void setKillerTool(class_1799 stack) {
        this.killerTool = stack;
    }

    @Override
    public class_1799 getKillerTool() {
        return this.killerTool;
    }

    @Inject(at = @At("RETURN"), method = "dropStack(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/entity/ItemEntity;", cancellable = true)
    private void carryDropsToLinkedChest(
            class_3218 world,
            class_1799 stack,
            class_243 yOffset,
            CallbackInfoReturnable<List<class_1799>> cir) {

        if (!world.method_8608()) {
            if (!((Object)this instanceof class_1309 self)) {
                return;
            }

            class_1799 tool = this.getKillerTool();

            if (!tool.method_7960() && tool.method_31573(ModTags.Items.LEGENDARY_TOOLS) && ModEnchantments.getLevel(tool, ModEnchantments.LINKER) > 0) {
                class_2338 storagePos = tool.method_58694(ModDataComponentTypes.LINKED_CHEST);

                if (storagePos != null && world.method_22340(storagePos) && world.method_8321(storagePos) instanceof class_1263 deposit) {
                    class_2248 blockAtLinkedPosition = world.method_8320(storagePos).method_26204();

                    if (deposit instanceof class_2595 && blockAtLinkedPosition instanceof class_2281) {
                        deposit = class_2281.method_17458((class_2281) blockAtLinkedPosition,
                                world.method_8320(storagePos), world, storagePos, true
                        );
                    }

                    if (deposit != null) {
                        int remainder = insert(deposit, stack);

                        deposit.method_5431();

                        if (remainder == 0) {
                            cir.setReturnValue(null);
                        }
                    }
                }
            }
        }
    }

    private static int insert(class_1263 deposit, class_1799 drop) {
        if (deposit == null) {
            return drop.method_7947();
        }
        else {
            if (isInventoryFull(deposit)) {
                return drop.method_7947();
            }
            else {
                class_1799 remainder = transfer(deposit, drop);
                if (remainder.method_7960()) {
                    return 0;
                }

                return drop.method_7947();
            }
        }
    }

    private static boolean isInventoryFull(class_1263 inventory) {
        int[] is = getAvailableSlots(inventory);

        for (int i : is) {
            class_1799 itemStack = inventory.method_5438(i);
            if (itemStack.method_7947() < itemStack.method_7914()) {
                return false;
            }
        }

        return true;
    }

    private static int[] getAvailableSlots(class_1263 inventory) {
        int i = inventory.method_5439();
        if (i < AVAILABLE_SLOTS_CACHE.length) {
            int[] is = AVAILABLE_SLOTS_CACHE[i];
            if (is != null) {
                return is;
            } else {
                int[] js = indexArray(i);
                AVAILABLE_SLOTS_CACHE[i] = js;
                return js;
            }
        } else {
            return indexArray(i);
        }
    }

    private static int[] indexArray(int size) {
        int[] is = new int[size];
        int i = 0;

        while (i < is.length) {
            is[i] = i++;
        }

        return is;
    }

    private static class_1799 transfer(class_1263 to, class_1799 stack) {
        int j = to.method_5439();

        for (int i = 0; i < j && !stack.method_7960(); i++) {
            stack = transfer2(to, stack, i);
        }
        return stack;
    }

    private static class_1799 transfer2(class_1263 deposit, class_1799 stack, int slot) {
        class_1799 receivingItemStack = deposit.method_5438(slot);
        if (canInsert(deposit, stack, slot)) {
            if (receivingItemStack.method_7960()) {
                deposit.method_5447(slot, stack.method_7972());
                stack.method_7939(0);
                stack = class_1799.field_8037;
            }
            else if (canMergeItems(receivingItemStack, stack)) {
                int i = stack.method_7914() - receivingItemStack.method_7947();
                int j = Math.min(stack.method_7947(), i);
                stack.method_7934(j);
                receivingItemStack.method_7933(j);
            }
        }

        return stack;
    }

    private static boolean canInsert(class_1263 inventory, class_1799 stack, int slot) {
        return inventory.method_5437(slot, stack);
    }

    private static boolean canMergeItems(class_1799 first, class_1799 second) {
        return first.method_7947() <= first.method_7914() && class_1799.method_31577(first, second);
    }
}
