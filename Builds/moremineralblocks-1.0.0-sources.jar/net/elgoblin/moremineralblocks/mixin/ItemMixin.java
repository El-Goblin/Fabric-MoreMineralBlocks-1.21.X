package net.elgoblin.moremineralblocks.mixin;

import net.elgoblin.moremineralblocks.util.ProtectorManager;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_9362;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import java.util.function.BiConsumer;


@Mixin(class_1792.class)
public class ItemMixin {

    @Unique
    private static final Map<class_2248, class_2248> crackedBlocks = Map.of(
            class_2246.field_10056, class_2246.field_10416,
            class_2246.field_28900, class_2246.field_29222,
            class_2246.field_28896, class_2246.field_29223,
            class_2246.field_10266, class_2246.field_23867,
            class_2246.field_23874, class_2246.field_23875,
            class_2246.field_10387, class_2246.field_10100
    );

    @Inject(
            method = "useOnBlock",
            at = @At("HEAD"),
            cancellable = true
    )
    private void useOnBlock(class_1838 context, CallbackInfoReturnable<class_1269> cir) {
        if (context.method_8041().method_7909() instanceof class_9362) {
            class_2248 blockToCrack = context.method_8045().method_8320(context.method_8037()).method_26204();
            class_2248 cracked = crackedBlocks.get(blockToCrack);

            if (cracked != null) {
                context.method_8045().method_8501(context.method_8037(), cracked.method_9564());
                context.method_8041().method_61653(1, context.method_8036());
                cir.setReturnValue(class_1269.field_5812);
            }
        }
    }
}

