package net.elgoblin.moremineralblocks.structure;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.structure.placements.DistanceBasedStructurePlacement;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_6875;
import net.minecraft.class_7923;

public class MoreMineralBlocksStructurePlacement {

    public static class_6875<DistanceBasedStructurePlacement> DISTANCE_BASED_STRUCTURE_PLACEMENT;

    /**
     * Registers the structure placement type itself and sets what its path is. In this case,
     * this base structure will have the resourcelocation of structure_tutorial:distance_based_structure_placement.
     */
    public static void registerStructurePlacementTypes() {
        DISTANCE_BASED_STRUCTURE_PLACEMENT = class_2378.method_10230(class_7923.field_41145, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "distance_based_structure_placement"), () -> DistanceBasedStructurePlacement.CODEC);
    }
}
