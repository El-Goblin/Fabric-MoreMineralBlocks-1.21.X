package net.elgoblin.moremineralblocks.structure.placements;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.elgoblin.moremineralblocks.structure.MoreMineralBlocksStructurePlacement;
import net.minecraft.class_1923;
import net.minecraft.class_2382;
import net.minecraft.class_5699;
import net.minecraft.class_6872;
import net.minecraft.class_6873;
import net.minecraft.class_6874;
import net.minecraft.class_6875;
import net.minecraft.class_7869;
import net.minecraft.world.gen.chunk.placement.*;

import java.util.Optional;

public class DistanceBasedStructurePlacement extends class_6872 {

    public static final MapCodec<DistanceBasedStructurePlacement> CODEC = RecordCodecBuilder.mapCodec((instance) -> instance.group(
            class_2382.method_39677(16).optionalFieldOf("locate_offset", class_2382.field_11176).forGetter(DistanceBasedStructurePlacement::method_41642),
            class_6874.class_7154.field_37786.optionalFieldOf("frequency_reduction_method", class_6874.class_7154.field_37782).forGetter(DistanceBasedStructurePlacement::method_41643),
            Codec.floatRange(0.0F, 1.0F).optionalFieldOf("frequency", 1.0F).forGetter(DistanceBasedStructurePlacement::method_41644),
            class_5699.field_33441.fieldOf("salt").forGetter(DistanceBasedStructurePlacement::method_41645),
            class_6874.class_7152.field_37781.optionalFieldOf("exclusion_zone").forGetter(DistanceBasedStructurePlacement::method_41646),
            Codec.intRange(0, Integer.MAX_VALUE).fieldOf("spacing").forGetter(DistanceBasedStructurePlacement::method_41632),
            Codec.intRange(0, Integer.MAX_VALUE).fieldOf("separation").forGetter(DistanceBasedStructurePlacement::method_41633),
            class_6873.field_36423.optionalFieldOf("spread_type", class_6873.field_36421).forGetter(DistanceBasedStructurePlacement::method_41634),
            Codec.intRange(0, Integer.MAX_VALUE).optionalFieldOf("min_distance_from_world_origin").forGetter(DistanceBasedStructurePlacement::minDistanceFromWorldOrigin)
    ).apply(instance, instance.stable(DistanceBasedStructurePlacement::new)));

    private final Optional<Integer> minDistanceFromWorldOrigin;

    public DistanceBasedStructurePlacement(class_2382 locateOffset,
                                           class_7154 frequencyReductionMethod,
                                           float frequency,
                                           int salt,
                                           Optional<class_7152> exclusionZone,
                                           int spacing,
                                           int separation,
                                           class_6873 spreadType,
                                           Optional<Integer> minDistanceFromWorldOrigin) {
        super(locateOffset, frequencyReductionMethod, frequency, salt, exclusionZone, spacing, separation, spreadType);
        this.minDistanceFromWorldOrigin = minDistanceFromWorldOrigin;

        // Helpful validation to ensure that spacing value is always greater than separation value
        if (spacing <= separation) {
            throw new RuntimeException("""
                Spacing cannot be less or equal to separation.
                Please correct this error as there's no way to spawn this structure properly
                    Spacing: %s
                    Separation: %s.
            """.formatted(spacing, separation));
        }
    }

    public Optional<Integer> minDistanceFromWorldOrigin() {
        return this.minDistanceFromWorldOrigin;
    }

    // Override this method to add coordinate checking.
    // The x and z here is in chunk positions.
    // What we do is we check if the structure is too close to world center and if so, return false.
    // Otherwise, if far enough away, run the normal structure position choosing code.
    // When this returns true, the structure's type class will be called to see if the structure layout can be made.
    @Override
    protected boolean method_40168(class_7869 structurePlacementCalculator, int x, int z) {

        // Recordar que minDistanceFromWorldOrigin es un Optional
        if (minDistanceFromWorldOrigin.isPresent()) {
            // Convert chunk position to block position.
            long xBlockPos = x * 16L;
            long zBlockPos = z * 16L;

            // Simple fast distance check without needing to do a square root. The threshold is circular around world origin.
            if ((xBlockPos * xBlockPos) + (zBlockPos * zBlockPos) < (((long) minDistanceFromWorldOrigin.get()) * minDistanceFromWorldOrigin.get())) {
                return false;
            }
        }

        class_1923 chunkpos = this.method_40169(structurePlacementCalculator.method_46714(), x, z);
        return chunkpos.field_9181 == x && chunkpos.field_9180 == z;
    }

    @Override
    public class_6875<?> method_40166() {
        return MoreMineralBlocksStructurePlacement.DISTANCE_BASED_STRUCTURE_PLACEMENT;
    }
}
