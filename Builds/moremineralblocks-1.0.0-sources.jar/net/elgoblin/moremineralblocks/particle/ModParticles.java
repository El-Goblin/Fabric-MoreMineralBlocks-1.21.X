package net.elgoblin.moremineralblocks.particle;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModParticles {

    public static final class_2400 PICKAXE_PARTICLE = registerParticle("pickaxe_particle", FabricParticleTypes.simple());
    public static final class_2400 CHAOS_ORB_HASTE_PARTICLE = registerParticle("haste_particle", FabricParticleTypes.simple());
    public static final class_2400 CHAOS_ORB_JUMP_BOOST_PARTICLE = registerParticle("jump_boost_particle", FabricParticleTypes.simple());
    public static final class_2400 CHAOS_ORB_REGENERATION_PARTICLE = registerParticle("regeneration_particle", FabricParticleTypes.simple());
    public static final class_2400 CHAOS_ORB_RESISTANCE_PARTICLE = registerParticle("resistance_particle", FabricParticleTypes.simple());
    public static final class_2400 CHAOS_ORB_SPEED_PARTICLE = registerParticle("speed_particle", FabricParticleTypes.simple());
    public static final class_2400 CHAOS_ORB_STRENGTH_PARTICLE = registerParticle("strength_particle", FabricParticleTypes.simple());
    public static final class_2400 CHAOS_ORB_COUNTER_BLINK_PARTICLE = registerParticle("counter_blink_particle", FabricParticleTypes.simple());
    public static final class_2400 CHAOS_ORB_BLINKING_PARTICLE = registerParticle("blinking_particle", FabricParticleTypes.simple());
    public static final class_2400 CHAOS_ORB_FRAGILE_PARTICLE = registerParticle("fragile_particle", FabricParticleTypes.simple());

    //

    private static class_2400 registerParticle(String name, class_2400 particleType) {
        return class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name), particleType);
    }

    public static void registerParticles() {
        MoreMineralBlocks.LOGGER.info("Registering Particles for " + MoreMineralBlocks.MOD_ID);
    }
}
