package net.elgoblin.moremineralblocks.particle.custom;

import net.minecraft.class_2400;
import net.minecraft.class_3940;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;
import org.jetbrains.annotations.Nullable;

public class ChaosOrbFeedbackParticle extends class_3940 {
    public ChaosOrbFeedbackParticle(class_638 clientWorld, double x, double y, double z,
                           class_4002 spriteProvider, double xSpeed, double ySpeed, double zSpeed) {
        super(clientWorld, x, y, z, xSpeed, ySpeed, zSpeed, spriteProvider.method_74304());

        this.field_3847 = 100;
        this.field_17867 = 1.5f;
        this.field_3852 = 0.0;
        this.field_3869 = 1.0;
        this.field_3850 = 0.0;
        this.field_3862 = false;
    }

    @Override
    protected class_11941 method_74255() {
        return class_11941.field_62639;
    }

    public static class Factory implements class_707<class_2400> {
        private final class_4002 spriteProvider;

        public Factory(class_4002 spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        @Override
        public @Nullable class_703 createParticle(class_2400 parameters, class_638 world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, class_5819 random) {
            return new ChaosOrbFeedbackParticle(world, x, y, z, this.spriteProvider, velocityX, velocityY, velocityZ);
        }
    }
}
