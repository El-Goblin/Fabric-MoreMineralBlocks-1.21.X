package net.elgoblin.moremineralblocks.component;

import com.mojang.serialization.Codec;
import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.effect.LaLechonaConsumeEffect;
import net.minecraft.class_10124;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9304;
import net.minecraft.class_9331;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.UnaryOperator;

import static net.minecraft.class_10128.method_62859;

public class ModDataComponentTypes {

    public static final class_9331<class_9304> OTHER_STORED_ENCHANTMENTS = register(
		"other_stored_enchantments", builder -> builder.method_57881(class_9304.field_49386).method_57882(class_9304.field_49387).method_59871()
    );
    public static final class_9331<class_9304> OTHER_ENCHANTMENTS = register(
            "other_enchantments", builder -> builder.method_57881(class_9304.field_49386).method_57882(class_9304.field_49387).method_59871()
    );
    public static final class_9331<String> ENCHANTMENT_SET = register("enchantment_set", builder -> builder.method_57881(Codec.STRING));


    public static final class_9331<class_2338> LINKED_CHEST = register("linked_chest", builder -> builder.method_57881(class_2338.field_25064));
    public static final class_9331<class_2338> OTHER_LINKED_CHEST = register("other_linked_chest", builder -> builder.method_57881(class_2338.field_25064));
    public static final class_9331<class_243> COORDINATES = register("coordinates", builder -> builder.method_57881(class_243.field_38277));
    public static final class_9331<class_2960> SERVERWORLD = register("server_id", builder -> builder.method_57881(class_2960.field_25139));
    public static final class_9331<class_2960> OTHER_SERVERWORLD = register("other_server_id", builder -> builder.method_57881(class_2960.field_25139));
    public static final class_9331<Integer> INTER_GROUP_POINTER = register("inter_group_pointer", builder -> builder.method_57881(Codec.INT));

    public static final class_9331<Integer> SELECTED_COLOR = register("selected_color", builder -> builder.method_57881(Codec.INT));
    public static final class_9331<List<Integer>> INTRA_GROUP_POINTERS = register("intra_group_pointers", builder -> builder.method_57881(Codec.INT.listOf()));

    public static final class_9331<Boolean> SAFE_MODE = register("safe_mode", builder -> builder.method_57881(Codec.BOOL));

    public static final Map<class_1767, class_9331<List<Integer>>> COLOR_INVENTORIES = new EnumMap<>(class_1767.class);

//    public static final ComponentType<Float> DAMAGE_DEALT_THIS_HIT = register("damage_dealt_this_hit", builder -> builder.codec(Codec.FLOAT));

    public static void registerComponents() {
        for (class_1767 color : class_1767.values()) {
            final String name = color.name().toLowerCase() + "_inventory_pointers";

            class_9331<List<Integer>> component = register(name, builder -> builder
                    .method_57881(Codec.list(Codec.INT))
                    .method_57882(class_9135.field_49675.method_56433(class_9135.method_56363()))
            );

            COLOR_INVENTORIES.put(color, component);
        }
    }


//    public static final ComponentType<Integer> CUMULATED_DAMAGE_TAKEN = register(
//            "cumulated_damage_taken", builder -> builder.codec(Codecs.rangedInt(0, 100)).packetCodec(PacketCodecs.VAR_INT).cache()
//    );
    public static final class_9331<class_1799> CHOSEN_INFINITE_ITEM = register("chosen_infinite_item",
        builder -> builder.method_57881(class_1799.field_24671).method_57882(class_1799.field_48349).method_59871());

    public static final class_10124 LA_LECHONA = method_62859().method_62854(LaLechonaConsumeEffect.INSTANCE).method_62851();


    private static <T>class_9331<T> register(String name, UnaryOperator<class_9331.class_9332<T>> builderOperator) {
        return class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name),
                        builderOperator.apply(class_9331.method_57873()).method_57880());
    }

    public static void registerDataComponentTypes() {
        MoreMineralBlocks.LOGGER.info("Registering Data Components for " + MoreMineralBlocks.MOD_ID);
        registerComponents();
    }
}
