package net.elgoblin.moremineralblocks.effect;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class ModEffects {
    public static final class_6880<class_1291> BLINKING = registerStatusEffect("blinking",
            new BlinkingEffect(class_4081.field_18273, 0x00ff20));

//    public static final RegistryEntry<StatusEffect> ADVENTURE = registerStatusEffect("adventure",
//            new AdventureEffect(StatusEffectCategory.NEUTRAL, 0x00ff20));

    public static final class_6880<class_1291> COUNTER_BLINK = registerStatusEffect("counter_blink", new OnDamageTakenEffect(class_4081.field_18272, 12779366));
    public static final class_6880<class_1291> FRAGILE = registerStatusEffect("fragile", new OnDamageTakenEffect(class_4081.field_18272, 12771234));
//    public static final RegistryEntry<StatusEffect> ONANA_HANDS = registerStatusEffect("onana_hands", new OnDamageTakenEffect(StatusEffectCategory.HARMFUL, 12779366));
//    public static final RegistryEntry<StatusEffect> CUMULATIVE_DAMAGE_TAKEN = registerStatusEffect("cumulative_damage_taken", new OnDamageTakenEffect(StatusEffectCategory.HARMFUL, 12779366)
//            .addAttributeModifier(ModEntityAttributes.CUMULATIVE_DAMAGE_TAKEN, Identifier.of(MoreMineralBlocks.MOD_ID, "cumulative_damage_taken"), 0.5, EntityAttributeModifier.Operation.ADD_VALUE));

    private static class_6880<class_1291> registerStatusEffect(String name, class_1291 statusEffect) {
        return class_2378.method_47985(class_7923.field_41174, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name), statusEffect);
    }
    public static void registerEffects() {
        MoreMineralBlocks.LOGGER.info("Registering Mod Effects for " + MoreMineralBlocks.MOD_ID);
    }
}
