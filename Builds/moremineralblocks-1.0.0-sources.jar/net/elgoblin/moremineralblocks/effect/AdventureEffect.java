package net.elgoblin.moremineralblocks.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4081;
import net.minecraft.class_5131;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Map;

public class AdventureEffect extends class_1291 {
    private Integer counter = 0;

    public AdventureEffect(class_4081 category, int color) {
        super(category, color);
        counter = 0;
    }

    @Override
    public boolean method_5572(class_3218 world, class_1309 entity, int amplifier) {
        if (!entity.method_73183().method_8608()) {
            counter = counter+1;
            if (entity.method_31747()) {
                MinecraftServer server = entity.method_73183().method_8503();
                if (server != null) {
                    List<class_3222> list = server.method_3760().method_14571();
                    if (!list.isEmpty()) {
                        class_3222 serverPlayerEntity = (class_3222)list.get(0);
                        serverPlayerEntity.method_7336(class_1934.field_9216);
                    }
                }
            }
            if (counter % 100 == 0) {
                if (entity instanceof class_1657 player) {
                    player.method_7353(class_2561.method_30163("Pasaron 5 segundos"), true);
                }
            }
        }

        return super.method_5572(world, entity, amplifier);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        return true;
    }

    @Override
    public void method_5562(class_5131 attributeContainer) {
        super.method_5562(attributeContainer);
    }
}
