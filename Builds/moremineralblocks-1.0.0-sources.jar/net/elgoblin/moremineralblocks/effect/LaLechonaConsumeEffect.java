package net.elgoblin.moremineralblocks.effect;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.minecraft.class_10134;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1324;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_5134;
import net.minecraft.class_6880;

public record LaLechonaConsumeEffect() implements class_10134 {
    public static final LaLechonaConsumeEffect INSTANCE = new LaLechonaConsumeEffect();

    @Override
    public class_10135<? extends class_10134> method_62864() {
        return class_10135.field_53812;
    }

    @Override
    public boolean method_62866(class_1937 world, class_1799 stack, class_1309 user) {
        applyAttributeChange(class_5134.field_47760, 1, user);
        applyAttributeChange(class_5134.field_23716, 20, user);
        applyAttributeChange(class_5134.field_47761, 0.6, user);
        applyAttributeChange(class_5134.field_49079, 3, user);
        applyAttributeChange(class_5134.field_23719, 0.1, user);
        applyAttributeChange(class_5134.field_23728, 0.42, user);
        applyAttributeChange(class_5134.field_47758, 4.5, user);
        applyAttributeChange(class_5134.field_47759, 3, user);
        applyAttributeChange(class_5134.field_49076, 1, user);
        return user.method_6012();
    }

    private void applyAttributeChange(class_6880<class_1320> attribute, double value, class_1309 player) {
        class_1324 currentStat = player.method_5996(attribute);
        if (currentStat != null) {
            currentStat.method_6192(value);
        }
    }
}
