package net.elgoblin.moremineralblocks.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_3218;
import net.minecraft.class_4081;

public class OnDamageTakenEffect extends class_1291 {

    public OnDamageTakenEffect(class_4081 category, int color) {
        super(category, color);
    }

    @Override
    public boolean method_5572(class_3218 world, class_1309 entity, int amplifier) {
        return super.method_5572(world, entity, amplifier);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        return true;
    }
}
