package net.elgoblin.moremineralblocks.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_4019;
import net.minecraft.class_4081;
import net.minecraft.class_5712;

public class BlinkingEffect extends class_1291 {
    private Integer counter = 0;

    public BlinkingEffect(class_4081 category, int color) {
        super(category, color);
        counter = 0;
    }

    @Override
    public boolean method_5572(class_3218 world, class_1309 entity, int amplifier) {
        if (!world.method_8608()) {
            for (int i = 0; i < 16; i++) {
                double d = entity.method_23317() + (entity.method_59922().method_43058() - 0.5) * 16.0;
                double e = class_3532.method_15350(
                        entity.method_23318() + (entity.method_59922().method_43048(16) - 8), (double)world.method_31607(), (double)(world.method_31607() + ((class_3218)world).method_32819() - 1)
                );
                double f = entity.method_23321() + (entity.method_59922().method_43058() - 0.5) * 16.0;
                if (entity.method_5765()) {
                    entity.method_5848();
                }

                class_243 vec3d = entity.method_73189();
                if (entity.method_6082(d, e, f, true)) {
                    world.method_32888(class_5712.field_39446, vec3d, class_5712.class_7397.method_43285(entity));
                    class_3419 soundCategory;
                    class_3414 soundEvent;
                    if (entity instanceof class_4019) {
                        soundEvent = class_3417.field_24630;
                        soundCategory = class_3419.field_15254;
                    } else {
                        soundEvent = class_3417.field_14890;
                        soundCategory = class_3419.field_15248;
                    }

                    world.method_54762(null, entity.method_23317(), entity.method_23318(), entity.method_23321(), soundEvent, soundCategory);
                    entity.method_38785();
                    break;
                }
            }
        }

        return super.method_5572(world, entity, amplifier);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        int i = 200 >> amplifier;
        return i > 0 ? duration % i == 1 : true;
    }
}
