package net.elgoblin.moremineralblocks.networking;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record InfiniteItemStackInterGroupScrollPayload(Integer scroll) implements class_8710 {
    public static final class_9154<InfiniteItemStackInterGroupScrollPayload> ID = new class_9154<>(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "infinite_item_inter_group_scroll"));
    public static final class_9139<class_9129, InfiniteItemStackInterGroupScrollPayload> CODEC = class_9139.method_56434(
            class_9135.field_49675, InfiniteItemStackInterGroupScrollPayload::scroll,
            InfiniteItemStackInterGroupScrollPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
