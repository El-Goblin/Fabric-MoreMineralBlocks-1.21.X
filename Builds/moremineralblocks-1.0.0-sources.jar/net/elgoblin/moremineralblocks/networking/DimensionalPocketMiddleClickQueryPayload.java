package net.elgoblin.moremineralblocks.networking;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7924;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record DimensionalPocketMiddleClickQueryPayload(class_1799 itemStack, class_2248 clicked) implements class_8710 {
    public static final class_9154<DimensionalPocketMiddleClickQueryPayload> ID = new class_9154<>(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "dimensional_pocket_middle_click_query_payload"));
    public static final class_9139<class_9129, DimensionalPocketMiddleClickQueryPayload> CODEC = class_9139.method_56435(
            class_1799.field_49268, DimensionalPocketMiddleClickQueryPayload::itemStack,
            class_9135.method_56365(class_7924.field_41254), DimensionalPocketMiddleClickQueryPayload::clicked,
            DimensionalPocketMiddleClickQueryPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
