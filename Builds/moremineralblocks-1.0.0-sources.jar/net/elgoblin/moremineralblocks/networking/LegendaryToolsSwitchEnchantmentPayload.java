package net.elgoblin.moremineralblocks.networking;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record LegendaryToolsSwitchEnchantmentPayload() implements class_8710 {
    public static final class_9154<LegendaryToolsSwitchEnchantmentPayload> ID = new class_9154<>(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "switch_enchantments"));
    public static final class_9139<class_9129, LegendaryToolsSwitchEnchantmentPayload> CODEC = class_9139.method_56431(new LegendaryToolsSwitchEnchantmentPayload());

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
