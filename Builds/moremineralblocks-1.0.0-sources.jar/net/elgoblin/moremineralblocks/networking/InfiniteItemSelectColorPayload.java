package net.elgoblin.moremineralblocks.networking;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record InfiniteItemSelectColorPayload(int colorIndex, int slot) implements class_8710 {
    public static final class_9154<InfiniteItemSelectColorPayload> ID = new class_9154<>(class_2960.method_60655("moremineralblocks", "infinite_item_select_color"));
    public static final class_9139<class_9129, InfiniteItemSelectColorPayload> CODEC = class_9139.method_56435(
            class_9135.field_49675, InfiniteItemSelectColorPayload::colorIndex,
            class_9135.field_49675, InfiniteItemSelectColorPayload::slot,
            InfiniteItemSelectColorPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
