package net.elgoblin.moremineralblocks.networking;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record InfiniteItemstackV2ChestContentsQueryPayload(class_1799 itemStack) implements class_8710 {
    public static final class_9154<InfiniteItemstackV2ChestContentsQueryPayload> ID = new class_9154<>(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "infinite_item_chest_contents_query"));
    public static final class_9139<class_9129, InfiniteItemstackV2ChestContentsQueryPayload> CODEC = class_9139.method_56434(
            class_1799.field_49268, InfiniteItemstackV2ChestContentsQueryPayload::itemStack,
            InfiniteItemstackV2ChestContentsQueryPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
