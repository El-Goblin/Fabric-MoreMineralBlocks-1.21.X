package net.elgoblin.moremineralblocks.networking;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7924;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record DimensionPocketMiddleClickQueryPayload(class_1799 itemStack, class_2248 clicked) implements class_8710 {
    public static final class_9154<DimensionPocketMiddleClickQueryPayload> ID = new class_9154<>(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "dimension_pocket_middle_click_query"));
    public static final class_9139<class_9129, DimensionPocketMiddleClickQueryPayload> CODEC = class_9139.method_56435(
            class_1799.field_49268, DimensionPocketMiddleClickQueryPayload::itemStack,
            class_9135.method_56365(class_7924.field_41254), DimensionPocketMiddleClickQueryPayload::clicked,
            DimensionPocketMiddleClickQueryPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
