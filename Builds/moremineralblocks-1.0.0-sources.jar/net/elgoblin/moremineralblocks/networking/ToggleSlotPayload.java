package net.elgoblin.moremineralblocks.networking;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ToggleSlotPayload(int targetSlotId, int clickedSlotId, int colorIndex) implements class_8710 {

    public static final class_8710.class_9154<ToggleSlotPayload> ID = new class_8710.class_9154<>(
            class_2960.method_60655(MoreMineralBlocks.MOD_ID, "toggle_slot")
    );

    public static final class_9139<class_9129, ToggleSlotPayload> CODEC = class_9139.method_56436(
            class_9135.field_48550, ToggleSlotPayload::targetSlotId,
            class_9135.field_48550, ToggleSlotPayload::clickedSlotId,
            class_9135.field_48550, ToggleSlotPayload::colorIndex,
            ToggleSlotPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
