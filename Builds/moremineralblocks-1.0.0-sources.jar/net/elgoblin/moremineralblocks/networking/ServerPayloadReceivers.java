package net.elgoblin.moremineralblocks.networking;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.elgoblin.moremineralblocks.item.custom.DimensionalPocketItem;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1263;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9331;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ServerPayloadReceivers {

    public static void registerDimensionPocketGlobalReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(DimensionalPocketDepositContentsQueryPayload.ID,
                (payload, context) -> {
                    context.server().execute(() -> {
                        class_1799 infiniteItem = payload.itemStack();

                        DimensionalPocketItem.DimensionalPocketData dimPocketData = checkValidDimensionalPocket(infiniteItem, context.server());
                        if (dimPocketData == null) {
                            sendEmptyPayload(context);
                            return;
                        }

                        class_3218 targetWorld = dimPocketData.targetWorld();
                        class_2338 storagePos = dimPocketData.storagePos();
                        Integer interGroupPointer = dimPocketData.interGroupPointer();
                        List<Integer> intraGroupPointers = dimPocketData.intraGroupPointers();
                        boolean safeMode = dimPocketData.safeMode();

                        if (!(dimPocketData.targetWorld().method_8321(storagePos) instanceof class_1263)) {
                            sendEmptyPayload(context);
                            return;
                        }

                        class_1263 deposit = getDeposit(targetWorld, storagePos);
                        if (deposit == null) {
                            sendEmptyPayload(context);
                            return;
                        }

                        StacksToShow stacksToShow = getStacksToShow(infiniteItem, deposit, interGroupPointer, intraGroupPointers.get(interGroupPointer), safeMode);
                        int nextGroupIndex = findNextNonEmptyGroup(infiniteItem, deposit, interGroupPointer, 1, safeMode);
                        int prevGroupIndex = findNextNonEmptyGroup(infiniteItem, deposit, interGroupPointer, -1, safeMode);

                        List<Integer> prevGroup = infiniteItem.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(prevGroupIndex)));
                        List<Integer> nextGroup = infiniteItem.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(nextGroupIndex)));

                        class_1799 prevGroupStack = prevGroup != null ? getStackFromInventory(deposit, prevGroup.get(intraGroupPointers.get(prevGroupIndex))) : class_1799.field_8037;
                        class_1799 nextGroupStack = nextGroup != null ? getStackFromInventory(deposit, nextGroup.get(intraGroupPointers.get(nextGroupIndex))) : class_1799.field_8037;

                        context.responseSender().sendPacket(new DimensionalPocketDepositContentsResponsePayload(
                                stacksToShow.currentStack,
                                stacksToShow.countCurrentStack,
                                stacksToShow.prevStack,
                                stacksToShow.nextStack,
                                prevGroupStack,
                                prevGroupIndex,
                                nextGroupStack,
                                nextGroupIndex
                        ));
                    });
                });

        ServerPlayNetworking.registerGlobalReceiver(DimensionalPocketMiddleClickQueryPayload.ID,
                (payload, context) -> {
                    context.server().execute(() -> {
                        class_3222 player = context.player();
                        class_1799 infiniteItem = player.method_6047();
                        if (!infiniteItem.method_31574(ModItems.DIMENSIONAL_POCKET)){
                            infiniteItem = player.method_6079();
                        }
                        if (!infiniteItem.method_31574(ModItems.DIMENSIONAL_POCKET)) {
                            return;
                        }

                        DimensionalPocketItem.DimensionalPocketData dimPocketData = checkValidDimensionalPocket(infiniteItem, context.server());
                        if (dimPocketData == null) {
                            return;
                        }

                        class_3218 targetWorld = dimPocketData.targetWorld();
                        class_2338 storagePos = dimPocketData.storagePos();
                        Integer interGroupPointer = dimPocketData.interGroupPointer();
                        List<Integer> intraGroupPointers = dimPocketData.intraGroupPointers();
                        boolean safeMode = dimPocketData.safeMode();

                        if (!(dimPocketData.targetWorld().method_8321(storagePos) instanceof class_1263)) {
                            return;
                        }

                        class_1263 deposit = getDeposit(targetWorld, storagePos);
                        if (deposit == null) {
                            return;
                        }

                        List<Integer> group = infiniteItem.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(interGroupPointer)));
                        if (group == null) {
                            return;
                        }

                        ArrayList<Integer> newIntraGroupPointers = new ArrayList<>(intraGroupPointers);

                        // Esta en el grupo en el que estoy?
                        for (int i = 0 ; i < group.size() ; i++) {
                            class_1799 currentStack = getStackFromInventory(deposit, group.get(i));
                            if (currentStack.method_7947() > (safeMode ? 1 : 0) &&
                                    currentStack.method_7909() == payload.clicked().method_8389()) {
                                newIntraGroupPointers.set(interGroupPointer, i);
                                infiniteItem.method_57379(ModDataComponentTypes.INTRA_GROUP_POINTERS, newIntraGroupPointers);
                                return;
                            }
                        }

                        // Esta en algun grupo?
                        for (int offset = 0 ; offset < 16 ; offset++) {
                            int newInterGroupPointer = Math.floorMod(interGroupPointer + offset, 16);
                            group = infiniteItem.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(newInterGroupPointer)));

                            if (group == null) {
                                return;
                            }

                            // Esta en el grupo en el que estoy?
                            for (int i = 0 ; i < group.size() ; i++) {
                                class_1799 currentStack = getStackFromInventory(deposit, group.get(i));
                                if (currentStack.method_7947() > (safeMode ? 1 : 0) &&
                                        currentStack.method_7909() == payload.clicked().method_8389()) {
                                    newIntraGroupPointers.set(newInterGroupPointer, i);
                                    infiniteItem.method_57379(ModDataComponentTypes.INTER_GROUP_POINTER, newInterGroupPointer);
                                    infiniteItem.method_57379(ModDataComponentTypes.INTRA_GROUP_POINTERS, newIntraGroupPointers);
                                    return;
                                }
                            }
                        }
                    });
                });

        ServerPlayNetworking.registerGlobalReceiver(DimensionalPocketToggleSlotPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                class_3222 player = context.player();
                class_1703 handler = player.field_7512;

                if (handler == null) return;

                class_1735 targetSlot = handler.method_7611(payload.targetSlotId());
                if (targetSlot == null || targetSlot.method_7677().method_7960()) {return;}
                class_1799 itemStack = targetSlot.method_7677();

                if (!itemStack.method_31574(ModItems.DIMENSIONAL_POCKET)) {return;}

                class_1767 dyeColor = class_1767.method_7791(payload.colorIndex());
                class_9331<List<Integer>> colorComponent = ModDataComponentTypes.COLOR_INVENTORIES.get(dyeColor);

                if (colorComponent == null) {return;}

                List<Integer> existingSlots = itemStack.method_58695(colorComponent, List.of());
                List<Integer> updatedSlots = new ArrayList<>(existingSlots);

                int clickedSlotId = payload.clickedSlotId();

                if (updatedSlots.contains(clickedSlotId)) {
                    updatedSlots.remove(Integer.valueOf(clickedSlotId));
                } else {
                    updatedSlots.add(clickedSlotId);
                }
                itemStack.method_57379(colorComponent, updatedSlots);
                targetSlot.method_7668();
                handler.method_34252();

            });
        });

        ServerPlayNetworking.registerGlobalReceiver(DimensionalPocketSelectColorPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                class_3222 player = context.player();
                class_1703 currentHandler = player.field_7512;

                if (currentHandler == null) {return;}

                int targetSlot = payload.slot();

                if (targetSlot >= 0 && targetSlot < currentHandler.field_7761.size()) {
                    class_1799 stack = currentHandler.method_7611(targetSlot).method_7677();

                    if (stack.method_31574(ModItems.DIMENSIONAL_POCKET)) {
                        stack.method_57379(ModDataComponentTypes.SELECTED_COLOR, payload.colorIndex());
                    }
                }

            });
        });

        ServerPlayNetworking.registerGlobalReceiver(DimensionalPocketInterGroupScrollPayload.ID,
                (payload, context) -> {
                    class_3222 player = context.player();
                    class_1799 activeHand = class_1799.field_8037;
                    if (player.method_6047().method_31574(ModItems.DIMENSIONAL_POCKET)) {
                        activeHand = player.method_6047();
                    }
                    else if (player.method_6079().method_31574(ModItems.DIMENSIONAL_POCKET)) {
                        activeHand = player.method_6079();
                    }

                    if (activeHand.method_7960()) {
                        return;
                    }

                    DimensionalPocketItem.DimensionalPocketData dimPocketData = checkValidDimensionalPocket(activeHand, context.server());

                    if (dimPocketData == null) {
                        return;
                    }

                    class_3218 targetWorld = dimPocketData.targetWorld();
                    class_2338 storagePos = dimPocketData.storagePos();
                    Integer interGroupPointer = dimPocketData.interGroupPointer();
                    List<Integer> intraGroupPointers = dimPocketData.intraGroupPointers();
                    boolean safeMode = dimPocketData.safeMode();

                    class_1263 deposit = getDeposit(targetWorld, storagePos);
                    if (deposit == null) {
                        return;
                    }
                    int newInterGroupPointer = interGroupPointer;

                    for (int offset = 1 ; offset < 16 ; offset++) {
                        newInterGroupPointer = Math.floorMod(newInterGroupPointer + payload.scroll(), 16);
                        List<Integer> group = activeHand.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(newInterGroupPointer)));

                        if (group == null || group.isEmpty()) {
                            continue;
                        }
                        int firstNonEmptySlot = isGroupEmpty(deposit, group, safeMode);
                        int oldIntraGroupPointer = intraGroupPointers.get(newInterGroupPointer);
                        int newIntraGroupPointer = firstNonEmptySlot;
                        if (group.size() > oldIntraGroupPointer) {
                            newIntraGroupPointer = (getStackFromInventory(deposit, group.get(oldIntraGroupPointer)).method_7947() > (safeMode ? 1 : 0)) ? oldIntraGroupPointer : firstNonEmptySlot;
                        }


                        if (newIntraGroupPointer != -1) {
                            activeHand.method_57379(ModDataComponentTypes.INTER_GROUP_POINTER, newInterGroupPointer);
                            List<Integer> newIntraGroupPointers = new ArrayList<>(intraGroupPointers);
                            newIntraGroupPointers.set(newInterGroupPointer, newIntraGroupPointer);
                            activeHand.method_57379(ModDataComponentTypes.INTRA_GROUP_POINTERS, newIntraGroupPointers);
                            return;
                        }
                    }
                });

        ServerPlayNetworking.registerGlobalReceiver(DimensionalPocketIntraGroupScrollPayload.ID,
                (payload, context) -> {
                    class_3222 player = context.player();
                    class_1799 activeHand = class_1799.field_8037;
                    if (player.method_6047().method_31574(ModItems.DIMENSIONAL_POCKET)) {activeHand = player.method_6047();}
                    else if (player.method_6079().method_31574(ModItems.DIMENSIONAL_POCKET)) {activeHand = player.method_6079();}

                    if (activeHand.method_7960()) {return;}

                    DimensionalPocketItem.DimensionalPocketData dimPocketData = checkValidDimensionalPocket(activeHand, context.server());

                    if (dimPocketData == null) {
                        return;
                    }

                    class_2338 storagePosition = dimPocketData.storagePos();
                    class_3218 targetWorld = dimPocketData.targetWorld();
                    Integer interGroupPointer = dimPocketData.interGroupPointer();
                    List<Integer> intraGroupPointers = dimPocketData.intraGroupPointers();
                    boolean safeMode = dimPocketData.safeMode();


                    class_1263 deposit = getDeposit(targetWorld, storagePosition);
                    if (deposit == null) {
                        return;
                    }

                    List<Integer> group = activeHand.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(interGroupPointer)));
                    if (group == null) {return;}

                    class_1799 heldStack = getStackFromInventory(deposit, group.get(intraGroupPointers.get(interGroupPointer)));

                    List<Integer> newIntraGroupPointers = new ArrayList<>(intraGroupPointers);
                    int newPointer = intraGroupPointers.get(interGroupPointer);
                    class_1792 targetItem = payload.scroll() > 0 ? payload.prevItem().method_7909() : payload.nextItem().method_7909();

                    for (int offset = 1 ; offset <= group.size(); offset++) {
                        newPointer = Math.floorMod(newPointer - payload.scroll(), group.size());
                        class_1799 currentStack = getStackFromInventory(deposit, group.get(newPointer));
                        if (currentStack.method_7947() > (safeMode ? 1 : 0) && currentStack.method_31574(targetItem)) {
                            newIntraGroupPointers.set(interGroupPointer, newPointer);
                            activeHand.method_57379(ModDataComponentTypes.INTRA_GROUP_POINTERS, newIntraGroupPointers);
                            return;
                        }
                    }
                });
    }

    private static int findNextNonEmptyGroup(class_1799 infiniteItemstack, class_1263 deposit, int currentGroup, int direction, boolean safeMode) {
        int newGroup = currentGroup;
        for (int i = 1; i < 16 ; i++) {
            newGroup = Math.floorMod(newGroup + direction, 16);
            List<Integer> group = infiniteItemstack.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(newGroup)));

            if (group == null || group.isEmpty()) {
                continue;
            }

            for (int j = 0 ; j < group.size() ; j++) {
                class_1799 currentStack = getStackFromInventory(deposit, group.get(j));
                if (currentStack.method_7947() > (safeMode ? 1 : 0)) {
                    return newGroup;
                }
            }
        }
        return currentGroup;
    }

    private static class_1799 getStackFromInventory(class_1263 inventory, int index) {
        if (inventory.method_5442()) {
            return class_1799.field_8037;
        }

        int newPointer = Math.floorMod(index, inventory.method_5439());
        return inventory.method_5438(newPointer);
    }

    private static void sendEmptyPayload(ServerPlayNetworking.Context context) {
        context.responseSender().sendPacket(new DimensionalPocketDepositContentsResponsePayload(
                class_1799.field_8037, 0, class_1799.field_8037, class_1799.field_8037, class_1799.field_8037, 0, class_1799.field_8037, 0
        ));
    }

    private static int isGroupEmpty(class_1263 deposit, List<Integer> group, boolean safeMode) {
        for (int i = 0 ; i < group.size() ; i++) {
            class_1799 currentStack = getStackFromInventory(deposit, group.get(i));
            if (currentStack.method_7947() > (safeMode ? 1 : 0)) {
                return i; // El grupo no esta vacio y su slot i contiene algo
            }
        }
        return -1; // Ninguno de los slots del grupo contiene algo
    }

    private static DimensionalPocketItem.DimensionalPocketData checkValidDimensionalPocket(class_1799 infiniteItem, MinecraftServer server){
        if (!infiniteItem.method_31574(ModItems.DIMENSIONAL_POCKET)) {
            return null;
        }
        class_2338 storagePos = infiniteItem.method_58694(ModDataComponentTypes.LINKED_CHEST);
        class_2960 dimension = infiniteItem.method_58694(ModDataComponentTypes.SERVERWORLD);
        List<Integer> intraGroupPointers = infiniteItem.method_58694(ModDataComponentTypes.INTRA_GROUP_POINTERS);
        Integer interGroupPointer = infiniteItem.method_58694(ModDataComponentTypes.INTER_GROUP_POINTER);
        Boolean safeMode = infiniteItem.method_58695(ModDataComponentTypes.SAFE_MODE, false);

        if (storagePos == null || dimension == null || intraGroupPointers == null || interGroupPointer == null) {;
            return null;
        }

        class_3218 targetWorld = server.method_3847(class_5321.method_29179(class_7924.field_41223, dimension));
        if (targetWorld == null || !targetWorld.method_8477(storagePos)) {
            return null;
        }

        return new DimensionalPocketItem.DimensionalPocketData(storagePos, dimension, targetWorld, intraGroupPointers, interGroupPointer, safeMode);
    }

    private static class_1263 getDeposit(class_3218 targetWorld, class_2338 storagePos) {
        class_2680 blockState = targetWorld.method_8320(storagePos);
        class_2248 inventoryBlock = blockState.method_26204();
        class_1263 deposit = null;

        if (inventoryBlock instanceof class_2281 chest) {
            deposit = class_2281.method_17458(chest, blockState, targetWorld, storagePos, true);
        }
        if (deposit == null && targetWorld.method_8321(storagePos) instanceof class_1263 otherInventory) {
            deposit = otherInventory;
        }
        return deposit;
    }

    private static boolean canMergeItems(class_1799 first, class_1799 second) {
        return first.method_7947() <= first.method_7914() && class_1799.method_31577(first, second);
    }

    private static StacksToShow getStacksToShow(class_1799 dimensionalPocket, class_1263 deposit, int interGroupPointer, int currentIntraIndex, boolean safeMode) {
        List<Integer> group = dimensionalPocket.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(interGroupPointer)));
        if (group == null || group.isEmpty()) {
            return new StacksToShow(class_1799.field_8037, 0, class_1799.field_8037, 0, class_1799.field_8037, 0);
        }
        int groupSize = group.size();
        currentIntraIndex = Math.floorMod(currentIntraIndex, groupSize);

        class_1799 mainStack = getStackFromInventory(deposit, group.get(currentIntraIndex));
        int mainStackCount = mainStack.method_7947();

        class_1799 nextStack = mainStack;
        int nextStackCount = mainStackCount;

        for (int i = 1 ; i < groupSize; i++) {
            int newPointer = Math.floorMod(currentIntraIndex + i, groupSize);
            class_1799 currentStack = getStackFromInventory(deposit, group.get(newPointer));

            if (currentStack.method_7960()) {
                continue;
            }

            if (canMergeItems(mainStack, currentStack)) {
                mainStackCount += currentStack.method_7947();
                continue;
            }

            if (canMergeItems(mainStack, nextStack) && currentStack.method_7947() > (safeMode ? 1 : 0)) {
                nextStack = currentStack;
                nextStackCount = currentStack.method_7947();
                continue;
            }

            if (canMergeItems(nextStack, currentStack)) {
                nextStackCount += currentStack.method_7947();
            }
        }

        class_1799 prevStack = mainStack;
        int prevStackCount = mainStackCount;

        for (int i = 1; i < groupSize; i++) {
            int newPointer = Math.floorMod(currentIntraIndex - i, groupSize);
            class_1799 currentStack = getStackFromInventory(deposit, group.get(newPointer));

            if (currentStack.method_7960()) {
                continue;
            }

            if (canMergeItems(mainStack, currentStack)) {
                continue;
            }

            if (canMergeItems(mainStack, prevStack) && currentStack.method_7947() > (safeMode ? 1 : 0)) {
                prevStack = currentStack;
                prevStackCount = currentStack.method_7947();
                continue;
            }

            // No quiero que el proximo y el anterior sean el mismo stack
            if (canMergeItems(prevStack, nextStack) && !canMergeItems(prevStack, currentStack) && !canMergeItems(mainStack, currentStack) && currentStack.method_7947() > (safeMode ? 1 :0)) {
                prevStack = currentStack;
                prevStackCount = currentStack.method_7947();
                continue;
            }

            if (canMergeItems(prevStack, currentStack)) {
                prevStackCount += currentStack.method_7947();
            }
        }

        return new StacksToShow(prevStack, prevStackCount, mainStack, mainStackCount, nextStack, nextStackCount);
    }

    private record StacksToShow(class_1799 prevStack, Integer countPrevStack,
                                class_1799 currentStack, Integer countCurrentStack,
                                class_1799 nextStack, Integer countNextStack) {

    }
}