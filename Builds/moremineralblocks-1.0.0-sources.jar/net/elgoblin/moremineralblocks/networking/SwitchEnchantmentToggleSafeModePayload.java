package net.elgoblin.moremineralblocks.networking;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SwitchEnchantmentToggleSafeModePayload() implements class_8710 {
    public static final class_9154<SwitchEnchantmentToggleSafeModePayload> ID = new class_9154<>(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "switch_enchantments_toggle_safe_mode_payload"));
    public static final class_9139<class_9129, SwitchEnchantmentToggleSafeModePayload> CODEC = class_9139.method_56431(new SwitchEnchantmentToggleSafeModePayload());

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
