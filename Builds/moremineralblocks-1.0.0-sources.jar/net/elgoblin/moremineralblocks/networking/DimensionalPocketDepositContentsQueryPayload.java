package net.elgoblin.moremineralblocks.networking;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record DimensionalPocketDepositContentsQueryPayload(class_1799 itemStack) implements class_8710 {
    public static final class_9154<DimensionalPocketDepositContentsQueryPayload> ID = new class_9154<>(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "dimensional_pocket_deposit_contents_query_payload"));
    public static final class_9139<class_9129, DimensionalPocketDepositContentsQueryPayload> CODEC = class_9139.method_56434(
            class_1799.field_49268, DimensionalPocketDepositContentsQueryPayload::itemStack,
            DimensionalPocketDepositContentsQueryPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
