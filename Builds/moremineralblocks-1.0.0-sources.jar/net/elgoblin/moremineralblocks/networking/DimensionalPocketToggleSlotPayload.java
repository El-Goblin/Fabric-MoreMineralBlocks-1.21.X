package net.elgoblin.moremineralblocks.networking;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record DimensionalPocketToggleSlotPayload(int targetSlotId, int clickedSlotId, int colorIndex) implements class_8710 {

    public static final class_8710.class_9154<DimensionalPocketToggleSlotPayload> ID = new class_8710.class_9154<>(
            class_2960.method_60655(MoreMineralBlocks.MOD_ID, "dimensional_pocket_toggle_slot_payload")
    );

    public static final class_9139<class_9129, DimensionalPocketToggleSlotPayload> CODEC = class_9139.method_56436(
            class_9135.field_48550, DimensionalPocketToggleSlotPayload::targetSlotId,
            class_9135.field_48550, DimensionalPocketToggleSlotPayload::clickedSlotId,
            class_9135.field_48550, DimensionalPocketToggleSlotPayload::colorIndex,
            DimensionalPocketToggleSlotPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
