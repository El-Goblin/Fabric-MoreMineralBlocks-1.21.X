package net.elgoblin.moremineralblocks.networking;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.fabricmc.fabric.impl.recipe.ingredient.OptionalCustomIngredientPacketCodec;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record DimensionalPocketDepositContentsResponsePayload(class_1799 mainStack, Integer mainCount,
                                                              class_1799 sameGroupPrevStack,
                                                              class_1799 sameGroupNextStack,
                                                              class_1799 prevGroupStack, Integer prevGroupIndex,
                                                              class_1799 nextGroupStack, Integer nextGroupIndex) implements class_8710 {
    public static final class_9154<DimensionalPocketDepositContentsResponsePayload> ID = new class_9154<>(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "dimensional_pocket_deposit_contents_response_payload"));
    public static final class_9139<class_9129, DimensionalPocketDepositContentsResponsePayload> CODEC = class_9139.method_65036(
            class_1799.field_49268, DimensionalPocketDepositContentsResponsePayload::mainStack,
            class_9135.field_49675, DimensionalPocketDepositContentsResponsePayload::mainCount,
            class_1799.field_49268, DimensionalPocketDepositContentsResponsePayload::sameGroupPrevStack,
            class_1799.field_49268, DimensionalPocketDepositContentsResponsePayload::sameGroupNextStack,
            class_1799.field_49268, DimensionalPocketDepositContentsResponsePayload::prevGroupStack,
            class_9135.field_49675, DimensionalPocketDepositContentsResponsePayload::prevGroupIndex,
            class_1799.field_49268, DimensionalPocketDepositContentsResponsePayload::nextGroupStack,
            class_9135.field_49675, DimensionalPocketDepositContentsResponsePayload::nextGroupIndex,
            DimensionalPocketDepositContentsResponsePayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
