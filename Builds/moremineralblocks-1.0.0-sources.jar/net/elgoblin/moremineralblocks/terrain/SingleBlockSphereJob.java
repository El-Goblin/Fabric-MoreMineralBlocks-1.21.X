package net.elgoblin.moremineralblocks.terrain;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;

public class SingleBlockSphereJob implements TerrainJob{
    private Queue<int[]> advanceX;
    private Queue<int[]> advanceZ;
    private Queue<int[]> advanceEquals;
    private final class_1937 world;
    private final class_1657 player;
    private final class_2338 center;
    private final int radius;
    private final int radiusSquared;
    private class_2248 toPlace;
    int blocksAdvanced;
//    ProtectorManager protectorManager;

    public SingleBlockSphereJob(class_1937 world, class_1657 player, class_2338 center, int radius, class_2248 toPlace) {
        this.world = world;
        this.center = center;
        this.radius = radius;
        this.radiusSquared = radius * radius;
        this.toPlace = toPlace;
        this.blocksAdvanced = 0;
        this.player = player;

//        if (world.getServer() != null) {
//            protectorManager = ProtectorManager.getProtectorManager(world.getServer());
//        }

        this.advanceX = new ArrayDeque<>();
        this.advanceZ = new ArrayDeque<>();
        this.advanceEquals = new ArrayDeque<>();
    }

    private int breakX4(class_2338.class_2339 positionToModify, int[] advanceDelta) {
        int blocksBroken = 0;
        // Romper X positivo y Z positivo
        positionToModify.method_10103(center.method_10263() + advanceDelta[0], center.method_10264() + advanceDelta[1], center.method_10260() + advanceDelta[2]);
        if (!world.method_8320(positionToModify).method_26215()) {
            world.method_8652(positionToModify, toPlace.method_9564(), 50);
            blocksBroken++;
        }
        // Romper X negativo y Z positivo
        positionToModify.method_10103(center.method_10263() - advanceDelta[0], center.method_10264() + advanceDelta[1], center.method_10260() + advanceDelta[2]);
        if (!world.method_8320(positionToModify).method_26215()) {
            world.method_8652(positionToModify, toPlace.method_9564(), 50);
            blocksBroken++;
        }
        // Romper X positivo y Z negativo
        positionToModify.method_10103(center.method_10263() + advanceDelta[0], center.method_10264() + advanceDelta[1], center.method_10260() - advanceDelta[2]);
        if (!world.method_8320(positionToModify).method_26215()) {
            world.method_8652(positionToModify, toPlace.method_9564(), 50);
            blocksBroken++;
        }
        // Romper X negativo y Z negativo
        positionToModify.method_10103(center.method_10263() - advanceDelta[0], center.method_10264() + advanceDelta[1], center.method_10260() - advanceDelta[2]);
        if (!world.method_8320(positionToModify).method_26215()) {
            world.method_8652(positionToModify, toPlace.method_9564(), 50);
            blocksBroken++;
        }
                return blocksBroken;
    }

    public boolean process(int maxBlockOperations) {
        int blocksProcessed = 0;

        class_2338.class_2339 positionToModify = new class_2338.class_2339();

        while (blocksAdvanced <= radius || (blocksProcessed < maxBlockOperations && !(advanceX.isEmpty() && advanceZ.isEmpty()))) {
            blocksProcessed += processY(positionToModify);
            blocksProcessed += processX(positionToModify);
            for (int i = 0; i <advanceZ.size()/2+5 ; i++) {
                blocksProcessed += processZ(positionToModify);
            }
            blocksProcessed += processEquals(positionToModify);
        }
        if (advanceX.isEmpty() && advanceZ.isEmpty()) {
            player.method_7353(class_2561.method_30163(String.format("%d", radius)), false);
            return true;
        }
        return false;
    }

    private int processY(class_2338.class_2339 positionToModify) {
        if (blocksAdvanced <= radius) {
            positionToModify.method_10103(center.method_10263(), center.method_10264() + blocksAdvanced, center.method_10260());
            if (!world.method_8320(positionToModify).method_26215()) {
                world.method_8652(positionToModify.method_10103(center.method_10263(), center.method_10264() + blocksAdvanced, center.method_10260()), toPlace.method_9564(), 50);
            }
            positionToModify.method_10103(center.method_10263(), center.method_10264() - blocksAdvanced, center.method_10260());
            if (!world.method_8320(positionToModify).method_26215()) {
                world.method_8652(positionToModify.method_10103(center.method_10263(), center.method_10264() - blocksAdvanced, center.method_10260()), toPlace.method_9564(), 50);
            }
            // En todas las iteraciones subo en Y 1 vez. Si pude subir en Y, sumo en X
            advanceX.add(new int[]{1, blocksAdvanced, 0});
            blocksAdvanced++;
            return 2;
        }
        return 0;
    }

    private int processX(class_2338.class_2339 positionToModify) {
        if (!advanceX.isEmpty()) {
            int blocksBroken = 0;
            int[] advanceDelta = advanceX.poll();

            // Z siempre es 0 aca
            if ((advanceDelta[0] + 1) * (advanceDelta[0] + 1) + advanceDelta[1] * advanceDelta[1] <= radiusSquared) {
                advanceX.add(new int[] {advanceDelta[0]+1, advanceDelta[1], 0});
            }
            // Z siempre es 1 aca
            if (advanceDelta[0] * advanceDelta[0] + advanceDelta[1] * advanceDelta[1] + 1 <= radiusSquared) {
                if (advanceDelta[0] == 1) {
                    advanceEquals.add(new int[] {1, advanceDelta[1], 1});
                }
                else {
                    advanceZ.add(new int[] {advanceDelta[0], advanceDelta[1], 1});
                }
            }

            // Romper X positivo
            positionToModify.method_10103(center.method_10263() + advanceDelta[0], center.method_10264() + advanceDelta[1], center.method_10260());
            if (!world.method_8320(positionToModify).method_26215()) {
                world.method_8652(positionToModify, toPlace.method_9564(), 50);
                blocksBroken++;
            }
            // Romper X negativo
            positionToModify.method_10103(center.method_10263() - advanceDelta[0], center.method_10264() + advanceDelta[1], center.method_10260());
            if (!world.method_8320(positionToModify).method_26215()) {
                world.method_8652(positionToModify, toPlace.method_9564(), 50);
                blocksBroken++;
            }
            // Romper Z positivo
            positionToModify.method_10103(center.method_10263(), center.method_10264() + advanceDelta[1], center.method_10260() + advanceDelta[0]);
            if (!world.method_8320(positionToModify).method_26215()) {
                world.method_8652(positionToModify, toPlace.method_9564(), 50);
                blocksBroken++;
            }
            // Romper Z negativo
            positionToModify.method_10103(center.method_10263(), center.method_10264() + advanceDelta[1], center.method_10260() - advanceDelta[0]);
            if (!world.method_8320(positionToModify).method_26215()) {
                world.method_8652(positionToModify, toPlace.method_9564(), 50);
                blocksBroken++;
            }

            advanceDelta[1] = -advanceDelta[1];

            // Romper X positivo
            positionToModify.method_10103(center.method_10263() + advanceDelta[0], center.method_10264() + advanceDelta[1], center.method_10260());
            if (!world.method_8320(positionToModify).method_26215()) {
                world.method_8652(positionToModify, toPlace.method_9564(), 50);
                blocksBroken++;
            }
            // Romper X negativo
            positionToModify.method_10103(center.method_10263() - advanceDelta[0], center.method_10264() + advanceDelta[1], center.method_10260());
            if (!world.method_8320(positionToModify).method_26215()) {
                world.method_8652(positionToModify, toPlace.method_9564(), 50);
                blocksBroken++;
            }
            // Romper Z positivo
            positionToModify.method_10103(center.method_10263(), center.method_10264() + advanceDelta[1], center.method_10260() + advanceDelta[0]);
            if (!world.method_8320(positionToModify).method_26215()) {
                world.method_8652(positionToModify, toPlace.method_9564(), 50);
                blocksBroken++;
            }
            // Romper Z negativo
            positionToModify.method_10103(center.method_10263(), center.method_10264() + advanceDelta[1], center.method_10260() - advanceDelta[0]);
            if (!world.method_8320(positionToModify).method_26215()) {
                world.method_8652(positionToModify, toPlace.method_9564(), 50);
                blocksBroken++;
            }

            return blocksBroken;
        }
        return 0;
    }

    private int processZ(class_2338.class_2339 positionToModify) {
        if (!advanceZ.isEmpty()) {
            // advanceDelta = {DeltaX, DeltaY, DeltaZ}
            int[] advanceDelta = advanceZ.poll();
            int blocksBroken = 0;

            // Agrego bloques en caso de poder seguir avanzando
            if (advanceDelta[0] * advanceDelta[0] + advanceDelta[1] * advanceDelta[1] + (advanceDelta[2] + 1) * (advanceDelta[2] + 1) <= radiusSquared) {
                int[] newDelta = new int[] {advanceDelta[0], advanceDelta[1], advanceDelta[2] + 1};
                if (advanceDelta[0] == advanceDelta[2] + 1) {
                    advanceEquals.add(newDelta);
                }
                else {
                    advanceZ.add(newDelta);
                }
            }

            blocksBroken += breakX4(positionToModify, advanceDelta);
            advanceDelta[1] = -advanceDelta[1];
            blocksBroken += breakX4(positionToModify, advanceDelta);
            advanceDelta = new int[] {advanceDelta[2], advanceDelta[1], advanceDelta[0]};
            blocksBroken += breakX4(positionToModify, advanceDelta);
            advanceDelta[1] = -advanceDelta[1];
            blocksBroken += breakX4(positionToModify, advanceDelta);

            return blocksBroken;
        }
        return 0;
    }

    private int processEquals(class_2338.class_2339 positionToModify) {
        if (!advanceEquals.isEmpty()) {
            // advanceDelta = {DeltaX, DeltaY, DeltaZ}
            int[] advanceDelta = advanceEquals.poll();
            int blocksBroken = 0;

            // No se agregan bloques nuevos porque van a ser procesados por la segunda iteracion del for de los Z

            blocksBroken += breakX4(positionToModify, advanceDelta);
            advanceDelta[1] = -advanceDelta[1];
            blocksBroken += breakX4(positionToModify, advanceDelta);

            return  blocksBroken;
        }
        return 0;
    }
}
