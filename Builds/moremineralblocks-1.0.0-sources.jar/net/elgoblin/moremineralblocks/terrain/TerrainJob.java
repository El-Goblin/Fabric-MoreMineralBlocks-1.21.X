package net.elgoblin.moremineralblocks.terrain;

import java.util.ArrayDeque;
import java.util.Queue;

public interface TerrainJob {
    public boolean process(int maxBlockOperations);
}