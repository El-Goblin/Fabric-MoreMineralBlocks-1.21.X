package net.elgoblin.moremineralblocks.block.custom;

import com.mojang.serialization.MapCodec;
import net.elgoblin.moremineralblocks.block.entity.custom.ProtectorBlockEntity;
import net.elgoblin.moremineralblocks.util.ProtectorManager;
import net.minecraft.block.*;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

public class ProtectorBlock extends class_2237 implements class_2343 {
    public ProtectorBlock(class_2251 settings) {
        super(settings);
    }

    public static final MapCodec<ProtectorBlock> field_46280 = ProtectorBlock.method_54094(ProtectorBlock::new);

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ProtectorBlockEntity(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

        @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        if (!world.method_8608()) {
            MinecraftServer server = world.method_8503();
            if (server != null) {
                ProtectorManager protectorManager = ProtectorManager.getProtectorManager(world.method_8503());

                ProtectorManager.Interval3i protectedArea = new ProtectorManager.Interval3i(pos, 64, 64, 64);
                protectorManager.addInterval(protectedArea);
            }

        }

        super.method_9567(world, pos, state, placer, itemStack);
    }


    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof ProtectorBlockEntity protector) {
            protector.method_11012();
        }

        return super.method_9576(world, pos, state, player);
    }

    @Override
    public void method_9585(class_1936 world, class_2338 pos, class_2680 state) {

        if (!world.method_8608()) {
            MinecraftServer server = world.method_8503();
            if (server != null) {
                ProtectorManager protectorManager = ProtectorManager.getProtectorManager(world.method_8503());

                ProtectorManager.Interval3i protectedArea = new ProtectorManager.Interval3i(pos, 64, 64, 64);
                protectorManager.remove(protectedArea);
            }
        }

        super.method_9585(world, pos, state);
    }
}
