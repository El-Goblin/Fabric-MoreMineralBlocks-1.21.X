package net.elgoblin.moremineralblocks.block.custom;

import com.mojang.serialization.MapCodec;
import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.block.entity.custom.ProtectorBlockEntity;
//import net.elgoblin.moremineralblocks.util.ProtectorManager;
import net.minecraft.block.*;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

public class ProtectorBlock extends class_2237 implements class_2343 {
    public ProtectorBlock(class_2251 settings) {
        super(settings);
    }

    public static final MapCodec<ProtectorBlock> field_46280 = ProtectorBlock.method_54094(ProtectorBlock::new);

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ProtectorBlockEntity(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    //    @Override
//    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack itemStack) {
//        if (!world.isClient()) {
//            MinecraftServer server = world.getServer();
//            if (server != null) {
//                ProtectorManager protectorManager = ProtectorManager.getProtectorManager(world.getServer());
//
//                ProtectorManager.Interval3i protectedArea = new ProtectorManager.Interval3i(pos, 64, 64, 64);
//                protectorManager.addInterval(protectedArea);
//            }
//
//        }
//
//        super.onPlaced(world, pos, state, placer, itemStack);
//    }


//    @Override
//    public BlockState onBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
//        BlockEntity blockEntity = world.getBlockEntity(pos);
//        if (blockEntity instanceof ProtectorBlockEntity protector) {
//            protector.markRemoved();
//        }
//
//        return super.onBreak(world, pos, state, player);
//    }

//    @Override
//    public void onBroken(WorldAccess world, BlockPos pos, BlockState state) {
//
//        if (!world.isClient()) {
//            MinecraftServer server = world.getServer();
//            if (server != null) {
//                ProtectorManager protectorManager = ProtectorManager.getProtectorManager(world.getServer());
//
//                ProtectorManager.Interval3i protectedArea = new ProtectorManager.Interval3i(pos, 64, 64, 64);
//                protectorManager.remove(protectedArea);
//            }
//        }
//
//        super.onBroken(world, pos, state);
//    }
}
