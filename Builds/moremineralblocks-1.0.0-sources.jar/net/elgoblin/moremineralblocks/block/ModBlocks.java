package net.elgoblin.moremineralblocks.block;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.block.custom.ProtectorBlock;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2378;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8177;

public class ModBlocks {

    /*public static final Block PINK_GARNET_BLOCK = registerBlock("pink_garnet_block",
            new Block(AbstractBlock.Settings.create()
                    .strength(4f).requiresTool().sounds(BlockSoundGroup.AMETHYST_BLOCK)));

    public static final Block RAW_PINK_GARNET_BLOCK = registerBlock("raw_pink_garnet_block",
            new Block(AbstractBlock.Settings.create().strength(3f).requiresTool()));

    public static final Block PINK_GARNET_ORE = registerBlock("pink_garnet_ore",
            new ExperienceDroppingBlock(UniformIntProvider.create(2,5), AbstractBlock.Settings.create().strength(3f).requiresTool()));

    public static final Block PINK_GARNET_DEEPSLATE_ORE = registerBlock("pink_garnet_deepslate_ore",
            new ExperienceDroppingBlock(UniformIntProvider.create(3,6), AbstractBlock.Settings.create().strength(4f).requiresTool().sounds(BlockSoundGroup .DEEPSLATE)));

    public static final Block MAGIC_BLOCK = registerBlock("magic_block", new MagicBlock(AbstractBlock.Settings.create().strength(1).requiresTool()));

    // ----------------------

    public static final Block PINK_GARNET_STAIRS = registerBlock("pink_garnet_stairs",
            new StairsBlock(ModBlocks.PINK_GARNET_BLOCK.getDefaultState(),
                    AbstractBlock.Settings.create().strength(2).requiresTool()));

    public static final Block PINK_GARNET_SLAB = registerBlock("pink_garnet_slab",
            new SlabBlock(AbstractBlock.Settings.create().strength(2).requiresTool()));



    public static final Block PINK_GARNET_BUTTON = registerBlock("pink_garnet_button",
            new ButtonBlock(BlockSetType.IRON, 2, AbstractBlock.Settings.create().strength(2).requiresTool().noCollision()));

    public static final Block PINK_GARNET_PRESSURE_PLATE = registerBlock("pink_garnet_pressure_plate",
            new PressurePlateBlock(BlockSetType.IRON, AbstractBlock.Settings.create().strength(2).requiresTool()));



    public static final Block PINK_GARNET_FENCE = registerBlock("pink_garnet_fence",
            new FenceBlock(AbstractBlock.Settings.create().strength(2).requiresTool()));

    public static final Block PINK_GARNET_FENCE_GATE = registerBlock("pink_garnet_fence_gate",
            new FenceGateBlock(WoodType.ACACIA, AbstractBlock.Settings.create().strength(2).requiresTool()));

    public static final Block PINK_GARNET_WALL = registerBlock("pink_garnet_wall",
            new WallBlock(AbstractBlock.Settings.create().strength(2).requiresTool()));

     */

    private static class_2498 METAL = class_2498.field_11533;
    private static class_2498 AMETHYST = class_2498.field_27197;
    private static class_2498 GLASS = class_2498.field_11537;

    private record SettingsPack(float strength, float resistance, boolean requiresTool, class_2498 soundGroup) {}

    static SettingsPack goldPack = new SettingsPack(3.0F, 6.0F, true, METAL);
    static SettingsPack diamondPack = new SettingsPack(5.0F, 6.0F, true, METAL);
    static SettingsPack ironPack = new SettingsPack(5.0F, 6.0F, true, METAL);
    static SettingsPack emeraldPack = new SettingsPack(5.0F, 6.0F, true, METAL);
    static SettingsPack amethystPack = new SettingsPack(1.5F, -1F, true, AMETHYST);
    static SettingsPack lapisPack = new SettingsPack(3F, 3F, true, null);
    static SettingsPack coalPack = new SettingsPack(5F, 6F, true, null);
    static SettingsPack calcitePack = new SettingsPack(0.75F, -1F, true, class_2498.field_27203);
    static SettingsPack netheritePack = new SettingsPack(50F, 1200F, true, class_2498.field_22150);
    static SettingsPack redstonePack = new SettingsPack(5F, 6F, true, METAL);
    static SettingsPack obsidianPack = new SettingsPack(50F, 1200F, true, null);
    static SettingsPack bedrockPack = new SettingsPack(-1F, 3600000F, false, null);
    static SettingsPack sculkPack = new SettingsPack(0.2F, -1F, false, class_2498.field_37644);
    static SettingsPack packedIcePack = new SettingsPack(0.5F, -1F, false, GLASS);
    static SettingsPack blueIcePack = new SettingsPack(2.8F, -1F, false, GLASS);
    static SettingsPack icePack = new SettingsPack(0.5F, -1F, false, GLASS);
    static SettingsPack deepslateEmeraldOrePack = new SettingsPack(4.5F, 3.0F, true, class_2498.field_29033);
    static SettingsPack prismarinePack = new SettingsPack(1.5F, 6.0F, true, null);

    private static class_4970.class_2251 abstractBlockSettings(String name, SettingsPack settings) {
        class_4970.class_2251 blockSettings = class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name)));
        if (settings.strength != -1F) { blockSettings.method_9632(settings.strength);}
        if (settings.resistance != -1F) { blockSettings.method_36558(settings.resistance);}
        if (settings.requiresTool) { blockSettings.method_29292();}
        if (settings.soundGroup != null) { blockSettings.method_9626(settings.soundGroup);}
        return blockSettings;
    }

    private static class_4970.class_2251 abstractBlockSettings(String name) {
        return class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name)));
    }

    // GOLD BLOCKS

    public static final class_2248 GOLD_STAIRS = registerBlock("gold_stairs",
            new class_2510(class_2246.field_10205.method_9564(),
                    abstractBlockSettings("gold_stairs", goldPack)));

    public static final class_2248 GOLD_SLAB = registerBlock("gold_slab",
            new class_2482(abstractBlockSettings("gold_slab", goldPack)));

    public static final class_2248 GOLD_FENCE = registerBlock("gold_fence",
            new class_2354(abstractBlockSettings("gold_fence", goldPack)));

    public static final class_2248 GOLD_FENCE_GATE = registerBlock("gold_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("gold_fence_gate", goldPack)));

    public static final class_2248 GOLD_WALL = registerBlock("gold_wall",
            new class_2544(abstractBlockSettings("gold_wall", goldPack)));

    public static final class_2248 GOLD_DOOR = registerBlock("gold_door",
            new class_2323(class_8177.field_42820, abstractBlockSettings("gold_door", goldPack)));

    public static final class_2248 GOLD_TRAPDOOR = registerBlock("gold_trapdoor",
            new class_2533(class_8177.field_42820, abstractBlockSettings("gold_trapdoor", goldPack).method_22488()));

    public static final class_2248 POLISHED_GOLD_BLOCK = registerBlock("polished_gold_block",
            new class_2248(abstractBlockSettings("polished_gold_block", goldPack).method_51368(class_2766.field_12644)));

    public static final class_2248 CALCIFIED_GOLD_BLOCK = registerBlock("calcified_gold_block",
            new class_2248(abstractBlockSettings("calcified_gold_block", goldPack)));

    public static final class_2248 GOLD_BRICKS = registerBlock("gold_bricks",
            new class_2248(abstractBlockSettings("gold_bricks", goldPack).method_51368(class_2766.field_12644)));

    public static final class_2248 GOLD_BRICK_STAIRS = registerBlock("gold_brick_stairs",
            new class_2510(ModBlocks.GOLD_BRICKS.method_9564(), abstractBlockSettings("gold_brick_stairs", goldPack)));

    public static final class_2248 GOLD_BRICK_SLAB = registerBlock("gold_brick_slab",
            new class_2482(abstractBlockSettings("gold_brick_slab", goldPack)));

    public static final class_2248 GOLD_BRICK_FENCE = registerBlock("gold_brick_fence",
            new class_2354(abstractBlockSettings("gold_brick_fence", goldPack)));

    public static final class_2248 GOLD_BRICK_FENCE_GATE = registerBlock("gold_brick_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("gold_brick_fence_gate", goldPack)));

    public static final class_2248 GOLD_BRICK_WALL = registerBlock("gold_brick_wall",
            new class_2544(abstractBlockSettings("gold_brick_wall", goldPack)));

    public static final class_2248 CALCIFIED_GOLD_STAIRS = registerBlock("calcified_gold_stairs",
            new class_2510(ModBlocks.CALCIFIED_GOLD_BLOCK.method_9564(), abstractBlockSettings("calcified_gold_stairs", goldPack)));

    public static final class_2248 CALCIFIED_GOLD_SLAB = registerBlock("calcified_gold_slab",
            new class_2482(abstractBlockSettings("calcified_gold_slab", goldPack)));

    public static final class_2248 CALCIFIED_GOLD_FENCE = registerBlock("calcified_gold_fence",
            new class_2354(abstractBlockSettings("calcified_gold_fence", goldPack)));

    public static final class_2248 CALCIFIED_GOLD_FENCE_GATE = registerBlock("calcified_gold_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("calcified_gold_fence_gate", goldPack)));

    public static final class_2248 CALCIFIED_GOLD_WALL = registerBlock("calcified_gold_wall",
            new class_2544(abstractBlockSettings("calcified_gold_wall", goldPack)));

    public static final class_2248 POLISHED_GOLD_STAIRS = registerBlock("polished_gold_stairs",
            new class_2510(ModBlocks.POLISHED_GOLD_BLOCK.method_9564(), abstractBlockSettings("polished_gold_stairs", goldPack)));

    public static final class_2248 POLISHED_GOLD_SLAB = registerBlock("polished_gold_slab",
            new class_2482(abstractBlockSettings("polished_gold_slab", goldPack)));

    public static final class_2248 POLISHED_GOLD_FENCE = registerBlock("polished_gold_fence",
            new class_2354(abstractBlockSettings("polished_gold_fence", goldPack)));

    public static final class_2248 POLISHED_GOLD_FENCE_GATE = registerBlock("polished_gold_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("polished_gold_fence_gate", goldPack)));

    public static final class_2248 POLISHED_GOLD_WALL = registerBlock("polished_gold_wall",
            new class_2544(abstractBlockSettings("polished_gold_wall", goldPack)));

    // DIAMOND BLOCKS

    public static final class_2248 DIAMOND_STAIRS = registerBlock("diamond_stairs",
            new class_2510(class_2246.field_10201.method_9564(), abstractBlockSettings("diamond_stairs", diamondPack)));

    public static final class_2248 DIAMOND_SLAB = registerBlock("diamond_slab",
            new class_2482(abstractBlockSettings("diamond_slab", diamondPack)));

    public static final class_2248 DIAMOND_FENCE = registerBlock("diamond_fence",
            new class_2354(abstractBlockSettings("diamond_fence", diamondPack)));

    public static final class_2248 DIAMOND_FENCE_GATE = registerBlock("diamond_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("diamond_fence_gate", diamondPack)));

    public static final class_2248 DIAMOND_WALL = registerBlock("diamond_wall",
            new class_2544(abstractBlockSettings("diamond_wall", diamondPack)));

    public static final class_2248 DIAMOND_DOOR = registerBlock("diamond_door",
            new class_2323(class_8177.field_42823, abstractBlockSettings("diamond_door", diamondPack).method_22488()));

    public static final class_2248 DIAMOND_TRAPDOOR = registerBlock("diamond_trapdoor",
            new class_2533(class_8177.field_42823, abstractBlockSettings("diamond_trapdoor", diamondPack).method_22488()));

    public static final class_2248 POLISHED_DIAMOND_BLOCK = registerBlock("polished_diamond_block",
            new class_2248(abstractBlockSettings("polished_diamond_block", diamondPack)));

    public static final class_2248 CALCIFIED_DIAMOND_BLOCK = registerBlock("calcified_diamond_block",
            new class_2248(abstractBlockSettings("calcified_diamond_block", diamondPack)));

    public static final class_2248 DIAMOND_BRICKS = registerBlock("diamond_bricks",
            new class_2248(abstractBlockSettings("diamond_bricks", diamondPack)));

    public static final class_2248 DIAMOND_BRICK_STAIRS = registerBlock("diamond_brick_stairs",
            new class_2510(ModBlocks.DIAMOND_BRICKS.method_9564(), abstractBlockSettings("diamond_brick_stairs", diamondPack)));

    public static final class_2248 DIAMOND_BRICK_SLAB = registerBlock("diamond_brick_slab",
            new class_2482(abstractBlockSettings("diamond_brick_slab", diamondPack)));

    public static final class_2248 DIAMOND_BRICK_FENCE = registerBlock("diamond_brick_fence",
            new class_2354(abstractBlockSettings("diamond_brick_fence", diamondPack)));

    public static final class_2248 DIAMOND_BRICK_FENCE_GATE = registerBlock("diamond_brick_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("diamond_brick_fence_gate", diamondPack)));

    public static final class_2248 DIAMOND_BRICK_WALL = registerBlock("diamond_brick_wall",
            new class_2544(abstractBlockSettings("diamond_brick_wall", diamondPack)));

    public static final class_2248 CALCIFIED_DIAMOND_STAIRS = registerBlock("calcified_diamond_stairs",
            new class_2510(ModBlocks.CALCIFIED_DIAMOND_BLOCK.method_9564(), abstractBlockSettings("calcified_diamond_stairs", diamondPack)));

    public static final class_2248 CALCIFIED_DIAMOND_SLAB = registerBlock("calcified_diamond_slab",
            new class_2482(abstractBlockSettings("calcified_diamond_slab", diamondPack)));

    public static final class_2248 CALCIFIED_DIAMOND_FENCE = registerBlock("calcified_diamond_fence",
            new class_2354(abstractBlockSettings("calcified_diamond_fence", diamondPack)));

    public static final class_2248 CALCIFIED_DIAMOND_FENCE_GATE = registerBlock("calcified_diamond_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("calcified_diamond_fence_gate", diamondPack)));

    public static final class_2248 CALCIFIED_DIAMOND_WALL = registerBlock("calcified_diamond_wall",
            new class_2544(abstractBlockSettings("calcified_diamond_wall", diamondPack)));

    public static final class_2248 POLISHED_DIAMOND_STAIRS = registerBlock("polished_diamond_stairs",
            new class_2510(ModBlocks.POLISHED_DIAMOND_BLOCK.method_9564(), abstractBlockSettings("polished_diamond_stairs", diamondPack)));

    public static final class_2248 POLISHED_DIAMOND_SLAB = registerBlock("polished_diamond_slab",
            new class_2482(abstractBlockSettings("polished_diamond_slab", diamondPack)));

    public static final class_2248 POLISHED_DIAMOND_FENCE = registerBlock("polished_diamond_fence",
            new class_2354(abstractBlockSettings("polished_diamond_fence", diamondPack)));

    public static final class_2248 POLISHED_DIAMOND_FENCE_GATE = registerBlock("polished_diamond_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("polished_diamond_fence_gate", diamondPack)));

    public static final class_2248 POLISHED_DIAMOND_WALL = registerBlock("polished_diamond_wall",
            new class_2544(abstractBlockSettings("polished_diamond_wall", diamondPack)));

    // IRON BLOCKS

    public static final class_2248 IRON_STAIRS = registerBlock("iron_stairs",
            new class_2510(class_2246.field_10085.method_9564(), abstractBlockSettings("iron_stairs", ironPack)));

    public static final class_2248 IRON_SLAB = registerBlock("iron_slab",
            new class_2482(abstractBlockSettings("iron_slab", ironPack)));

    public static final class_2248 IRON_FENCE = registerBlock("iron_fence",
            new class_2354(abstractBlockSettings("iron_fence", ironPack)));

    public static final class_2248 IRON_FENCE_GATE = registerBlock("iron_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("iron_fence_gate", ironPack)));

    public static final class_2248 IRON_WALL = registerBlock("iron_wall",
            new class_2544(abstractBlockSettings("iron_wall", ironPack)));

    public static final class_2248 POLISHED_IRON_BLOCK = registerBlock("polished_iron_block",
            new class_2248(abstractBlockSettings("polished_iron_block", ironPack).method_51368(class_2766.field_18284)));

    public static final class_2248 CALCIFIED_IRON_BLOCK = registerBlock("calcified_iron_block",
            new class_2248(abstractBlockSettings("calcified_iron_block", ironPack)));

    public static final class_2248 IRON_BRICKS = registerBlock("iron_bricks",
            new class_2248(abstractBlockSettings("iron_bricks", ironPack).method_51368(class_2766.field_18284)));

    public static final class_2248 IRON_BRICK_STAIRS = registerBlock("iron_brick_stairs",
            new class_2510(ModBlocks.IRON_BRICKS.method_9564(), abstractBlockSettings("iron_brick_stairs", ironPack)));

    public static final class_2248 IRON_BRICK_SLAB = registerBlock("iron_brick_slab",
            new class_2482(abstractBlockSettings("iron_brick_slab", ironPack)));

    public static final class_2248 IRON_BRICK_FENCE = registerBlock("iron_brick_fence",
            new class_2354(abstractBlockSettings("iron_brick_fence", ironPack)));

    public static final class_2248 IRON_BRICK_FENCE_GATE = registerBlock("iron_brick_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("iron_brick_fence_gate", ironPack)));

    public static final class_2248 IRON_BRICK_WALL = registerBlock("iron_brick_wall",
            new class_2544(abstractBlockSettings("iron_brick_wall", ironPack)));

    public static final class_2248 CALCIFIED_IRON_STAIRS = registerBlock("calcified_iron_stairs",
            new class_2510(ModBlocks.CALCIFIED_IRON_BLOCK.method_9564(), abstractBlockSettings("calcified_iron_stairs", ironPack)));

    public static final class_2248 CALCIFIED_IRON_SLAB = registerBlock("calcified_iron_slab",
            new class_2482(abstractBlockSettings("calcified_iron_slab", ironPack)));

    public static final class_2248 CALCIFIED_IRON_FENCE = registerBlock("calcified_iron_fence",
            new class_2354(abstractBlockSettings("calcified_iron_fence", ironPack)));

    public static final class_2248 CALCIFIED_IRON_FENCE_GATE = registerBlock("calcified_iron_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("calcified_iron_fence_gate", ironPack)));

    public static final class_2248 CALCIFIED_IRON_WALL = registerBlock("calcified_iron_wall",
            new class_2544(abstractBlockSettings("calcified_iron_wall", ironPack)));

    public static final class_2248 POLISHED_IRON_STAIRS = registerBlock("polished_iron_stairs",
            new class_2510(ModBlocks.POLISHED_IRON_BLOCK.method_9564(), abstractBlockSettings("polished_iron_stairs", ironPack)));

    public static final class_2248 POLISHED_IRON_SLAB = registerBlock("polished_iron_slab",
            new class_2482(abstractBlockSettings("polished_iron_slab", ironPack)));

    public static final class_2248 POLISHED_IRON_FENCE = registerBlock("polished_iron_fence",
            new class_2354(abstractBlockSettings("polished_iron_fence", ironPack)));

    public static final class_2248 POLISHED_IRON_FENCE_GATE = registerBlock("polished_iron_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("polished_iron_fence_gate", ironPack)));

    public static final class_2248 POLISHED_IRON_WALL = registerBlock("polished_iron_wall",
            new class_2544(abstractBlockSettings("polished_iron_wall", ironPack)));

    // EMERALD BLOCKS

    public static final class_2248 EMERALD_STAIRS = registerBlock("emerald_stairs",
            new class_2510(class_2246.field_10234.method_9564(), abstractBlockSettings("emerald_stairs", emeraldPack)));

    public static final class_2248 EMERALD_SLAB = registerBlock("emerald_slab",
            new class_2482(abstractBlockSettings("emerald_slab", emeraldPack)));

    public static final class_2248 EMERALD_FENCE = registerBlock("emerald_fence",
            new class_2354(abstractBlockSettings("emerald_fence", emeraldPack)));

    public static final class_2248 EMERALD_FENCE_GATE = registerBlock("emerald_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("emerald_fence_gate", emeraldPack)));

    public static final class_2248 EMERALD_WALL = registerBlock("emerald_wall",
            new class_2544(abstractBlockSettings("emerald_wall", emeraldPack)));

    public static final class_2248 EMERALD_DOOR = registerBlock("emerald_door",
            new class_2323(class_8177.field_42823, abstractBlockSettings("emerald_door", emeraldPack).method_22488()));

    public static final class_2248 EMERALD_TRAPDOOR = registerBlock("emerald_trapdoor",
            new class_2533(class_8177.field_42823, abstractBlockSettings("emerald_trapdoor", emeraldPack).method_22488()));

    public static final class_2248 POLISHED_EMERALD_BLOCK = registerBlock("polished_emerald_block",
            new class_2248(abstractBlockSettings("polished_emerald_block", emeraldPack).method_51368(class_2766.field_18287)));

    public static final class_2248 CALCIFIED_EMERALD_BLOCK = registerBlock("calcified_emerald_block",
            new class_2248(abstractBlockSettings("calcified_emerald_block", emeraldPack)));

    public static final class_2248 EMERALD_BRICKS = registerBlock("emerald_bricks",
            new class_2248(abstractBlockSettings("emerald_bricks", emeraldPack).method_51368(class_2766.field_18287)));

    public static final class_2248 CHISELED_EMERALD_BLOCK = registerBlock("chiseled_emerald_block",
            new class_2248(abstractBlockSettings("chiseled_emerald_block", emeraldPack).method_51368(class_2766.field_18287)));

    public static final class_2248 EMERALD_BRICK_STAIRS = registerBlock("emerald_brick_stairs",
            new class_2510(ModBlocks.EMERALD_BRICKS.method_9564(), abstractBlockSettings("emerald_brick_stairs", emeraldPack)));

    public static final class_2248 EMERALD_BRICK_SLAB = registerBlock("emerald_brick_slab",
            new class_2482(abstractBlockSettings("emerald_brick_slab", emeraldPack)));

    public static final class_2248 EMERALD_BRICK_FENCE = registerBlock("emerald_brick_fence",
            new class_2354(abstractBlockSettings("emerald_brick_fence", emeraldPack)));

    public static final class_2248 EMERALD_BRICK_FENCE_GATE = registerBlock("emerald_brick_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("emerald_brick_fence_gate", emeraldPack)));

    public static final class_2248 EMERALD_BRICK_WALL = registerBlock("emerald_brick_wall",
            new class_2544(abstractBlockSettings("emerald_brick_wall", emeraldPack)));

    public static final class_2248 CALCIFIED_EMERALD_STAIRS = registerBlock("calcified_emerald_stairs",
            new class_2510(ModBlocks.CALCIFIED_EMERALD_BLOCK.method_9564(), abstractBlockSettings("calcified_emerald_stairs", emeraldPack)));

    public static final class_2248 CALCIFIED_EMERALD_SLAB = registerBlock("calcified_emerald_slab",
            new class_2482(abstractBlockSettings("calcified_emerald_slab", emeraldPack)));

    public static final class_2248 CALCIFIED_EMERALD_FENCE = registerBlock("calcified_emerald_fence",
            new class_2354(abstractBlockSettings("calcified_emerald_fence", emeraldPack)));

    public static final class_2248 CALCIFIED_EMERALD_FENCE_GATE = registerBlock("calcified_emerald_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("calcified_emerald_fence_gate", emeraldPack)));

    public static final class_2248 CALCIFIED_EMERALD_WALL = registerBlock("calcified_emerald_wall",
            new class_2544(abstractBlockSettings("calcified_emerald_wall", emeraldPack)));

    public static final class_2248 POLISHED_EMERALD_STAIRS = registerBlock("polished_emerald_stairs",
            new class_2510(ModBlocks.POLISHED_EMERALD_BLOCK.method_9564(), abstractBlockSettings("polished_emerald_stairs", emeraldPack)));

    public static final class_2248 POLISHED_EMERALD_SLAB = registerBlock("polished_emerald_slab",
            new class_2482(abstractBlockSettings("polished_emerald_slab", emeraldPack)));

    public static final class_2248 POLISHED_EMERALD_FENCE = registerBlock("polished_emerald_fence",
            new class_2354(abstractBlockSettings("polished_emerald_fence", emeraldPack)));

    public static final class_2248 POLISHED_EMERALD_FENCE_GATE = registerBlock("polished_emerald_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("polished_emerald_fence_gate", emeraldPack)));

    public static final class_2248 POLISHED_EMERALD_WALL = registerBlock("polished_emerald_wall",
            new class_2544(abstractBlockSettings("polished_emerald_wall", emeraldPack)));

    public static final class_2248 CHISELED_EMERALD_STAIRS = registerBlock("chiseled_emerald_stairs",
            new class_2510(ModBlocks.CHISELED_EMERALD_BLOCK.method_9564(), abstractBlockSettings("chiseled_emerald_stairs", emeraldPack)));

    public static final class_2248 CHISELED_EMERALD_SLAB = registerBlock("chiseled_emerald_slab",
            new class_2482(abstractBlockSettings("chiseled_emerald_slab", emeraldPack)));

    public static final class_2248 CHISELED_EMERALD_FENCE = registerBlock("chiseled_emerald_fence",
            new class_2354(abstractBlockSettings("chiseled_emerald_fence", emeraldPack)));

    public static final class_2248 CHISELED_EMERALD_FENCE_GATE = registerBlock("chiseled_emerald_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("chiseled_emerald_fence_gate", emeraldPack)));

    public static final class_2248 CHISELED_EMERALD_WALL = registerBlock("chiseled_emerald_wall",
            new class_2544(abstractBlockSettings("chiseled_emerald_wall", emeraldPack)));

    // AMETHYST BLOCKS

    public static final class_2248 AMETHYST_STAIRS = registerBlock("amethyst_stairs",
            new class_2510(class_2246.field_27159.method_9564(), abstractBlockSettings("amethyst_stairs", amethystPack)));

    public static final class_2248 AMETHYST_SLAB = registerBlock("amethyst_slab",
            new class_2482(abstractBlockSettings("amethyst_slab", amethystPack)));

    public static final class_2248 AMETHYST_FENCE = registerBlock("amethyst_fence",
            new class_2354(abstractBlockSettings("amethyst_fence", amethystPack)));

    public static final class_2248 AMETHYST_FENCE_GATE = registerBlock("amethyst_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("amethyst_fence_gate", amethystPack)));

    public static final class_2248 AMETHYST_WALL = registerBlock("amethyst_wall",
            new class_2544(abstractBlockSettings("amethyst_wall", amethystPack)));

    public static final class_2248 AMETHYST_DOOR = registerBlock("amethyst_door",
            new class_2323(class_8177.field_42823, abstractBlockSettings("amethyst_door", amethystPack).method_22488()));

    public static final class_2248 AMETHYST_TRAPDOOR = registerBlock("amethyst_trapdoor",
            new class_2533(class_8177.field_42823, abstractBlockSettings("amethyst_trapdoor", amethystPack).method_22488()));

    public static final class_2248 POLISHED_AMETHYST_BLOCK = registerBlock("polished_amethyst_block",
            new class_2248(abstractBlockSettings("polished_amethyst_block", amethystPack)));

    public static final class_2248 CALCIFIED_AMETHYST_BLOCK = registerBlock("calcified_amethyst_block",
            new class_2248(abstractBlockSettings("calcified_amethyst_block", amethystPack)));

    public static final class_2248 AMETHYST_BRICKS = registerBlock("amethyst_bricks",
            new class_2248(abstractBlockSettings("amethyst_bricks", amethystPack)));

    public static final class_2248 AMETHYST_BRICK_STAIRS = registerBlock("amethyst_brick_stairs",
            new class_2510(ModBlocks.AMETHYST_BRICKS.method_9564(), abstractBlockSettings("amethyst_brick_stairs", amethystPack)));

    public static final class_2248 AMETHYST_BRICK_SLAB = registerBlock("amethyst_brick_slab",
            new class_2482(abstractBlockSettings("amethyst_brick_slab", amethystPack)));

    public static final class_2248 AMETHYST_BRICK_FENCE = registerBlock("amethyst_brick_fence",
            new class_2354(abstractBlockSettings("amethyst_brick_fence", amethystPack)));

    public static final class_2248 AMETHYST_BRICK_FENCE_GATE = registerBlock("amethyst_brick_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("amethyst_brick_fence_gate", amethystPack)));

    public static final class_2248 AMETHYST_BRICK_WALL = registerBlock("amethyst_brick_wall",
            new class_2544(abstractBlockSettings("amethyst_brick_wall", amethystPack)));

    public static final class_2248 CALCIFIED_AMETHYST_STAIRS = registerBlock("calcified_amethyst_stairs",
            new class_2510(ModBlocks.CALCIFIED_AMETHYST_BLOCK.method_9564(), abstractBlockSettings("calcified_amethyst_stairs", amethystPack)));

    public static final class_2248 CALCIFIED_AMETHYST_SLAB = registerBlock("calcified_amethyst_slab",
            new class_2482(abstractBlockSettings("calcified_amethyst_slab", amethystPack)));

    public static final class_2248 CALCIFIED_AMETHYST_FENCE = registerBlock("calcified_amethyst_fence",
            new class_2354(abstractBlockSettings("calcified_amethyst_fence", amethystPack)));

    public static final class_2248 CALCIFIED_AMETHYST_FENCE_GATE = registerBlock("calcified_amethyst_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("calcified_amethyst_fence_gate", amethystPack)));

    public static final class_2248 CALCIFIED_AMETHYST_WALL = registerBlock("calcified_amethyst_wall",
            new class_2544(abstractBlockSettings("calcified_amethyst_wall", amethystPack)));

    public static final class_2248 POLISHED_AMETHYST_STAIRS = registerBlock("polished_amethyst_stairs",
            new class_2510(ModBlocks.POLISHED_AMETHYST_BLOCK.method_9564(), abstractBlockSettings("polished_amethyst_stairs", amethystPack)));

    public static final class_2248 POLISHED_AMETHYST_SLAB = registerBlock("polished_amethyst_slab",
            new class_2482(abstractBlockSettings("polished_amethyst_slab", amethystPack)));

    public static final class_2248 POLISHED_AMETHYST_FENCE = registerBlock("polished_amethyst_fence",
            new class_2354(abstractBlockSettings("polished_amethyst_fence", amethystPack)));

    public static final class_2248 POLISHED_AMETHYST_FENCE_GATE = registerBlock("polished_amethyst_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("polished_amethyst_fence_gate", amethystPack)));

    public static final class_2248 POLISHED_AMETHYST_WALL = registerBlock("polished_amethyst_wall",
            new class_2544(abstractBlockSettings("polished_amethyst_wall", amethystPack)));


    // LAPIS LAZULI BLOCKS

    public static final class_2248 LAPIS_STAIRS = registerBlock("lapis_stairs",
            new class_2510(class_2246.field_10441.method_9564(), abstractBlockSettings("lapis_stairs", lapisPack)));

    public static final class_2248 LAPIS_SLAB = registerBlock("lapis_slab",
            new class_2482(abstractBlockSettings("lapis_slab", lapisPack)));

    public static final class_2248 LAPIS_FENCE = registerBlock("lapis_fence",
            new class_2354(abstractBlockSettings("lapis_fence", lapisPack)));

    public static final class_2248 LAPIS_FENCE_GATE = registerBlock("lapis_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("lapis_fence_gate", lapisPack)));

    public static final class_2248 LAPIS_WALL = registerBlock("lapis_wall",
            new class_2544(abstractBlockSettings("lapis_wall", lapisPack)));

    public static final class_2248 LAPIS_DOOR = registerBlock("lapis_door",
            new class_2323(class_8177.field_42823, abstractBlockSettings("lapis_door", lapisPack).method_22488()));

    public static final class_2248 LAPIS_TRAPDOOR = registerBlock("lapis_trapdoor",
            new class_2533(class_8177.field_42823, abstractBlockSettings("lapis_trapdoor", lapisPack).method_22488()));

    public static final class_2248 POLISHED_LAPIS_BLOCK = registerBlock("polished_lapis_block",
            new class_2248(abstractBlockSettings("polished_lapis_block", lapisPack)));

    public static final class_2248 CALCIFIED_LAPIS_BLOCK = registerBlock("calcified_lapis_block",
            new class_2248(abstractBlockSettings("calcified_lapis_block", lapisPack)));

    public static final class_2248 LAPIS_BRICKS = registerBlock("lapis_bricks",
            new class_2248(abstractBlockSettings("lapis_bricks", lapisPack)));

    public static final class_2248 LAPIS_BRICK_STAIRS = registerBlock("lapis_brick_stairs",
            new class_2510(ModBlocks.LAPIS_BRICKS.method_9564(), abstractBlockSettings("lapis_brick_stairs", lapisPack)));

    public static final class_2248 LAPIS_BRICK_SLAB = registerBlock("lapis_brick_slab",
            new class_2482(abstractBlockSettings("lapis_brick_slab", lapisPack)));

    public static final class_2248 LAPIS_BRICK_FENCE = registerBlock("lapis_brick_fence",
            new class_2354(abstractBlockSettings("lapis_brick_fence", lapisPack)));

    public static final class_2248 LAPIS_BRICK_FENCE_GATE = registerBlock("lapis_brick_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("lapis_brick_fence_gate", lapisPack)));

    public static final class_2248 LAPIS_BRICK_WALL = registerBlock("lapis_brick_wall",
            new class_2544(abstractBlockSettings("lapis_brick_wall", lapisPack)));

    public static final class_2248 CALCIFIED_LAPIS_STAIRS = registerBlock("calcified_lapis_stairs",
            new class_2510(ModBlocks.CALCIFIED_LAPIS_BLOCK.method_9564(), abstractBlockSettings("calcified_lapis_stairs", lapisPack)));

    public static final class_2248 CALCIFIED_LAPIS_SLAB = registerBlock("calcified_lapis_slab",
            new class_2482(abstractBlockSettings("calcified_lapis_slab", lapisPack)));

    public static final class_2248 CALCIFIED_LAPIS_FENCE = registerBlock("calcified_lapis_fence",
            new class_2354(abstractBlockSettings("calcified_lapis_fence", lapisPack)));

    public static final class_2248 CALCIFIED_LAPIS_FENCE_GATE = registerBlock("calcified_lapis_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("calcified_lapis_fence_gate", lapisPack)));

    public static final class_2248 CALCIFIED_LAPIS_WALL = registerBlock("calcified_lapis_wall",
            new class_2544(abstractBlockSettings("calcified_lapis_wall", lapisPack)));

    public static final class_2248 POLISHED_LAPIS_STAIRS = registerBlock("polished_lapis_stairs",
            new class_2510(ModBlocks.POLISHED_LAPIS_BLOCK.method_9564(), abstractBlockSettings("polished_lapis_stairs", lapisPack)));

    public static final class_2248 POLISHED_LAPIS_SLAB = registerBlock("polished_lapis_slab",
            new class_2482(abstractBlockSettings("polished_lapis_slab", lapisPack)));

    public static final class_2248 POLISHED_LAPIS_FENCE = registerBlock("polished_lapis_fence",
            new class_2354(abstractBlockSettings("polished_lapis_fence", lapisPack)));

    public static final class_2248 POLISHED_LAPIS_FENCE_GATE = registerBlock("polished_lapis_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("polished_lapis_fence_gate", lapisPack)));

    public static final class_2248 POLISHED_LAPIS_WALL = registerBlock("polished_lapis_wall",
            new class_2544(abstractBlockSettings("polished_lapis_wall", lapisPack)));

    // COAL BLOCKS

    public static final class_2248 COAL_STAIRS = registerBlock("coal_stairs",
            new class_2510(class_2246.field_10381.method_9564(), abstractBlockSettings("coal_stairs", coalPack)));

    public static final class_2248 COAL_SLAB = registerBlock("coal_slab",
            new class_2482(abstractBlockSettings("coal_slab", coalPack)));

    public static final class_2248 COAL_FENCE = registerBlock("coal_fence",
            new class_2354(abstractBlockSettings("coal_fence", coalPack)));

    public static final class_2248 COAL_FENCE_GATE = registerBlock("coal_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("coal_fence_gate", coalPack)));

    public static final class_2248 COAL_WALL = registerBlock("coal_wall",
            new class_2544(abstractBlockSettings("coal_wall", coalPack)));

    public static final class_2248 COAL_DOOR = registerBlock("coal_door",
            new class_2323(class_8177.field_42823, abstractBlockSettings("coal_door", coalPack).method_22488()));

    public static final class_2248 COAL_TRAPDOOR = registerBlock("coal_trapdoor",
            new class_2533(class_8177.field_42823, abstractBlockSettings("coal_trapdoor", coalPack).method_22488()));

    public static final class_2248 POLISHED_COAL_BLOCK = registerBlock("polished_coal_block",
            new class_2248(abstractBlockSettings("polished_coal_block", coalPack).method_51368(class_2766.field_12653)));

    public static final class_2248 CALCIFIED_COAL_BLOCK = registerBlock("calcified_coal_block",
            new class_2248(abstractBlockSettings("calcified_coal_block", coalPack)));

    public static final class_2248 COAL_BRICKS = registerBlock("coal_bricks",
            new class_2248(abstractBlockSettings("coal_bricks", coalPack).method_51368(class_2766.field_12653)));

    public static final class_2248 COAL_BRICK_STAIRS = registerBlock("coal_brick_stairs",
            new class_2510(ModBlocks.COAL_BRICKS.method_9564(), abstractBlockSettings("coal_brick_stairs", coalPack)));

    public static final class_2248 COAL_BRICK_SLAB = registerBlock("coal_brick_slab",
            new class_2482(abstractBlockSettings("coal_brick_slab", coalPack)));

    public static final class_2248 COAL_BRICK_FENCE = registerBlock("coal_brick_fence",
            new class_2354(abstractBlockSettings("coal_brick_fence", coalPack)));

    public static final class_2248 COAL_BRICK_FENCE_GATE = registerBlock("coal_brick_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("coal_brick_fence_gate", coalPack)));

    public static final class_2248 COAL_BRICK_WALL = registerBlock("coal_brick_wall",
            new class_2544(abstractBlockSettings("coal_brick_wall", coalPack)));

    public static final class_2248 CALCIFIED_COAL_STAIRS = registerBlock("calcified_coal_stairs",
            new class_2510(ModBlocks.CALCIFIED_COAL_BLOCK.method_9564(), abstractBlockSettings("calcified_coal_stairs", coalPack)));

    public static final class_2248 CALCIFIED_COAL_SLAB = registerBlock("calcified_coal_slab",
            new class_2482(abstractBlockSettings("calcified_coal_slab", coalPack)));

    public static final class_2248 CALCIFIED_COAL_FENCE = registerBlock("calcified_coal_fence",
            new class_2354(abstractBlockSettings("calcified_coal_fence", coalPack)));

    public static final class_2248 CALCIFIED_COAL_FENCE_GATE = registerBlock("calcified_coal_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("calcified_coal_fence_gate", coalPack)));

    public static final class_2248 CALCIFIED_COAL_WALL = registerBlock("calcified_coal_wall",
            new class_2544(abstractBlockSettings("calcified_coal_wall", coalPack)));

    public static final class_2248 POLISHED_COAL_STAIRS = registerBlock("polished_coal_stairs",
            new class_2510(ModBlocks.POLISHED_COAL_BLOCK.method_9564(), abstractBlockSettings("polished_coal_stairs", coalPack)));

    public static final class_2248 POLISHED_COAL_SLAB = registerBlock("polished_coal_slab",
            new class_2482(abstractBlockSettings("polished_coal_slab", coalPack)));

    public static final class_2248 POLISHED_COAL_FENCE = registerBlock("polished_coal_fence",
            new class_2354(abstractBlockSettings("polished_coal_fence", coalPack)));

    public static final class_2248 POLISHED_COAL_FENCE_GATE = registerBlock("polished_coal_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("polished_coal_fence_gate", coalPack)));

    public static final class_2248 POLISHED_COAL_WALL = registerBlock("polished_coal_wall",
            new class_2544(abstractBlockSettings("polished_coal_wall", coalPack)));

    // CALCITE BLOCKS

    public static final class_2248 CALCITE_STAIRS = registerBlock("calcite_stairs",
            new class_2510(class_2246.field_27114.method_9564(), abstractBlockSettings("calcite_stairs", calcitePack)));

    public static final class_2248 CALCITE_SLAB = registerBlock("calcite_slab",
            new class_2482(abstractBlockSettings("calcite_slab", calcitePack)));

    public static final class_2248 CALCITE_FENCE = registerBlock("calcite_fence",
            new class_2354(abstractBlockSettings("calcite_fence", calcitePack)));

    public static final class_2248 CALCITE_FENCE_GATE = registerBlock("calcite_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("calcite_fence_gate", calcitePack)));

    public static final class_2248 CALCITE_WALL = registerBlock("calcite_wall",
            new class_2544(abstractBlockSettings("calcite_wall", calcitePack)));

    // NETHERITE BLOCKS

    public static final class_2248 NETHERITE_STAIRS = registerBlock("netherite_stairs",
            new class_2510(class_2246.field_22108.method_9564(), abstractBlockSettings("netherite_stairs", netheritePack)));

    public static final class_2248 NETHERITE_SLAB = registerBlock("netherite_slab",
            new class_2482(abstractBlockSettings("netherite_slab", netheritePack)));

    public static final class_2248 NETHERITE_FENCE = registerBlock("netherite_fence",
            new class_2354(abstractBlockSettings("netherite_fence", netheritePack)));

    public static final class_2248 NETHERITE_FENCE_GATE = registerBlock("netherite_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("netherite_fence_gate", netheritePack)));

    public static final class_2248 NETHERITE_WALL = registerBlock("netherite_wall",
            new class_2544(abstractBlockSettings("netherite_wall", netheritePack)));

    public static final class_2248 NETHERITE_DOOR = registerBlock("netherite_door",
            new class_2323(class_8177.field_42819, abstractBlockSettings("netherite_door", netheritePack).method_22488()));

    public static final class_2248 NETHERITE_TRAPDOOR = registerBlock("netherite_trapdoor",
            new class_2533(class_8177.field_42819, abstractBlockSettings("netherite_trapdoor", netheritePack).method_22488()));

    public static final class_2248 POLISHED_NETHERITE_BLOCK = registerBlock("polished_netherite_block",
            new class_2248(abstractBlockSettings("polished_netherite_block", netheritePack).method_51368(class_2766.field_12653)));

    public static final class_2248 CALCIFIED_NETHERITE_BLOCK = registerBlock("calcified_netherite_block",
            new class_2248(abstractBlockSettings("calcified_netherite_block", netheritePack)));

    public static final class_2248 NETHERITE_BRICKS = registerBlock("netherite_bricks",
            new class_2248(abstractBlockSettings("netherite_bricks", netheritePack).method_51368(class_2766.field_12653)));

    public static final class_2248 NETHERITE_BRICK_STAIRS = registerBlock("netherite_brick_stairs",
            new class_2510(ModBlocks.NETHERITE_BRICKS.method_9564(), abstractBlockSettings("netherite_brick_stairs", netheritePack)));

    public static final class_2248 NETHERITE_BRICK_SLAB = registerBlock("netherite_brick_slab",
            new class_2482(abstractBlockSettings("netherite_brick_slab", netheritePack)));

    public static final class_2248 NETHERITE_BRICK_FENCE = registerBlock("netherite_brick_fence",
            new class_2354(abstractBlockSettings("netherite_brick_fence", netheritePack)));

    public static final class_2248 NETHERITE_BRICK_FENCE_GATE = registerBlock("netherite_brick_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("netherite_brick_fence_gate", netheritePack)));

    public static final class_2248 NETHERITE_BRICK_WALL = registerBlock("netherite_brick_wall",
            new class_2544(abstractBlockSettings("netherite_brick_wall", netheritePack)));

    public static final class_2248 CALCIFIED_NETHERITE_STAIRS = registerBlock("calcified_netherite_stairs",
            new class_2510(ModBlocks.CALCIFIED_NETHERITE_BLOCK.method_9564(), abstractBlockSettings("calcified_netherite_stairs", netheritePack)));

    public static final class_2248 CALCIFIED_NETHERITE_SLAB = registerBlock("calcified_netherite_slab",
            new class_2482(abstractBlockSettings("calcified_netherite_slab", netheritePack)));

    public static final class_2248 CALCIFIED_NETHERITE_FENCE = registerBlock("calcified_netherite_fence",
            new class_2354(abstractBlockSettings("calcified_netherite_fence", netheritePack)));

    public static final class_2248 CALCIFIED_NETHERITE_FENCE_GATE = registerBlock("calcified_netherite_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("calcified_netherite_fence_gate", netheritePack)));

    public static final class_2248 CALCIFIED_NETHERITE_WALL = registerBlock("calcified_netherite_wall",
            new class_2544(abstractBlockSettings("calcified_netherite_wall", netheritePack)));

    public static final class_2248 POLISHED_NETHERITE_STAIRS = registerBlock("polished_netherite_stairs",
            new class_2510(ModBlocks.POLISHED_NETHERITE_BLOCK.method_9564(), abstractBlockSettings("polished_netherite_stairs", netheritePack)));

    public static final class_2248 POLISHED_NETHERITE_SLAB = registerBlock("polished_netherite_slab",
            new class_2482(abstractBlockSettings("polished_netherite_slab", netheritePack)));

    public static final class_2248 POLISHED_NETHERITE_FENCE = registerBlock("polished_netherite_fence",
            new class_2354(abstractBlockSettings("polished_netherite_fence", netheritePack)));

    public static final class_2248 POLISHED_NETHERITE_FENCE_GATE = registerBlock("polished_netherite_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("polished_netherite_fence_gate", netheritePack)));

    public static final class_2248 POLISHED_NETHERITE_WALL = registerBlock("polished_netherite_wall",
            new class_2544(abstractBlockSettings("polished_netherite_wall", netheritePack)));

    // REDSTONE

    public static final class_2248 REDSTONE_STAIRS = registerBlock("redstone_stairs",
            new class_2510(class_2246.field_10002.method_9564(), abstractBlockSettings("redstone_stairs", redstonePack)));

    public static final class_2248 REDSTONE_SLAB = registerBlock("redstone_slab",
            new class_2482(abstractBlockSettings("redstone_slab", redstonePack)));

    public static final class_2248 REDSTONE_FENCE = registerBlock("redstone_fence",
            new class_2354(abstractBlockSettings("redstone_fence", redstonePack)));

    public static final class_2248 REDSTONE_FENCE_GATE = registerBlock("redstone_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("redstone_fence_gate", redstonePack)));

    public static final class_2248 REDSTONE_WALL = registerBlock("redstone_wall",
            new class_2544(abstractBlockSettings("redstone_wall", redstonePack)));

    public static final class_2248 REDSTONE_DOOR = registerBlock("redstone_door",
            new class_2323(class_8177.field_42823, abstractBlockSettings("redstone_door", redstonePack).method_22488()));

    public static final class_2248 REDSTONE_TRAPDOOR = registerBlock("redstone_trapdoor",
            new class_2533(class_8177.field_42823, abstractBlockSettings("redstone_trapdoor", redstonePack).method_22488()));

    public static final class_2248 POLISHED_REDSTONE_BLOCK = registerBlock("polished_redstone_block",
            new class_2248(abstractBlockSettings("polished_redstone_block", redstonePack).method_51368(class_2766.field_12653)));

    public static final class_2248 CALCIFIED_REDSTONE_BLOCK = registerBlock("calcified_redstone_block",
            new class_2248(abstractBlockSettings("calcified_redstone_block", redstonePack)));

    public static final class_2248 REDSTONE_BRICKS = registerBlock("redstone_bricks",
            new class_2248(abstractBlockSettings("redstone_bricks", redstonePack).method_51368(class_2766.field_12653)));

    public static final class_2248 REDSTONE_BRICK_STAIRS = registerBlock("redstone_brick_stairs",
            new class_2510(ModBlocks.REDSTONE_BRICKS.method_9564(), abstractBlockSettings("redstone_brick_stairs", redstonePack)));

    public static final class_2248 REDSTONE_BRICK_SLAB = registerBlock("redstone_brick_slab",
            new class_2482(abstractBlockSettings("redstone_brick_slab", redstonePack)));

    public static final class_2248 REDSTONE_BRICK_FENCE = registerBlock("redstone_brick_fence",
            new class_2354(abstractBlockSettings("redstone_brick_fence", redstonePack)));

    public static final class_2248 REDSTONE_BRICK_FENCE_GATE = registerBlock("redstone_brick_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("redstone_brick_fence_gate", redstonePack)));

    public static final class_2248 REDSTONE_BRICK_WALL = registerBlock("redstone_brick_wall",
            new class_2544(abstractBlockSettings("redstone_brick_wall", redstonePack)));

    public static final class_2248 CALCIFIED_REDSTONE_STAIRS = registerBlock("calcified_redstone_stairs",
            new class_2510(ModBlocks.CALCIFIED_REDSTONE_BLOCK.method_9564(), abstractBlockSettings("calcified_redstone_stairs", redstonePack)));

    public static final class_2248 CALCIFIED_REDSTONE_SLAB = registerBlock("calcified_redstone_slab",
            new class_2482(abstractBlockSettings("calcified_redstone_slab", redstonePack)));

    public static final class_2248 CALCIFIED_REDSTONE_FENCE = registerBlock("calcified_redstone_fence",
            new class_2354(abstractBlockSettings("calcified_redstone_fence", redstonePack)));

    public static final class_2248 CALCIFIED_REDSTONE_FENCE_GATE = registerBlock("calcified_redstone_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("calcified_redstone_fence_gate", redstonePack)));

    public static final class_2248 CALCIFIED_REDSTONE_WALL = registerBlock("calcified_redstone_wall",
            new class_2544(abstractBlockSettings("calcified_redstone_wall", redstonePack)));

    public static final class_2248 POLISHED_REDSTONE_STAIRS = registerBlock("polished_redstone_stairs",
            new class_2510(ModBlocks.POLISHED_REDSTONE_BLOCK.method_9564(), abstractBlockSettings("polished_redstone_stairs", redstonePack)));

    public static final class_2248 POLISHED_REDSTONE_SLAB = registerBlock("polished_redstone_slab",
            new class_2482(abstractBlockSettings("polished_redstone_slab", redstonePack)));

    public static final class_2248 POLISHED_REDSTONE_FENCE = registerBlock("polished_redstone_fence",
            new class_2354(abstractBlockSettings("polished_redstone_fence", redstonePack)));

    public static final class_2248 POLISHED_REDSTONE_FENCE_GATE = registerBlock("polished_redstone_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("polished_redstone_fence_gate", redstonePack)));

    public static final class_2248 POLISHED_REDSTONE_WALL = registerBlock("polished_redstone_wall",
            new class_2544(abstractBlockSettings("polished_redstone_wall", redstonePack)));

    // OBSIDIAN

    public static final class_2248 OBSIDIAN_STAIRS = registerBlock("obsidian_stairs",
            new class_2510(class_2246.field_10540.method_9564(), abstractBlockSettings("obsidian_stairs", obsidianPack)));

    public static final class_2248 OBSIDIAN_SLAB = registerBlock("obsidian_slab",
            new class_2482(abstractBlockSettings("obsidian_slab", obsidianPack)));

    public static final class_2248 OBSIDIAN_FENCE = registerBlock("obsidian_fence",
            new class_2354(abstractBlockSettings("obsidian_fence", obsidianPack)));

    public static final class_2248 OBSIDIAN_FENCE_GATE = registerBlock("obsidian_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("obsidian_fence_gate", obsidianPack)));

    public static final class_2248 OBSIDIAN_WALL = registerBlock("obsidian_wall",
            new class_2544(abstractBlockSettings("obsidian_wall", obsidianPack)));

    // BEDROCK

    public static final class_2248 BEDROCK_STAIRS = registerBlock("bedrock_stairs",
            new class_2510(class_2246.field_9987.method_9564(), abstractBlockSettings("bedrock_stairs", bedrockPack).method_9632(-1F).method_42327().method_26235(class_2246::method_26114)));

    public static final class_2248 BEDROCK_SLAB = registerBlock("bedrock_slab",
            new class_2482(abstractBlockSettings("bedrock_slab", bedrockPack).method_9632(-1F).method_42327().method_26235(class_2246::method_26114)));

    public static final class_2248 BEDROCK_FENCE = registerBlock("bedrock_fence",
            new class_2354(abstractBlockSettings("bedrock_fence", bedrockPack).method_9632(-1F).method_42327().method_26235(class_2246::method_26114)));

    public static final class_2248 BEDROCK_FENCE_GATE = registerBlock("bedrock_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("bedrock_fence_gate", bedrockPack).method_9632(-1F).method_42327().method_26235(class_2246::method_26114)));

    public static final class_2248 BEDROCK_WALL = registerBlock("bedrock_wall",
            new class_2544(abstractBlockSettings("bedrock_wall", bedrockPack).method_9632(-1F).method_42327().method_26235(class_2246::method_26114)));

    // SCULK

    //TODO add drop table con silk touch unicamente
    public static final class_2248 SCULK_STAIRS = registerBlock("sculk_stairs",
            new class_2510(class_2246.field_37568.method_9564(), abstractBlockSettings("sculk_stairs", sculkPack)));

    public static final class_2248 SCULK_SLAB = registerBlock("sculk_slab",
            new class_2482(abstractBlockSettings("sculk_slab", sculkPack)));

    public static final class_2248 SCULK_FENCE = registerBlock("sculk_fence",
            new class_2354(abstractBlockSettings("sculk_fence", sculkPack)));

    public static final class_2248 SCULK_FENCE_GATE = registerBlock("sculk_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("sculk_fence_gate", sculkPack)));

    public static final class_2248 SCULK_WALL = registerBlock("sculk_wall",
            new class_2544(abstractBlockSettings("sculk_wall", sculkPack)));

    // PACKED_ICE

    public static final class_2248 PACKED_ICE_STAIRS = registerBlock("packed_ice_stairs",
            new class_2510(class_2246.field_10225.method_9564(), abstractBlockSettings("packed_ice_stairs", packedIcePack).method_51368(class_2766.field_12647).method_9628(0.98F)));

    public static final class_2248 PACKED_ICE_SLAB = registerBlock("packed_ice_slab",
            new class_2482(abstractBlockSettings("packed_ice_slab", packedIcePack).method_51368(class_2766.field_12647).method_9628(0.98F)));

    public static final class_2248 PACKED_ICE_FENCE = registerBlock("packed_ice_fence",
            new class_2354(abstractBlockSettings("packed_ice_fence", packedIcePack).method_51368(class_2766.field_12647).method_9628(0.98F)));

    public static final class_2248 PACKED_ICE_FENCE_GATE = registerBlock("packed_ice_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("packed_ice_fence_gate", packedIcePack).method_51368(class_2766.field_12647).method_9628(0.98F)));

    public static final class_2248 PACKED_ICE_WALL = registerBlock("packed_ice_wall",
            new class_2544(abstractBlockSettings("packed_ice_wall", packedIcePack).method_51368(class_2766.field_12647).method_9628(0.98F)));

    // BLUE_ICE

    public static final class_2248 BLUE_ICE_STAIRS = registerBlock("blue_ice_stairs",
            new class_2510(class_2246.field_10384.method_9564(), abstractBlockSettings("blue_ice_stairs", blueIcePack).method_9628(0.989F)));

    public static final class_2248 BLUE_ICE_SLAB = registerBlock("blue_ice_slab",
            new class_2482(abstractBlockSettings("blue_ice_slab", blueIcePack).method_9628(0.989F)));

    public static final class_2248 BLUE_ICE_FENCE = registerBlock("blue_ice_fence",
            new class_2354(abstractBlockSettings("blue_ice_fence", blueIcePack).method_9628(0.989F)));

    public static final class_2248 BLUE_ICE_FENCE_GATE = registerBlock("blue_ice_fence_gate",
            new class_2349(class_4719.field_21676, abstractBlockSettings("blue_ice_fence_gate", blueIcePack).method_9628(0.989F)));

    public static final class_2248 BLUE_ICE_WALL = registerBlock("blue_ice_wall",
            new class_2544(abstractBlockSettings("blue_ice_wall", blueIcePack).method_9628(0.989F)));

    // ICE

    public static final class_2248 ICE_STAIRS = registerBlock("ice_stairs",
            new class_2510(class_2246.field_10295.method_9564(), abstractBlockSettings("ice_stairs", icePack).method_9628(0.98F)));

    public static final class_2248 ICE_SLAB = registerBlock("ice_slab",
            new class_2482(abstractBlockSettings("ice_slab", icePack).method_9628(0.98F)));

    public static final class_2248 ICE_FENCE = registerBlock("ice_fence",
            new class_2354(abstractBlockSettings("ice_fence", icePack).method_9628(0.98F)));

    public static final class_2248 ICE_FENCE_GATE = registerBlock("ice_fence_gate",
            new class_2349(class_4719.field_21679, abstractBlockSettings("ice_fence_gate", icePack).method_9628(0.98F)));

    public static final class_2248 ICE_WALL = registerBlock("ice_wall",
            new class_2544(abstractBlockSettings("ice_wall", icePack).method_9628(0.98F)));

    // DEEPSLATE_EMERALD_ORE

    public static final class_2248 DEEPSLATE_EMERALD_ORE_STAIRS = registerBlock("deepslate_emerald_ore_stairs",
            new class_2510(class_2246.field_29220.method_9564(), abstractBlockSettings("deepslate_emerald_ore_stairs", deepslateEmeraldOrePack)));

    public static final class_2248 DEEPSLATE_EMERALD_ORE_SLAB = registerBlock("deepslate_emerald_ore_slab",
            new class_2482(abstractBlockSettings("deepslate_emerald_ore_slab", deepslateEmeraldOrePack)));

    public static final class_2248 DEEPSLATE_EMERALD_ORE_FENCE = registerBlock("deepslate_emerald_ore_fence",
            new class_2354(abstractBlockSettings("deepslate_emerald_ore_fence", deepslateEmeraldOrePack)));

    public static final class_2248 DEEPSLATE_EMERALD_ORE_FENCE_GATE = registerBlock("deepslate_emerald_ore_fence_gate",
            new class_2349(class_4719.field_21679, abstractBlockSettings("deepslate_emerald_ore_fence_gate", deepslateEmeraldOrePack)));

    public static final class_2248 DEEPSLATE_EMERALD_ORE_WALL = registerBlock("deepslate_emerald_ore_wall",
            new class_2544(abstractBlockSettings("deepslate_emerald_ore_wall", deepslateEmeraldOrePack)));

    // PRISMARINE

    public static final class_2248 PRISMARINE_BRICK_WALL = registerBlock("prismarine_brick_wall",
            new class_2544(abstractBlockSettings("prismarine_brick_wall", prismarinePack)));

    public static final class_2248 DARK_PRISMARINE_WALL = registerBlock("dark_prismarine_wall",
            new class_2544(abstractBlockSettings("dark_prismarine_wall", prismarinePack)));

    // Others

    public static final class_2248 PROTECTOR_BLOCK = registerBlock("protector_block", new ProtectorBlock(abstractBlockSettings("protector_block").method_9629(4f, 6f).method_29292()));


    // Otra funcion de ayuda para registrar bloques nuevos
    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name), block);
    }

    // Funcion de ayuda para registrar bloques nuevos
    private static void registerBlockItem(String name, class_2248 block) {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name),
                new class_1747(block,new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name))).method_63685()));
    }

    public static void registerModBlocks() {
        MoreMineralBlocks.LOGGER.info("Registering Mod Blocks for" + MoreMineralBlocks.MOD_ID);

        // Para agregar bloques a una tab existente de minecraft vanilla en creativo
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries -> {
            //entries.add(ModBlocks.PINK_GARNET_BLOCK);
            //entries.add(ModBlocks.RAW_PINK_GARNET_BLOCK);

            entries.method_45421(ModBlocks.GOLD_STAIRS);
            entries.method_45421(ModBlocks.GOLD_SLAB);
            entries.method_45421(ModBlocks.GOLD_FENCE);
            entries.method_45421(ModBlocks.GOLD_FENCE_GATE);
            entries.method_45421(ModBlocks.GOLD_WALL);
            entries.method_45421(ModBlocks.GOLD_DOOR);
            entries.method_45421(ModBlocks.GOLD_TRAPDOOR);
            entries.method_45421(ModBlocks.POLISHED_GOLD_BLOCK);
            entries.method_45421(ModBlocks.CALCIFIED_GOLD_BLOCK);
            entries.method_45421(ModBlocks.GOLD_BRICKS);


            entries.method_45421(ModBlocks.GOLD_BRICK_STAIRS);
            entries.method_45421(ModBlocks.GOLD_BRICK_SLAB);
            entries.method_45421(ModBlocks.GOLD_BRICK_WALL);
            entries.method_45421(ModBlocks.GOLD_BRICK_FENCE);
            entries.method_45421(ModBlocks.GOLD_BRICK_FENCE_GATE);
            entries.method_45421(ModBlocks.CALCIFIED_GOLD_STAIRS);
            entries.method_45421(ModBlocks.CALCIFIED_GOLD_SLAB);
            entries.method_45421(ModBlocks.CALCIFIED_GOLD_WALL);
            entries.method_45421(ModBlocks.CALCIFIED_GOLD_FENCE);
            entries.method_45421(ModBlocks.CALCIFIED_GOLD_FENCE_GATE);
            entries.method_45421(ModBlocks.POLISHED_GOLD_STAIRS);
            entries.method_45421(ModBlocks.POLISHED_GOLD_SLAB);
            entries.method_45421(ModBlocks.POLISHED_GOLD_WALL);
            entries.method_45421(ModBlocks.POLISHED_GOLD_FENCE);
            entries.method_45421(ModBlocks.POLISHED_GOLD_FENCE_GATE);

            entries.method_45421(ModBlocks.DIAMOND_STAIRS);
            entries.method_45421(ModBlocks.DIAMOND_SLAB);
            entries.method_45421(ModBlocks.DIAMOND_FENCE);
            entries.method_45421(ModBlocks.DIAMOND_FENCE_GATE);
            entries.method_45421(ModBlocks.DIAMOND_WALL);
            entries.method_45421(ModBlocks.DIAMOND_DOOR);
            entries.method_45421(ModBlocks.DIAMOND_TRAPDOOR);
            entries.method_45421(ModBlocks.POLISHED_DIAMOND_BLOCK);
            entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_BLOCK);
            entries.method_45421(ModBlocks.DIAMOND_BRICKS);

            entries.method_45421(ModBlocks.DIAMOND_BRICK_STAIRS);
            entries.method_45421(ModBlocks.DIAMOND_BRICK_SLAB);
            entries.method_45421(ModBlocks.DIAMOND_BRICK_WALL);
            entries.method_45421(ModBlocks.DIAMOND_BRICK_FENCE);
            entries.method_45421(ModBlocks.DIAMOND_BRICK_FENCE_GATE);
            entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_STAIRS);
            entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_SLAB);
            entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_WALL);
            entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_FENCE);
            entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_FENCE_GATE);
            entries.method_45421(ModBlocks.POLISHED_DIAMOND_STAIRS);
            entries.method_45421(ModBlocks.POLISHED_DIAMOND_SLAB);
            entries.method_45421(ModBlocks.POLISHED_DIAMOND_WALL);
            entries.method_45421(ModBlocks.POLISHED_DIAMOND_FENCE);
            entries.method_45421(ModBlocks.POLISHED_DIAMOND_FENCE_GATE);

            entries.method_45421(ModBlocks.IRON_STAIRS);
            entries.method_45421(ModBlocks.IRON_SLAB);
            entries.method_45421(ModBlocks.IRON_FENCE);
            entries.method_45421(ModBlocks.IRON_FENCE_GATE);
            entries.method_45421(ModBlocks.IRON_WALL);
            entries.method_45421(ModBlocks.POLISHED_IRON_BLOCK);
            entries.method_45421(ModBlocks.CALCIFIED_IRON_BLOCK);
            entries.method_45421(ModBlocks.IRON_BRICKS);

            entries.method_45421(ModBlocks.IRON_BRICK_STAIRS);
            entries.method_45421(ModBlocks.IRON_BRICK_SLAB);
            entries.method_45421(ModBlocks.IRON_BRICK_WALL);
            entries.method_45421(ModBlocks.IRON_BRICK_FENCE);
            entries.method_45421(ModBlocks.IRON_BRICK_FENCE_GATE);
            entries.method_45421(ModBlocks.CALCIFIED_IRON_STAIRS);
            entries.method_45421(ModBlocks.CALCIFIED_IRON_SLAB);
            entries.method_45421(ModBlocks.CALCIFIED_IRON_WALL);
            entries.method_45421(ModBlocks.CALCIFIED_IRON_FENCE);
            entries.method_45421(ModBlocks.CALCIFIED_IRON_FENCE_GATE);
            entries.method_45421(ModBlocks.POLISHED_IRON_STAIRS);
            entries.method_45421(ModBlocks.POLISHED_IRON_SLAB);
            entries.method_45421(ModBlocks.POLISHED_IRON_WALL);
            entries.method_45421(ModBlocks.POLISHED_IRON_FENCE);
            entries.method_45421(ModBlocks.POLISHED_IRON_FENCE_GATE);

            entries.method_45421(ModBlocks.EMERALD_STAIRS);
            entries.method_45421(ModBlocks.EMERALD_SLAB);
            entries.method_45421(ModBlocks.EMERALD_FENCE);
            entries.method_45421(ModBlocks.EMERALD_FENCE_GATE);
            entries.method_45421(ModBlocks.EMERALD_WALL);
            entries.method_45421(ModBlocks.EMERALD_DOOR);
            entries.method_45421(ModBlocks.EMERALD_TRAPDOOR);
            entries.method_45421(ModBlocks.CHISELED_EMERALD_BLOCK);
            entries.method_45421(ModBlocks.POLISHED_EMERALD_BLOCK);
            entries.method_45421(ModBlocks.CALCIFIED_EMERALD_BLOCK);
            entries.method_45421(ModBlocks.EMERALD_BRICKS);

            entries.method_45421(ModBlocks.EMERALD_BRICK_STAIRS);
            entries.method_45421(ModBlocks.EMERALD_BRICK_SLAB);
            entries.method_45421(ModBlocks.EMERALD_BRICK_WALL);
            entries.method_45421(ModBlocks.EMERALD_BRICK_FENCE);
            entries.method_45421(ModBlocks.EMERALD_BRICK_FENCE_GATE);
            entries.method_45421(ModBlocks.CALCIFIED_EMERALD_STAIRS);
            entries.method_45421(ModBlocks.CALCIFIED_EMERALD_SLAB);
            entries.method_45421(ModBlocks.CALCIFIED_EMERALD_WALL);
            entries.method_45421(ModBlocks.CALCIFIED_EMERALD_FENCE);
            entries.method_45421(ModBlocks.CALCIFIED_EMERALD_FENCE_GATE);
            entries.method_45421(ModBlocks.POLISHED_EMERALD_STAIRS);
            entries.method_45421(ModBlocks.POLISHED_EMERALD_SLAB);
            entries.method_45421(ModBlocks.POLISHED_EMERALD_WALL);
            entries.method_45421(ModBlocks.POLISHED_EMERALD_FENCE);
            entries.method_45421(ModBlocks.POLISHED_EMERALD_FENCE_GATE);
            entries.method_45421(ModBlocks.CHISELED_EMERALD_STAIRS);
            entries.method_45421(ModBlocks.CHISELED_EMERALD_SLAB);
            entries.method_45421(ModBlocks.CHISELED_EMERALD_WALL);
            entries.method_45421(ModBlocks.CHISELED_EMERALD_FENCE);
            entries.method_45421(ModBlocks.CHISELED_EMERALD_FENCE_GATE);

            entries.method_45421(ModBlocks.LAPIS_STAIRS);
            entries.method_45421(ModBlocks.LAPIS_SLAB);
            entries.method_45421(ModBlocks.LAPIS_FENCE);
            entries.method_45421(ModBlocks.LAPIS_FENCE_GATE);
            entries.method_45421(ModBlocks.LAPIS_WALL);
            entries.method_45421(ModBlocks.LAPIS_DOOR);
            entries.method_45421(ModBlocks.LAPIS_TRAPDOOR);
            entries.method_45421(ModBlocks.POLISHED_LAPIS_BLOCK);
            entries.method_45421(ModBlocks.CALCIFIED_LAPIS_BLOCK);
            entries.method_45421(ModBlocks.LAPIS_BRICKS);

            entries.method_45421(ModBlocks.LAPIS_BRICK_STAIRS);
            entries.method_45421(ModBlocks.LAPIS_BRICK_SLAB);
            entries.method_45421(ModBlocks.LAPIS_BRICK_WALL);
            entries.method_45421(ModBlocks.LAPIS_BRICK_FENCE);
            entries.method_45421(ModBlocks.LAPIS_BRICK_FENCE_GATE);
            entries.method_45421(ModBlocks.CALCIFIED_LAPIS_STAIRS);
            entries.method_45421(ModBlocks.CALCIFIED_LAPIS_SLAB);
            entries.method_45421(ModBlocks.CALCIFIED_LAPIS_WALL);
            entries.method_45421(ModBlocks.CALCIFIED_LAPIS_FENCE);
            entries.method_45421(ModBlocks.CALCIFIED_LAPIS_FENCE_GATE);
            entries.method_45421(ModBlocks.POLISHED_LAPIS_STAIRS);
            entries.method_45421(ModBlocks.POLISHED_LAPIS_SLAB);
            entries.method_45421(ModBlocks.POLISHED_LAPIS_WALL);
            entries.method_45421(ModBlocks.POLISHED_LAPIS_FENCE);
            entries.method_45421(ModBlocks.POLISHED_LAPIS_FENCE_GATE);

            entries.method_45421(ModBlocks.COAL_STAIRS);
            entries.method_45421(ModBlocks.COAL_SLAB);
            entries.method_45421(ModBlocks.COAL_FENCE);
            entries.method_45421(ModBlocks.COAL_FENCE_GATE);
            entries.method_45421(ModBlocks.COAL_WALL);
            entries.method_45421(ModBlocks.COAL_DOOR);
            entries.method_45421(ModBlocks.COAL_TRAPDOOR);
            entries.method_45421(ModBlocks.POLISHED_COAL_BLOCK);
            entries.method_45421(ModBlocks.CALCIFIED_COAL_BLOCK);
            entries.method_45421(ModBlocks.COAL_BRICKS);

            entries.method_45421(ModBlocks.COAL_BRICK_STAIRS);
            entries.method_45421(ModBlocks.COAL_BRICK_SLAB);
            entries.method_45421(ModBlocks.COAL_BRICK_WALL);
            entries.method_45421(ModBlocks.COAL_BRICK_FENCE);
            entries.method_45421(ModBlocks.COAL_BRICK_FENCE_GATE);
            entries.method_45421(ModBlocks.CALCIFIED_COAL_STAIRS);
            entries.method_45421(ModBlocks.CALCIFIED_COAL_SLAB);
            entries.method_45421(ModBlocks.CALCIFIED_COAL_WALL);
            entries.method_45421(ModBlocks.CALCIFIED_COAL_FENCE);
            entries.method_45421(ModBlocks.CALCIFIED_COAL_FENCE_GATE);
            entries.method_45421(ModBlocks.POLISHED_COAL_STAIRS);
            entries.method_45421(ModBlocks.POLISHED_COAL_SLAB);
            entries.method_45421(ModBlocks.POLISHED_COAL_WALL);
            entries.method_45421(ModBlocks.POLISHED_COAL_FENCE);
            entries.method_45421(ModBlocks.POLISHED_COAL_FENCE_GATE);

            entries.method_45421(ModBlocks.CALCITE_STAIRS);
            entries.method_45421(ModBlocks.CALCITE_SLAB);
            entries.method_45421(ModBlocks.CALCITE_FENCE);
            entries.method_45421(ModBlocks.CALCITE_FENCE_GATE);
            entries.method_45421(ModBlocks.CALCITE_WALL);

            entries.method_45421(ModBlocks.NETHERITE_STAIRS);
            entries.method_45421(ModBlocks.NETHERITE_SLAB);
            entries.method_45421(ModBlocks.NETHERITE_FENCE);
            entries.method_45421(ModBlocks.NETHERITE_FENCE_GATE);
            entries.method_45421(ModBlocks.NETHERITE_WALL);
            entries.method_45421(ModBlocks.NETHERITE_DOOR);
            entries.method_45421(ModBlocks.NETHERITE_TRAPDOOR);
            entries.method_45421(ModBlocks.POLISHED_NETHERITE_BLOCK);
            entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_BLOCK);
            entries.method_45421(ModBlocks.NETHERITE_BRICKS);

            entries.method_45421(ModBlocks.NETHERITE_BRICK_STAIRS);
            entries.method_45421(ModBlocks.NETHERITE_BRICK_SLAB);
            entries.method_45421(ModBlocks.NETHERITE_BRICK_WALL);
            entries.method_45421(ModBlocks.NETHERITE_BRICK_FENCE);
            entries.method_45421(ModBlocks.NETHERITE_BRICK_FENCE_GATE);
            entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_STAIRS);
            entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_SLAB);
            entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_WALL);
            entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_FENCE);
            entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_FENCE_GATE);
            entries.method_45421(ModBlocks.POLISHED_NETHERITE_STAIRS);
            entries.method_45421(ModBlocks.POLISHED_NETHERITE_SLAB);
            entries.method_45421(ModBlocks.POLISHED_NETHERITE_WALL);
            entries.method_45421(ModBlocks.POLISHED_NETHERITE_FENCE);
            entries.method_45421(ModBlocks.POLISHED_NETHERITE_FENCE_GATE);

            entries.method_45421(ModBlocks.AMETHYST_STAIRS);
            entries.method_45421(ModBlocks.AMETHYST_SLAB);
            entries.method_45421(ModBlocks.AMETHYST_FENCE);
            entries.method_45421(ModBlocks.AMETHYST_FENCE_GATE);
            entries.method_45421(ModBlocks.AMETHYST_WALL);
            entries.method_45421(ModBlocks.AMETHYST_DOOR);
            entries.method_45421(ModBlocks.AMETHYST_TRAPDOOR);
            entries.method_45421(ModBlocks.POLISHED_AMETHYST_BLOCK);
            entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_BLOCK);
            entries.method_45421(ModBlocks.AMETHYST_BRICKS);

            entries.method_45421(ModBlocks.AMETHYST_BRICK_STAIRS);
            entries.method_45421(ModBlocks.AMETHYST_BRICK_SLAB);
            entries.method_45421(ModBlocks.AMETHYST_BRICK_WALL);
            entries.method_45421(ModBlocks.AMETHYST_BRICK_FENCE);
            entries.method_45421(ModBlocks.AMETHYST_BRICK_FENCE_GATE);
            entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_STAIRS);
            entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_SLAB);
            entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_WALL);
            entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_FENCE);
            entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_FENCE_GATE);
            entries.method_45421(ModBlocks.POLISHED_AMETHYST_STAIRS);
            entries.method_45421(ModBlocks.POLISHED_AMETHYST_SLAB);
            entries.method_45421(ModBlocks.POLISHED_AMETHYST_WALL);
            entries.method_45421(ModBlocks.POLISHED_AMETHYST_FENCE);
            entries.method_45421(ModBlocks.POLISHED_AMETHYST_FENCE_GATE);

            entries.method_45421(ModBlocks.REDSTONE_STAIRS);
            entries.method_45421(ModBlocks.REDSTONE_SLAB);
            entries.method_45421(ModBlocks.REDSTONE_FENCE);
            entries.method_45421(ModBlocks.REDSTONE_FENCE_GATE);
            entries.method_45421(ModBlocks.REDSTONE_WALL);
            entries.method_45421(ModBlocks.REDSTONE_DOOR);
            entries.method_45421(ModBlocks.REDSTONE_TRAPDOOR);
            entries.method_45421(ModBlocks.POLISHED_REDSTONE_BLOCK);
            entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_BLOCK);
            entries.method_45421(ModBlocks.REDSTONE_BRICKS);

            entries.method_45421(ModBlocks.REDSTONE_BRICK_STAIRS);
            entries.method_45421(ModBlocks.REDSTONE_BRICK_SLAB);
            entries.method_45421(ModBlocks.REDSTONE_BRICK_WALL);
            entries.method_45421(ModBlocks.REDSTONE_BRICK_FENCE);
            entries.method_45421(ModBlocks.REDSTONE_BRICK_FENCE_GATE);
            entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_STAIRS);
            entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_SLAB);
            entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_WALL);
            entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_FENCE);
            entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_FENCE_GATE);
            entries.method_45421(ModBlocks.POLISHED_REDSTONE_STAIRS);
            entries.method_45421(ModBlocks.POLISHED_REDSTONE_SLAB);
            entries.method_45421(ModBlocks.POLISHED_REDSTONE_WALL);
            entries.method_45421(ModBlocks.POLISHED_REDSTONE_FENCE);
            entries.method_45421(ModBlocks.POLISHED_REDSTONE_FENCE_GATE);

            entries.method_45421(ModBlocks.OBSIDIAN_STAIRS);
            entries.method_45421(ModBlocks.OBSIDIAN_SLAB);
            entries.method_45421(ModBlocks.OBSIDIAN_FENCE);
            entries.method_45421(ModBlocks.OBSIDIAN_FENCE_GATE);
            entries.method_45421(ModBlocks.OBSIDIAN_WALL);

            entries.method_45421(ModBlocks.BEDROCK_STAIRS);
            entries.method_45421(ModBlocks.BEDROCK_SLAB);
            entries.method_45421(ModBlocks.BEDROCK_FENCE);
            entries.method_45421(ModBlocks.BEDROCK_FENCE_GATE);
            entries.method_45421(ModBlocks.BEDROCK_WALL);

            entries.method_45421(ModBlocks.SCULK_STAIRS);
            entries.method_45421(ModBlocks.SCULK_SLAB);
            entries.method_45421(ModBlocks.SCULK_FENCE);
            entries.method_45421(ModBlocks.SCULK_FENCE_GATE);
            entries.method_45421(ModBlocks.SCULK_WALL);

            entries.method_45421(ModBlocks.PACKED_ICE_STAIRS);
            entries.method_45421(ModBlocks.PACKED_ICE_SLAB);
            entries.method_45421(ModBlocks.PACKED_ICE_FENCE);
            entries.method_45421(ModBlocks.PACKED_ICE_FENCE_GATE);
            entries.method_45421(ModBlocks.PACKED_ICE_WALL);

            entries.method_45421(ModBlocks.BLUE_ICE_STAIRS);
            entries.method_45421(ModBlocks.BLUE_ICE_SLAB);
            entries.method_45421(ModBlocks.BLUE_ICE_FENCE);
            entries.method_45421(ModBlocks.BLUE_ICE_FENCE_GATE);
            entries.method_45421(ModBlocks.BLUE_ICE_WALL);

            entries.method_45421(ModBlocks.ICE_STAIRS);
            entries.method_45421(ModBlocks.ICE_SLAB);
            entries.method_45421(ModBlocks.ICE_FENCE);
            entries.method_45421(ModBlocks.ICE_FENCE_GATE);
            entries.method_45421(ModBlocks.ICE_WALL);

            entries.method_45421(ModBlocks.DEEPSLATE_EMERALD_ORE_STAIRS);
            entries.method_45421(ModBlocks.DEEPSLATE_EMERALD_ORE_SLAB);
            entries.method_45421(ModBlocks.DEEPSLATE_EMERALD_ORE_FENCE);
            entries.method_45421(ModBlocks.DEEPSLATE_EMERALD_ORE_FENCE_GATE);
            entries.method_45421(ModBlocks.DEEPSLATE_EMERALD_ORE_WALL);

            entries.method_45421(ModBlocks.PRISMARINE_BRICK_WALL);
            entries.method_45421(ModBlocks.DARK_PRISMARINE_WALL);
        });
    }
}
