package net.elgoblin.moremineralblocks.block.entity;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.block.ModBlocks;
import net.elgoblin.moremineralblocks.block.entity.custom.ProtectorBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlockEntities {

    public static final class_2591<ProtectorBlockEntity> PROTECTOR_BLOCK_ENTITY =
            class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "protector_block_entity"),
                    FabricBlockEntityTypeBuilder.create(ProtectorBlockEntity::new, ModBlocks.PROTECTOR_BLOCK).build(null));

    public static void registerBlockEntities() {
        MoreMineralBlocks.LOGGER.info("Registering block entities for " + MoreMineralBlocks.MOD_ID);
    }
}
