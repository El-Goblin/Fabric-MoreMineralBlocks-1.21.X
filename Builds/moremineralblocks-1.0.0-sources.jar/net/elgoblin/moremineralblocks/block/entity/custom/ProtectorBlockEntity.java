package net.elgoblin.moremineralblocks.block.entity.custom;

import net.elgoblin.moremineralblocks.block.entity.ModBlockEntities;
import net.elgoblin.moremineralblocks.util.ProtectorManager;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.server.MinecraftServer;

public class ProtectorBlockEntity extends class_2586 {
    private boolean hasBeenRegistered = false;
    ProtectorManager.Interval3i protectedArea;

    public ProtectorBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.PROTECTOR_BLOCK_ENTITY, pos, state);
    }

    @Override
    public void method_31662(class_1937 world) {
        super.method_31662(world);

        if (!world.method_8608() && !hasBeenRegistered) {
            MinecraftServer server = world.method_8503();
            if (server != null) {
                ProtectorManager protectorManager = ProtectorManager.getProtectorManager(server);
                protectedArea = new ProtectorManager.Interval3i(this.field_11867, 64, 64, 64);

                protectorManager.addInterval(protectedArea);
                hasBeenRegistered = true;
            }
        }
    }

    @Override
    public void method_11012() {
        if (field_11863 != null && !field_11863.method_8608() && hasBeenRegistered) {
            MinecraftServer server = field_11863.method_8503();
            if (server != null) {
                ProtectorManager protectorManager = ProtectorManager.getProtectorManager(server);
                protectorManager.remove(protectedArea);
            }
        }
        super.method_11012();
    }
}
