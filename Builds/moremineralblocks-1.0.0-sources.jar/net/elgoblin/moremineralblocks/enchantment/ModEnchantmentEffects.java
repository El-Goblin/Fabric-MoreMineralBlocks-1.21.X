package net.elgoblin.moremineralblocks.enchantment;

import com.mojang.serialization.MapCodec;
import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.enchantment.custom.LinkerEnchantmentEffect;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9723;

public class ModEnchantmentEffects {

    public static final MapCodec<? extends class_9723> LINKER = registerValueEffect("linker", LinkerEnchantmentEffect.CODEC);

    private static MapCodec<? extends class_9723> registerValueEffect(String name,
                                                                                  MapCodec<? extends class_9723> codec) {
        return class_2378.method_10230(class_7923.field_51836, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name), codec);
    }

    public static void registerEnchantmentEffects() {
        MoreMineralBlocks.LOGGER.info("Registering Mod Enchantment Effects for " + MoreMineralBlocks.MOD_ID);
    }
}
