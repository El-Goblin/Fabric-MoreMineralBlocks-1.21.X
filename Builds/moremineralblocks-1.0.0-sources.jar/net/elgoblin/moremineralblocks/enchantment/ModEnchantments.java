package net.elgoblin.moremineralblocks.enchantment;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.util.ModTags;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7871;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.class_9274;
import net.minecraft.class_9304;

public class ModEnchantments {

    public static final class_5321<class_1887> LINKER = class_5321.method_29179(class_7924.field_41265, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "linker"));

    public static void bootstrap(class_7891<class_1887> registerable) {
        class_7871<class_1887> enchantments = registerable.method_46799(class_7924.field_41265);
        class_7871<class_1792> items = registerable.method_46799(class_7924.field_41197);

        register(registerable, LINKER, class_1887.method_60030(class_1887.method_58443(
                items.method_46735(ModTags.Items.LEGENDARY_TOOLS),
                items.method_46735(ModTags.Items.LEGENDARY_TOOLS),
                1,
                1,
                class_1887.method_58441(1, 1),
                class_1887.method_58441(50, 1),
                2,
                class_9274.field_49217)));
    }

    private static void register(class_7891<class_1887> registry, class_5321<class_1887> key, class_1887.class_9700 builder) {
        registry.method_46838(key, builder.method_60060(key.method_29177()));
    }

    public static int getLevel(class_1799 stack, class_5321<class_1887> enchantmentKey){
        class_9304 enchantments = stack.method_58657();

        for (class_6880<class_1887> entry : enchantments.method_57534()){
            if (entry.method_40225(enchantmentKey)) {
                return enchantments.method_57536(entry);
            }
        }
        return 0;
    }
}
