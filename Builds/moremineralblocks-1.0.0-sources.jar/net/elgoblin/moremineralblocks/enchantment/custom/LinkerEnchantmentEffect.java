package net.elgoblin.moremineralblocks.enchantment.custom;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_5819;
import net.minecraft.class_9723;

public record LinkerEnchantmentEffect() implements class_9723 {
    public static final MapCodec<LinkerEnchantmentEffect> CODEC = MapCodec.unit(LinkerEnchantmentEffect::new);

    @Override
    public float method_60213(int level, class_5819 random, float inputValue) {
        return 0;
    }

    @Override
    public MapCodec<? extends class_9723> method_60211() {
        return CODEC;
    }
}
