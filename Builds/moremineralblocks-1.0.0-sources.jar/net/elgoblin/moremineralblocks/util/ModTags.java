package net.elgoblin.moremineralblocks.util;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModTags {
    public static class Blocks {

        public static final class_6862<class_2248> NEEDS_LEGENDARY_TOOL = createTag("needs_legendary_tool");
        public static final class_6862<class_2248> INCORRECT_FOR_LEGENDARY_TOOL = createTag("incorrect_for_legendary_tool");
        public static final class_6862<class_2248> INCORRECT_FOR_SURVIVAL_DEBUG_STICK = createTag("incorrect_for_survival_debug_stick");

        private static class_6862<class_2248> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name));
        }
    }

    public static class Items {
        // Este es el grupo de items que van a transformarse en diamantes en el magic block
        public static final class_6862<class_1792> TRANSFORMABLE_ITEMS = createTag("transformable_items");
        public static final class_6862<class_1792> LEGENDARY_REPAIR = createTag("legendary_repair");
        public static final class_6862<class_1792> LEGENDARY_TOOLS = createTag("legendary_tools");
        public static final class_6862<class_1792> LONGSWORDS = createTag("longswords");

        private static class_6862<class_1792> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name));
        }
    }
}
