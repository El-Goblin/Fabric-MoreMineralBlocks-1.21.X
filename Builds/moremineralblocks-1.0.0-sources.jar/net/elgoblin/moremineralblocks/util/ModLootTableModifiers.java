package net.elgoblin.moremineralblocks.util;

import net.elgoblin.moremineralblocks.item.ModItems;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.class_141;
import net.minecraft.class_219;
import net.minecraft.class_39;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;

public class ModLootTableModifiers {
    public static void modifyLootTables() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registry) -> {

            class_55.class_56 startChest = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(1))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(32.0f, 32.0f)).method_515());

            class_55.class_56 village = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.25f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(2.0f, 3.0f)).method_515());

            class_55.class_56 dungeon = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.45f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(2.0f, 5.0f)).method_515());

            class_55.class_56 stronghold = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.5f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(16.0f, 32.0f)).method_515());

            class_55.class_56 desertTemple = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.33f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(1.0f, 4.0f)).method_515());

            class_55.class_56 jungleTemple = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.45f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(1.0f, 3.0f)).method_515());

            class_55.class_56 igloo = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.5f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());

            class_55.class_56 mansion = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.4f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(12.0f, 24.0f)).method_515());

            class_55.class_56 shipwrecks = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.3f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(1.0f, 4.0f)).method_515());

            class_55.class_56 buriedTreasure = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(1))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(8.0f, 32.0f)).method_515());

            class_55.class_56 netherBridge = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.33f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(4.0f, 8.0f)).method_515());

            class_55.class_56 bastion = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.3f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(3.0f, 9.0f)).method_515());

            class_55.class_56 ancientCity = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.25f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(8.0f, 12.0f)).method_515());

            class_55.class_56 endCity = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.5f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(12f, 24f)).method_515());

            class_55.class_56 trialChambers = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.05f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(1.0f, 2.0f)).method_515());

            class_55.class_56 sniffer = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(1))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());

            class_55.class_56 fishingJunk = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.1f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());

            class_55.class_56 fishingFish = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.1f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());

            class_55.class_56 fishingTreasure = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.25f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(1.0f, 3.0f)).method_515());

            class_55.class_56 piglinBartering = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.05f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(2.0f, 4.0f)).method_515());

            class_55.class_56 trialChamberPot = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.05f))
                    .method_351(class_77.method_411(ModItems.CHAOS_ORB))
                    .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());

            // Start chest

            if (class_39.field_850.equals(key)) {
                tableBuilder.pool(startChest.method_355());
            }

            // Villages

            if (class_39.field_434.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_17107.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_17009.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_16751.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_17010.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_17011.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_17012.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_17108.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_18007.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_16750.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_17109.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_16752.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_16748.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_16749.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_16754.equals(key)) {
                tableBuilder.pool(village.method_355());
            }
            if (class_39.field_16753.equals(key)) {
                tableBuilder.pool(village.method_355());
            }

            // dungeon

            if (class_39.field_356.equals(key)) {
                tableBuilder.pool(dungeon.method_355());
            }

            if (class_39.field_472.equals(key)) {
                tableBuilder.pool(dungeon.method_355());
            }

            // Stronghold

            if (class_39.field_683.equals(key)) {
                tableBuilder.pool(stronghold.method_355());
            }
            if (class_39.field_800.equals(key)) {
                tableBuilder.pool(stronghold.method_355());
            }
            if (class_39.field_842.equals(key)) {
                tableBuilder.pool(stronghold.method_355());
            }

            // Desert Temple

            if (class_39.field_885.equals(key)) {
                tableBuilder.pool(desertTemple.method_355());
            }

            // Jungle Temple

            if (class_39.field_803.equals(key)) {
                tableBuilder.pool(jungleTemple.method_355());
            }

            // Igloo

            if (class_39.field_662.equals(key)) {
                tableBuilder.pool(igloo.method_355());
            }

            // Mansion

            if (class_39.field_484.equals(key)) {
                tableBuilder.pool(mansion.method_355());
            }

            // Shipwrecks, ocean ruins, ruined portals

            if (class_39.field_397.equals(key)) {
                tableBuilder.pool(shipwrecks.method_355());
            }
            if (class_39.field_300.equals(key)) {
                tableBuilder.pool(shipwrecks.method_355());
            }
            if (class_39.field_841.equals(key)) {
                tableBuilder.pool(shipwrecks.method_355());
            }
            if (class_39.field_880.equals(key)) {
                tableBuilder.pool(shipwrecks.method_355());
            }
            if (class_39.field_665.equals(key)) {
                tableBuilder.pool(shipwrecks.method_355());
            }
            if (class_39.field_24050.equals(key)) {
                tableBuilder.pool(shipwrecks.method_355());
            }

            // Buried Treasure

            if (class_39.field_251.equals(key)) {
                tableBuilder.pool(buriedTreasure.method_355());
            }

            // Nether Bridge

            if (class_39.field_615.equals(key)) {
                tableBuilder.pool(netherBridge.method_355());
            }

            // Bastion

            if (class_39.field_24046.equals(key)) {
                tableBuilder.pool(bastion.method_355());
            }
            if (class_39.field_24047.equals(key)) {
                tableBuilder.pool(bastion.method_355());
            }
            if (class_39.field_24048.equals(key)) {
                tableBuilder.pool(bastion.method_355());
            }
            if (class_39.field_24049.equals(key)) {
                tableBuilder.pool(bastion.method_355());
            }

            // Ancient City

            if (class_39.field_38438.equals(key)) {
                tableBuilder.pool(ancientCity.method_355());
            }
            if (class_39.field_38439.equals(key)) {
                tableBuilder.pool(ancientCity.method_355());
            }

            // Trial Chambers

            if (class_39.field_47415.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_49844.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_49845.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_49846.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_50194.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_50195.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_50196.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_50197.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_47416.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_47417.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_47418.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_47419.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_47420.equals(key)) {
                tableBuilder.pool(trialChambers.method_355());
            }
            if (class_39.field_47426.equals(key)) {
                tableBuilder.pool(trialChamberPot.method_355());
            }

            // End Cities

            if (class_39.field_274.equals(key)) {
                tableBuilder.pool(endCity.method_355());
            }

//            // Sheep
//            if (LootTables.PINK_SHEEP_ENTITY.equals(key)) {
//                tableBuilder.pool(fishingFish.build());
//            }

            // Fishing

            if (class_39.field_266.equals(key)) {
                tableBuilder.pool(fishingJunk.method_355());
            }
            if (class_39.field_854.equals(key)) {
                tableBuilder.pool(fishingTreasure.method_355());
            }
            if (class_39.field_795.equals(key)) {
                tableBuilder.pool(fishingFish.method_355());
            }

            // Animals

            if (class_39.field_16216.equals(key)) {
                tableBuilder.pool(fishingFish.method_355());
            }
            if (class_39.field_44748.equals(key)) {
                tableBuilder.pool(sniffer.method_355());
            }

            // Piglin Bartering

            if (class_39.field_22402.equals(key)) {
                tableBuilder.pool(piglinBartering.method_355());
            }

        });
    }
}
