package net.elgoblin.moremineralblocks.util;

import net.minecraft.class_1799;

public interface KillerToolSaver {

    void setKillerTool(class_1799 tool);

    class_1799 getKillerTool();
}
