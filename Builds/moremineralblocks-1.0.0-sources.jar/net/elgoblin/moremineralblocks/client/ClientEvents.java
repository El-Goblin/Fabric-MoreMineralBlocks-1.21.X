package net.elgoblin.moremineralblocks.client;

import net.elgoblin.moremineralblocks.MoreMineralBlocksClient;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.elgoblin.moremineralblocks.networking.DimensionalPocketInterGroupScrollPayload;
import net.elgoblin.moremineralblocks.networking.DimensionalPocketIntraGroupScrollPayload;
import net.elgoblin.moremineralblocks.networking.SwitchEnchantmentToggleSafeModePayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class ClientEvents {

    public static final class_310 minecraft = class_310.method_1551();
    private static int tickCounter = 0;

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            tickCounter++;
            if (tickCounter < 0) {tickCounter = 0;}

            while (MoreMineralBlocksClient.switchEnchantments_toggleSafeMode.method_1436()) {
                ClientPlayNetworking.send(new SwitchEnchantmentToggleSafeModePayload());
            }
            while (MoreMineralBlocksClient.switchEnchantments_toggleSafeMode.method_1436()) {
                ClientPlayNetworking.send(new SwitchEnchantmentToggleSafeModePayload());
            }

            if (client.field_1724 != null && tickCounter % 2 == 0) {
                class_1799 mainHoldedStack = client.field_1724.method_6047();
                class_1799 offHoldedStack = client.field_1724.method_6079();
                class_1799 activeItem = class_1799.field_8037;

                if (mainHoldedStack.method_31574(ModItems.DIMENSIONAL_POCKET)) {
                    activeItem = mainHoldedStack;
                } else if (offHoldedStack.method_31574(ModItems.DIMENSIONAL_POCKET)) {
                    activeItem = offHoldedStack;
                }

                if (!activeItem.method_7960()) {
                    InfiniteItemClientCache.requestUpdate(activeItem);
                }
            }
        });
    }

    public static boolean onScroll(double delta) {
        class_746 player = minecraft.field_1724;
        if (player != null && minecraft.method_22683() != null) {

            class_1799 mainHand = player.method_6047();
            class_1799 offHand = player.method_6079();

            boolean isHoldingInfiniteItem = mainHand.method_31574(ModItems.DIMENSIONAL_POCKET) || offHand.method_31574(ModItems.DIMENSIONAL_POCKET);
            boolean tabPressed = MoreMineralBlocksClient.intraGroupScroll.method_1434();
            boolean gravePressed = MoreMineralBlocksClient.interGroupScroll.method_1434();

            if (isHoldingInfiniteItem && delta != 0) {
                int scroll = delta > 0 ? 1 : -1;

                if (tabPressed) {
                    ClientPlayNetworking.send(new DimensionalPocketIntraGroupScrollPayload(scroll));
                    return true;
                }
                else if (gravePressed) {
                    ClientPlayNetworking.send(new DimensionalPocketInterGroupScrollPayload(scroll));
                    return true;
                }
            }
        }
        return false;
    }
}
