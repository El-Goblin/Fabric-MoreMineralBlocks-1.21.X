package net.elgoblin.moremineralblocks.client;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.elgoblin.moremineralblocks.networking.InfiniteItemSelectColorPayload;
import net.elgoblin.moremineralblocks.networking.ToggleSlotPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1735;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_9331;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class InlineColorPanel {
    public int x, y;
    public final int targetSlotId;
    public boolean active = true;

    private int selectedColorIndex = 0;

    private static final int[] COLORS = {
            0xFFFFFFFF, 0xFFD87F33, 0xFFB24CD8, 0xFF6699D8,
            0xFFE5E533, 0xFF7FCC19, 0xFFF27FA5, 0xFF4C4C4C,
            0xFF999999, 0xFF4C7F99, 0xFF7F3FB2, 0xFF334CB2,
            0xFF664C33, 0xFF667F33, 0xFF993333, 0xFF191919
    };

    public InlineColorPanel(int x, int y, int targetSlotId, int currentActiveColor) {
        this.x = x;
        this.y = y;
        this.targetSlotId = targetSlotId;
        this.selectedColorIndex = currentActiveColor;
    }

    public void render(class_332 context, int mouseX, int mouseY) {
        if (!active) return;

        // Cuadrado fondo atras de los cuadraditos con los colores
        context.method_25294(this.x - 4, this.y - 4, this.x + (4 * 18) + 2, this.y + (4 * 18) + 2, 0xEE101010);

        int index = 0;
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                int cx = this.x + (col * 18);
                int cy = this.y + (row * 18);
                int color = COLORS[index];

                // Cuadrado blanco que indica que color estas hovereando con el mouse
                if (mouseX >= cx && mouseX < cx + 16 && mouseY >= cy && mouseY < cy + 16) {
                    context.method_25294(cx - 1, cy - 1, cx + 17, cy + 17, 0xFFFFFFFF);
                }

                // Dibujar los cuadrados de cada color en el panel
                context.method_25294(cx, cy, cx + 16, cy + 16, color);

                // Cuadrado blanco de seleccion de color
                if (index == selectedColorIndex) {
                    context.method_25294(cx - 1, cy - 1, cx + 17, cy, 0xFFFFFFFF); // Top line
                    context.method_25294(cx - 1, cy + 16, cx + 17, cy + 17, 0xFFFFFFFF); // Bottom line
                    context.method_25294(cx - 1, cy, cx, cy + 16, 0xFFFFFFFF); // Left line
                    context.method_25294(cx + 16, cy, cx + 17, cy + 16, 0xFFFFFFFF); // Right line
                }
                index++;
            }
        }
    }

    public boolean checkClick(double mouseX, double mouseY) {
        if (!active) return false;

        int totalWidth = 4 * 18;
        int totalHeight = 4 * 18;

        // Click adentro del panel?
        if (mouseX >= this.x && mouseX < this.x + totalWidth && mouseY >= this.y && mouseY < this.y + totalHeight) {
            int index = 0;
            for (int row = 0; row < 4; row++) {
                for (int col = 0; col < 4; col++) {
                    int cx = this.x + (col * 18);
                    int cy = this.y + (row * 18);

                    if (mouseX >= cx && mouseX < cx + 16 && mouseY >= cy && mouseY < cy + 16) {
                        this.selectedColorIndex = index;
                        ClientPlayNetworking.send(new InfiniteItemSelectColorPayload(index, this.targetSlotId));
                        return true;
                    }
                    index++;
                }
            }
            return true;
        }
        return false;
    }

    public void toggleSlotAssignment(int slotId) {
        if (selectedColorIndex == -1) return;

        class_1767 dyeColor = class_1767.method_7791(selectedColorIndex);
        // Como quiero que esto sea generico para todos los colores, no puedo hacer get despues con un color en especifico
        class_9331<List<Integer>> colorInventory = ModDataComponentTypes.COLOR_INVENTORIES.get(dyeColor);

        if (colorInventory != null) {
            class_310 client = class_310.method_1551();
            if (client.field_1755 instanceof class_465<?> handledScreen) {

                // Para poder acceder las componentes, consigo el ItemStack del InfiniteItem
                class_1735 slot = handledScreen.method_17577().method_7611(this.targetSlotId);

                if (slot != null && slot.method_7681()) {
                    class_1799 stack = slot.method_7677();
                    if (stack.method_31574(ModItems.DIMENSION_POCKET)) {
                        List<Integer> existingSlots = stack.method_58695(colorInventory, Collections.emptyList());
                        List<Integer> updatedSlots = new ArrayList<>(existingSlots);

                        if (updatedSlots.contains(slotId)) {
                            updatedSlots.remove(Integer.valueOf(slotId));
                        } else {
                            updatedSlots.add(slotId);
                        }
                        stack.method_57379(colorInventory, updatedSlots);
                        slot.method_7673(stack);
                    }
                }
            }
        }
        ClientPlayNetworking.send(new ToggleSlotPayload(this.targetSlotId, slotId, selectedColorIndex));
    }

    public int getColorHex(int index) {
        if (index < 0 || index >= COLORS.length) return 0xFFFFFFFF;
        return COLORS[index];
    }

    public int getSelectedColorIndex() {
        return this.selectedColorIndex;
    }

    public boolean isSlotAssignedToColor(int slotId, int colorIndex) {
        class_1767 dyeColor = class_1767.method_7791(colorIndex);
        class_9331<List<Integer>> component = ModDataComponentTypes.COLOR_INVENTORIES.get(dyeColor);

        if (component != null) {
            class_310 client = class_310.method_1551();
            if (client.field_1755 instanceof class_465<?> handledScreen) {
                class_1735 slot = handledScreen.method_17577().method_7611(this.targetSlotId);
                if (slot != null && slot.method_7681()) {
                    class_1799 itemStack = slot.method_7677();
                    if (itemStack.method_31574(ModItems.DIMENSION_POCKET)) {
                        List<Integer> slots = slot.method_7677().method_58695(component, java.util.Collections.emptyList());
                        return slots.contains(slotId);
                    }
                }
            }
        }
        return false;
    }
}