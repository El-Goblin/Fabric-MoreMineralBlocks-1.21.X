package net.elgoblin.moremineralblocks.client;

import net.elgoblin.moremineralblocks.networking.DimensionalPocketDepositContentsQueryPayload;
import net.elgoblin.moremineralblocks.networking.DimensionalPocketDepositContentsResponsePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;

public class InfiniteItemClientCache {
    public static class_1799 mainStack = class_1799.field_8037;
    public static int mainCount = 0;

    public static class_1799 sameGroupPrevStack = class_1799.field_8037;
    public static int sameGroupPrevCount = 0;

    public static class_1799 sameGroupNextStack = class_1799.field_8037;
    public static int sameGroupNextCount = 0;

    public static class_1799 prevGroupStack = class_1799.field_8037;
    public static int prevGroupIndex = 0;

    public static class_1799 nextGroupStack = class_1799.field_8037;
    public static int nextGroupIndex = 0;

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(DimensionalPocketDepositContentsResponsePayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                mainStack = payload.mainStack();
                mainCount = payload.mainCount();

                sameGroupPrevStack = payload.sameGroupPrevStack();

                sameGroupNextStack = payload.sameGroupNextStack();

                prevGroupStack = payload.prevGroupStack();
                prevGroupIndex = payload.prevGroupIndex();

                nextGroupStack = payload.nextGroupStack();
                nextGroupIndex = payload.nextGroupIndex();
            });
        });
    }

    public static void requestUpdate(class_1799 stack) {
        ClientPlayNetworking.send(new DimensionalPocketDepositContentsQueryPayload(stack));
    }
}
