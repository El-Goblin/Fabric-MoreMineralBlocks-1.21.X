package net.elgoblin.moremineralblocks.client;

import net.elgoblin.moremineralblocks.networking.InfiniteItemstackV2ChestContentsQueryPayload;
import net.elgoblin.moremineralblocks.networking.InfiniteItemstackV2ChestContentsResponsePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;

public class InfiniteItemClientCache {
    public static class_1799 mainRenderedStack = class_1799.field_8037;
    public static class_1799 sameGroupPrevStack = class_1799.field_8037;
    public static class_1799 sameGroupNextStack = class_1799.field_8037;
    public static class_1799 prevGroupStack = class_1799.field_8037;
    public static class_1799 nextGroupStack = class_1799.field_8037;

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(InfiniteItemstackV2ChestContentsResponsePayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                mainRenderedStack = payload.mainStack();
                sameGroupPrevStack = payload.sameGroupPrevStack();
                sameGroupNextStack = payload.sameGroupNextStack();
                prevGroupStack = payload.prevGroupStack();
                nextGroupStack = payload.nextGroupStack();
            });
        });
    }

    public static void requestUpdate(class_1799 stack) {
        ClientPlayNetworking.send(new InfiniteItemstackV2ChestContentsQueryPayload(stack));
    }
}
