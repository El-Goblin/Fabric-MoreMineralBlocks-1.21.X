package net.elgoblin.moremineralblocks.client;

import net.elgoblin.moremineralblocks.networking.DimensionalPocketDepositContentsQueryPayload;
import net.elgoblin.moremineralblocks.networking.DimensionalPocketDepositContentsResponsePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;

public class InfiniteItemClientCache {
    public static class_1799 mainRenderedStack = class_1799.field_8037;
    public static class_1799 sameGroupPrevStack = class_1799.field_8037;
    public static class_1799 sameGroupNextStack = class_1799.field_8037;
    public static class_1799 prevGroupStack = class_1799.field_8037;
    public static class_1799 nextGroupStack = class_1799.field_8037;

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(DimensionalPocketDepositContentsResponsePayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                mainRenderedStack = payload.mainStack();
                sameGroupPrevStack = payload.sameGroupPrevStack();
                sameGroupNextStack = payload.sameGroupNextStack();
                prevGroupStack = payload.prevGroupStack();
                nextGroupStack = payload.nextGroupStack();
            });
        });
    }

    public static void requestUpdate(class_1799 stack) {
        ClientPlayNetworking.send(new DimensionalPocketDepositContentsQueryPayload(stack));
    }
}
