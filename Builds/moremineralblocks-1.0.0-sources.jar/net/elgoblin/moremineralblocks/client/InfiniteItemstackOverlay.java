package net.elgoblin.moremineralblocks.client;

import net.elgoblin.moremineralblocks.MoreMineralBlocksClient;
import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_10799;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import java.util.List;

public class InfiniteItemstackOverlay {
    private static final class_2960 HOTBAR_SELECTED_TEXTURE =
            class_2960.method_60656("textures/gui/sprites/hud/hotbar_selection.png");
    private static final class_2960 HOTBAR_TEXTURE =
            class_2960.method_60656("textures/gui/sprites/hud/hotbar.png");

    public static void register() {
        HudRenderCallback.EVENT.register((drawContext, renderTickCounter) -> {

            class_310 client = class_310.method_1551();
            if (client.field_1724 == null || client.field_1690.field_1842) return;

            boolean interGroupScrollPressed = MoreMineralBlocksClient.interGroupScroll.method_1434();
            boolean intraGroupScrollPressed = MoreMineralBlocksClient.intraGroupScroll.method_1434();
            if (!intraGroupScrollPressed && !interGroupScrollPressed) {
                return;
            }

            class_1657 player = client.field_1724;
            class_1799 mainHand = player.method_6047();
            class_1799 offHand = player.method_6079();
            class_1799 activeItem = class_1799.field_8037;

            if (mainHand.method_31574(ModItems.DIMENSIONAL_POCKET)) {
                activeItem = mainHand;
            } else if (offHand.method_31574(ModItems.DIMENSIONAL_POCKET)) {
                activeItem = offHand;
            }

            if (activeItem.method_7960()) return;

            Integer currentGroup = activeItem.method_58694(ModDataComponentTypes.INTER_GROUP_POINTER);
            if (currentGroup == null) {
                currentGroup = 0;
            }

            int previousGroup = findNextGroup(activeItem, currentGroup, -1);
            int nextGroup = findNextGroup(activeItem, currentGroup, 1);

            int screenWidth = client.method_22683().method_4486();
            int screenHeight = client.method_22683().method_4502();

            int hotbarLeftX = screenWidth / 2 - 90;
            int selectedSlot = player.method_31548().method_67532();

            int slotCenterX = hotbarLeftX + (selectedSlot * 20) - 2;

            int hotbarTopY = screenHeight - 22;
            int slotHeight = 22;

            if (activeItem == offHand) {
                slotCenterX = (screenWidth / 2) - 90 - 29 -2;
            }

            drawContext.method_25290(
                    class_10799.field_56883,
                    HOTBAR_TEXTURE,
                    slotCenterX+2,
                    hotbarTopY - slotHeight + 1,
                    1,
                    1,
                    20,
                    20,
                    182,
                    22
            );
            drawContext.method_25290(
                    class_10799.field_56883,
                    HOTBAR_TEXTURE,
                    slotCenterX+2,
                    hotbarTopY - (slotHeight * 3) + 2,
                    1,
                    1,
                    20,
                    20,
                    182,
                    22
            );
            drawContext.method_25290(
                    class_10799.field_56883,
                    HOTBAR_SELECTED_TEXTURE,
                    slotCenterX + 1,
                    hotbarTopY - slotHeight * 2,
                    1,
                    1,
                    22,
                    23,
                    24,
                    24
            );

            drawColorIcon(drawContext, nextGroup, slotCenterX + 4, hotbarTopY - (slotHeight * 3) + 4, activeItem);

            // Duplicado para arreglar lo del 1 pixel vacio
            drawColorIcon(drawContext, currentGroup, slotCenterX + 4, hotbarTopY - (slotHeight * 2) + 3, activeItem);
            drawColorIcon(drawContext, currentGroup, slotCenterX + 4, hotbarTopY - (slotHeight * 2) + 4, activeItem);

            drawColorIcon(drawContext, previousGroup, slotCenterX + 4, hotbarTopY - slotHeight + 3, activeItem);

            renderSafeCachedStack(drawContext, InfiniteItemClientCache.nextGroupStack, slotCenterX + 4, hotbarTopY - (slotHeight * 3) + 4);
            renderSafeCachedStack(drawContext, InfiniteItemClientCache.prevGroupStack, slotCenterX + 4, hotbarTopY - slotHeight + 3);

            if (intraGroupScrollPressed) {
                drawContext.method_25290(class_10799.field_56883, HOTBAR_TEXTURE, slotCenterX - 20 + 1, hotbarTopY - (slotHeight * 2) + 1, 1, 1, 20, 20, 182, 22);
                drawContext.method_25290(class_10799.field_56883, HOTBAR_TEXTURE, slotCenterX + 22 + 1, hotbarTopY - (slotHeight * 2) + 1, 1, 1, 20, 20, 182, 22);

                drawColorIcon(drawContext, currentGroup, slotCenterX -20 + 3, hotbarTopY - (slotHeight * 2) + 3, activeItem);
                drawColorIcon(drawContext, currentGroup, slotCenterX +22 + 3, hotbarTopY - (slotHeight * 2) + 3, activeItem);

                renderSafeCachedStack(drawContext, InfiniteItemClientCache.sameGroupPrevStack, slotCenterX - 20 + 3, hotbarTopY - (slotHeight * 2) + 3);
                renderSafeCachedStack(drawContext, InfiniteItemClientCache.sameGroupNextStack, slotCenterX + 22 + 3, hotbarTopY - (slotHeight * 2) + 3);
            }

            renderSafeCachedStack(drawContext, InfiniteItemClientCache.mainStack, slotCenterX + 4, hotbarTopY - (slotHeight * 2) + 4);
        });
    }

    // Creamos una copia del itemStack y le cambiamos el interGroupPointer a ese stack para que se renderize distinto.
    private static void drawColorIcon(class_332 context, int colorIndex, int x, int y, class_1799 originalItem) {
        class_1799 iconStack = originalItem.method_7972();
        iconStack.method_57379(ModDataComponentTypes.INTER_GROUP_POINTER, colorIndex);
        context.method_51427(iconStack, x, y);
    }

    static int findNextGroup(class_1799 infiniteItemstack, int currentGroup, int direction) {
        int newGroup = currentGroup + direction;
        if (newGroup >= 16) {newGroup = 0;}
        if (newGroup < 0) {newGroup = 15;}
        List<Integer> group = infiniteItemstack.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(newGroup)));
        while (group != null && group.isEmpty() && newGroup != currentGroup) {
            newGroup = newGroup + direction;
            if (newGroup >= 16) {newGroup = 0;}
            if (newGroup < 0) {newGroup = 15;}
            group = infiniteItemstack.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(newGroup)));
        }

        return newGroup;
    }

    private static void renderSafeCachedStack(class_332 context, class_1799 cachedStack, int x, int y) {
        if (cachedStack != null && !cachedStack.method_7960()) {
            context.method_51427(cachedStack, x, y);
        }
    }
}