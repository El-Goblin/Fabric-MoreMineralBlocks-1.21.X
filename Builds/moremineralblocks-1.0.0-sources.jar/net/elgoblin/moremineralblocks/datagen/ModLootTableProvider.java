package net.elgoblin.moremineralblocks.datagen;

import net.elgoblin.moremineralblocks.block.ModBlocks;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ModLootTableProvider extends FabricBlockLootTableProvider {
    public ModLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void method_10379() {
        //addDrop(ModBlocks.PINK_GARNET_BLOCK);
        //addDrop(ModBlocks.RAW_PINK_GARNET_BLOCK);
        //addDrop(ModBlocks.MAGIC_BLOCK);

        //addDrop(ModBlocks.PINK_GARNET_ORE, oreDrops(ModBlocks.PINK_GARNET_ORE, ModItems.RAW_PINK_GARNET));
        //addDrop(ModBlocks.PINK_GARNET_DEEPSLATE_ORE, multipleOreDrops(ModBlocks.PINK_GARNET_DEEPSLATE_ORE, ModItems.RAW_PINK_GARNET, 2, 5));

        //addDrop(ModBlocks.PINK_GARNET_STAIRS);
        //addDrop(ModBlocks.PINK_GARNET_FENCE);
        //addDrop(ModBlocks.PINK_GARNET_FENCE_GATE);
        //addDrop(ModBlocks.PINK_GARNET_WALL);
        //addDrop(ModBlocks.PINK_GARNET_SLAB, slabDrops(ModBlocks.PINK_GARNET_SLAB));

        method_46025(ModBlocks.GOLD_STAIRS);
        method_46025(ModBlocks.GOLD_FENCE);
        method_46025(ModBlocks.GOLD_FENCE_GATE);
        method_46025(ModBlocks.GOLD_WALL);
        method_46025(ModBlocks.GOLD_TRAPDOOR);
        method_45988(ModBlocks.GOLD_SLAB, method_45980(ModBlocks.GOLD_SLAB));
        method_45988(ModBlocks.GOLD_DOOR, method_46022(ModBlocks.GOLD_DOOR));
        method_46025(ModBlocks.POLISHED_GOLD_BLOCK);
        method_46025(ModBlocks.CALCIFIED_GOLD_BLOCK);
        method_46025(ModBlocks.GOLD_BRICKS);

        method_46025(ModBlocks.GOLD_BRICK_STAIRS);
        method_45988(ModBlocks.GOLD_BRICK_SLAB, method_45980(ModBlocks.GOLD_BRICK_SLAB));
        method_46025(ModBlocks.GOLD_BRICK_FENCE);
        method_46025(ModBlocks.GOLD_BRICK_FENCE_GATE);
        method_46025(ModBlocks.GOLD_BRICK_WALL);
        method_46025(ModBlocks.POLISHED_GOLD_STAIRS);
        method_45988(ModBlocks.POLISHED_GOLD_SLAB, method_45980(ModBlocks.POLISHED_GOLD_SLAB));
        method_46025(ModBlocks.POLISHED_GOLD_FENCE);
        method_46025(ModBlocks.POLISHED_GOLD_FENCE_GATE);
        method_46025(ModBlocks.POLISHED_GOLD_WALL);
        method_46025(ModBlocks.CALCIFIED_GOLD_STAIRS);
        method_45988(ModBlocks.CALCIFIED_GOLD_SLAB, method_45980(ModBlocks.CALCIFIED_GOLD_SLAB));
        method_46025(ModBlocks.CALCIFIED_GOLD_FENCE);
        method_46025(ModBlocks.CALCIFIED_GOLD_FENCE_GATE);
        method_46025(ModBlocks.CALCIFIED_GOLD_WALL);

        method_46025(ModBlocks.DIAMOND_STAIRS);
        method_46025(ModBlocks.DIAMOND_FENCE);
        method_46025(ModBlocks.DIAMOND_FENCE_GATE);
        method_46025(ModBlocks.DIAMOND_WALL);
        method_46025(ModBlocks.DIAMOND_TRAPDOOR);
        method_45988(ModBlocks.DIAMOND_SLAB, method_45980(ModBlocks.DIAMOND_SLAB));
        method_45988(ModBlocks.DIAMOND_DOOR, method_46022(ModBlocks.DIAMOND_DOOR));
        method_46025(ModBlocks.POLISHED_DIAMOND_BLOCK);
        method_46025(ModBlocks.CALCIFIED_DIAMOND_BLOCK);
        method_46025(ModBlocks.DIAMOND_BRICKS);

        method_46025(ModBlocks.DIAMOND_BRICK_STAIRS);
        method_45988(ModBlocks.DIAMOND_BRICK_SLAB, method_45980(ModBlocks.DIAMOND_BRICK_SLAB));
        method_46025(ModBlocks.DIAMOND_BRICK_FENCE);
        method_46025(ModBlocks.DIAMOND_BRICK_FENCE_GATE);
        method_46025(ModBlocks.DIAMOND_BRICK_WALL);
        method_46025(ModBlocks.POLISHED_DIAMOND_STAIRS);
        method_45988(ModBlocks.POLISHED_DIAMOND_SLAB, method_45980(ModBlocks.POLISHED_DIAMOND_SLAB));
        method_46025(ModBlocks.POLISHED_DIAMOND_FENCE);
        method_46025(ModBlocks.POLISHED_DIAMOND_FENCE_GATE);
        method_46025(ModBlocks.POLISHED_DIAMOND_WALL);
        method_46025(ModBlocks.CALCIFIED_DIAMOND_STAIRS);
        method_45988(ModBlocks.CALCIFIED_DIAMOND_SLAB, method_45980(ModBlocks.CALCIFIED_DIAMOND_SLAB));
        method_46025(ModBlocks.CALCIFIED_DIAMOND_FENCE);
        method_46025(ModBlocks.CALCIFIED_DIAMOND_FENCE_GATE);
        method_46025(ModBlocks.CALCIFIED_DIAMOND_WALL);

        method_46025(ModBlocks.IRON_STAIRS);
        method_46025(ModBlocks.IRON_FENCE);
        method_46025(ModBlocks.IRON_FENCE_GATE);
        method_46025(ModBlocks.IRON_WALL);
        method_45988(ModBlocks.IRON_SLAB, method_45980(ModBlocks.IRON_SLAB));
        method_46025(ModBlocks.POLISHED_IRON_BLOCK);
        method_46025(ModBlocks.CALCIFIED_IRON_BLOCK);
        method_46025(ModBlocks.IRON_BRICKS);

        method_46025(ModBlocks.IRON_BRICK_STAIRS);
        method_45988(ModBlocks.IRON_BRICK_SLAB, method_45980(ModBlocks.IRON_BRICK_SLAB));
        method_46025(ModBlocks.IRON_BRICK_FENCE);
        method_46025(ModBlocks.IRON_BRICK_FENCE_GATE);
        method_46025(ModBlocks.IRON_BRICK_WALL);
        method_46025(ModBlocks.POLISHED_IRON_STAIRS);
        method_45988(ModBlocks.POLISHED_IRON_SLAB, method_45980(ModBlocks.POLISHED_IRON_SLAB));
        method_46025(ModBlocks.POLISHED_IRON_FENCE);
        method_46025(ModBlocks.POLISHED_IRON_FENCE_GATE);
        method_46025(ModBlocks.POLISHED_IRON_WALL);
        method_46025(ModBlocks.CALCIFIED_IRON_STAIRS);
        method_45988(ModBlocks.CALCIFIED_IRON_SLAB, method_45980(ModBlocks.CALCIFIED_IRON_SLAB));
        method_46025(ModBlocks.CALCIFIED_IRON_FENCE);
        method_46025(ModBlocks.CALCIFIED_IRON_FENCE_GATE);
        method_46025(ModBlocks.CALCIFIED_IRON_WALL);

        method_46025(ModBlocks.AMETHYST_STAIRS);
        method_46025(ModBlocks.AMETHYST_FENCE);
        method_46025(ModBlocks.AMETHYST_FENCE_GATE);
        method_46025(ModBlocks.AMETHYST_WALL);
        method_46025(ModBlocks.AMETHYST_TRAPDOOR);
        method_45988(ModBlocks.AMETHYST_SLAB, method_45980(ModBlocks.AMETHYST_SLAB));
        method_45988(ModBlocks.AMETHYST_DOOR, method_46022(ModBlocks.AMETHYST_DOOR));
        method_46025(ModBlocks.POLISHED_AMETHYST_BLOCK);
        method_46025(ModBlocks.CALCIFIED_AMETHYST_BLOCK);
        method_46025(ModBlocks.AMETHYST_BRICKS);

        method_46025(ModBlocks.AMETHYST_BRICK_STAIRS);
        method_45988(ModBlocks.AMETHYST_BRICK_SLAB, method_45980(ModBlocks.AMETHYST_BRICK_SLAB));
        method_46025(ModBlocks.AMETHYST_BRICK_FENCE);
        method_46025(ModBlocks.AMETHYST_BRICK_FENCE_GATE);
        method_46025(ModBlocks.AMETHYST_BRICK_WALL);
        method_46025(ModBlocks.POLISHED_AMETHYST_STAIRS);
        method_45988(ModBlocks.POLISHED_AMETHYST_SLAB, method_45980(ModBlocks.POLISHED_AMETHYST_SLAB));
        method_46025(ModBlocks.POLISHED_AMETHYST_FENCE);
        method_46025(ModBlocks.POLISHED_AMETHYST_FENCE_GATE);
        method_46025(ModBlocks.POLISHED_AMETHYST_WALL);
        method_46025(ModBlocks.CALCIFIED_AMETHYST_STAIRS);
        method_45988(ModBlocks.CALCIFIED_AMETHYST_SLAB, method_45980(ModBlocks.CALCIFIED_AMETHYST_SLAB));
        method_46025(ModBlocks.CALCIFIED_AMETHYST_FENCE);
        method_46025(ModBlocks.CALCIFIED_AMETHYST_FENCE_GATE);
        method_46025(ModBlocks.CALCIFIED_AMETHYST_WALL);

        method_46025(ModBlocks.EMERALD_STAIRS);
        method_46025(ModBlocks.EMERALD_FENCE);
        method_46025(ModBlocks.EMERALD_FENCE_GATE);
        method_46025(ModBlocks.EMERALD_WALL);
        method_46025(ModBlocks.EMERALD_TRAPDOOR);
        method_45988(ModBlocks.EMERALD_SLAB, method_45980(ModBlocks.EMERALD_SLAB));
        method_45988(ModBlocks.EMERALD_DOOR, method_46022(ModBlocks.EMERALD_DOOR));
        method_46025(ModBlocks.POLISHED_EMERALD_BLOCK);
        method_46025(ModBlocks.CHISELED_EMERALD_BLOCK);
        method_46025(ModBlocks.CALCIFIED_EMERALD_BLOCK);
        method_46025(ModBlocks.EMERALD_BRICKS);

        method_46025(ModBlocks.EMERALD_BRICK_STAIRS);
        method_45988(ModBlocks.EMERALD_BRICK_SLAB, method_45980(ModBlocks.EMERALD_BRICK_SLAB));
        method_46025(ModBlocks.EMERALD_BRICK_FENCE);
        method_46025(ModBlocks.EMERALD_BRICK_FENCE_GATE);
        method_46025(ModBlocks.EMERALD_BRICK_WALL);
        method_46025(ModBlocks.POLISHED_EMERALD_STAIRS);
        method_45988(ModBlocks.POLISHED_EMERALD_SLAB, method_45980(ModBlocks.POLISHED_EMERALD_SLAB));
        method_46025(ModBlocks.POLISHED_EMERALD_FENCE);
        method_46025(ModBlocks.POLISHED_EMERALD_FENCE_GATE);
        method_46025(ModBlocks.POLISHED_EMERALD_WALL);
        method_46025(ModBlocks.CALCIFIED_EMERALD_STAIRS);
        method_45988(ModBlocks.CALCIFIED_EMERALD_SLAB, method_45980(ModBlocks.CALCIFIED_EMERALD_SLAB));
        method_46025(ModBlocks.CALCIFIED_EMERALD_FENCE);
        method_46025(ModBlocks.CALCIFIED_EMERALD_FENCE_GATE);
        method_46025(ModBlocks.CALCIFIED_EMERALD_WALL);
        method_46025(ModBlocks.CHISELED_EMERALD_STAIRS);
        method_45988(ModBlocks.CHISELED_EMERALD_SLAB, method_45980(ModBlocks.CHISELED_EMERALD_SLAB));
        method_46025(ModBlocks.CHISELED_EMERALD_FENCE);
        method_46025(ModBlocks.CHISELED_EMERALD_FENCE_GATE);
        method_46025(ModBlocks.CHISELED_EMERALD_WALL);

        method_46025(ModBlocks.LAPIS_STAIRS);
        method_46025(ModBlocks.LAPIS_FENCE);
        method_46025(ModBlocks.LAPIS_FENCE_GATE);
        method_46025(ModBlocks.LAPIS_WALL);
        method_46025(ModBlocks.LAPIS_TRAPDOOR);
        method_45988(ModBlocks.LAPIS_SLAB, method_45980(ModBlocks.LAPIS_SLAB));
        method_45988(ModBlocks.LAPIS_DOOR, method_46022(ModBlocks.LAPIS_DOOR));
        method_46025(ModBlocks.POLISHED_LAPIS_BLOCK);
        method_46025(ModBlocks.CALCIFIED_LAPIS_BLOCK);
        method_46025(ModBlocks.LAPIS_BRICKS);

        method_46025(ModBlocks.LAPIS_BRICK_STAIRS);
        method_45988(ModBlocks.LAPIS_BRICK_SLAB, method_45980(ModBlocks.LAPIS_BRICK_SLAB));
        method_46025(ModBlocks.LAPIS_BRICK_FENCE);
        method_46025(ModBlocks.LAPIS_BRICK_FENCE_GATE);
        method_46025(ModBlocks.LAPIS_BRICK_WALL);
        method_46025(ModBlocks.POLISHED_LAPIS_STAIRS);
        method_45988(ModBlocks.POLISHED_LAPIS_SLAB, method_45980(ModBlocks.POLISHED_LAPIS_SLAB));
        method_46025(ModBlocks.POLISHED_LAPIS_FENCE);
        method_46025(ModBlocks.POLISHED_LAPIS_FENCE_GATE);
        method_46025(ModBlocks.POLISHED_LAPIS_WALL);
        method_46025(ModBlocks.CALCIFIED_LAPIS_STAIRS);
        method_45988(ModBlocks.CALCIFIED_LAPIS_SLAB, method_45980(ModBlocks.CALCIFIED_LAPIS_SLAB));
        method_46025(ModBlocks.CALCIFIED_LAPIS_FENCE);
        method_46025(ModBlocks.CALCIFIED_LAPIS_FENCE_GATE);
        method_46025(ModBlocks.CALCIFIED_LAPIS_WALL);

        method_46025(ModBlocks.COAL_STAIRS);
        method_46025(ModBlocks.COAL_FENCE);
        method_46025(ModBlocks.COAL_FENCE_GATE);
        method_46025(ModBlocks.COAL_WALL);
        method_46025(ModBlocks.COAL_TRAPDOOR);
        method_45988(ModBlocks.COAL_SLAB, method_45980(ModBlocks.COAL_SLAB));
        method_45988(ModBlocks.COAL_DOOR, method_46022(ModBlocks.COAL_DOOR));
        method_46025(ModBlocks.POLISHED_COAL_BLOCK);
        method_46025(ModBlocks.CALCIFIED_COAL_BLOCK);
        method_46025(ModBlocks.COAL_BRICKS);

        method_46025(ModBlocks.COAL_BRICK_STAIRS);
        method_45988(ModBlocks.COAL_BRICK_SLAB, method_45980(ModBlocks.COAL_BRICK_SLAB));
        method_46025(ModBlocks.COAL_BRICK_FENCE);
        method_46025(ModBlocks.COAL_BRICK_FENCE_GATE);
        method_46025(ModBlocks.COAL_BRICK_WALL);
        method_46025(ModBlocks.POLISHED_COAL_STAIRS);
        method_45988(ModBlocks.POLISHED_COAL_SLAB, method_45980(ModBlocks.POLISHED_COAL_SLAB));
        method_46025(ModBlocks.POLISHED_COAL_FENCE);
        method_46025(ModBlocks.POLISHED_COAL_FENCE_GATE);
        method_46025(ModBlocks.POLISHED_COAL_WALL);
        method_46025(ModBlocks.CALCIFIED_COAL_STAIRS);
        method_45988(ModBlocks.CALCIFIED_COAL_SLAB, method_45980(ModBlocks.CALCIFIED_COAL_SLAB));
        method_46025(ModBlocks.CALCIFIED_COAL_FENCE);
        method_46025(ModBlocks.CALCIFIED_COAL_FENCE_GATE);
        method_46025(ModBlocks.CALCIFIED_COAL_WALL);

        method_46025(ModBlocks.CALCITE_STAIRS);
        method_46025(ModBlocks.CALCITE_FENCE);
        method_46025(ModBlocks.CALCITE_FENCE_GATE);
        method_46025(ModBlocks.CALCITE_WALL);
        method_45988(ModBlocks.CALCITE_SLAB, method_45980(ModBlocks.CALCITE_SLAB));

        method_46025(ModBlocks.NETHERITE_STAIRS);
        method_46025(ModBlocks.NETHERITE_FENCE);
        method_46025(ModBlocks.NETHERITE_FENCE_GATE);
        method_46025(ModBlocks.NETHERITE_WALL);
        method_46025(ModBlocks.NETHERITE_TRAPDOOR);
        method_45988(ModBlocks.NETHERITE_SLAB, method_45980(ModBlocks.NETHERITE_SLAB));
        method_45988(ModBlocks.NETHERITE_DOOR, method_46022(ModBlocks.NETHERITE_DOOR));
        method_46025(ModBlocks.POLISHED_NETHERITE_BLOCK);
        method_46025(ModBlocks.CALCIFIED_NETHERITE_BLOCK);
        method_46025(ModBlocks.NETHERITE_BRICKS);

        method_46025(ModBlocks.NETHERITE_BRICK_STAIRS);
        method_45988(ModBlocks.NETHERITE_BRICK_SLAB, method_45980(ModBlocks.NETHERITE_BRICK_SLAB));
        method_46025(ModBlocks.NETHERITE_BRICK_FENCE);
        method_46025(ModBlocks.NETHERITE_BRICK_FENCE_GATE);
        method_46025(ModBlocks.NETHERITE_BRICK_WALL);
        method_46025(ModBlocks.POLISHED_NETHERITE_STAIRS);
        method_45988(ModBlocks.POLISHED_NETHERITE_SLAB, method_45980(ModBlocks.POLISHED_NETHERITE_SLAB));
        method_46025(ModBlocks.POLISHED_NETHERITE_FENCE);
        method_46025(ModBlocks.POLISHED_NETHERITE_FENCE_GATE);
        method_46025(ModBlocks.POLISHED_NETHERITE_WALL);
        method_46025(ModBlocks.CALCIFIED_NETHERITE_STAIRS);
        method_45988(ModBlocks.CALCIFIED_NETHERITE_SLAB, method_45980(ModBlocks.CALCIFIED_NETHERITE_SLAB));
        method_46025(ModBlocks.CALCIFIED_NETHERITE_FENCE);
        method_46025(ModBlocks.CALCIFIED_NETHERITE_FENCE_GATE);
        method_46025(ModBlocks.CALCIFIED_NETHERITE_WALL);

        method_46025(ModBlocks.REDSTONE_STAIRS);
        method_46025(ModBlocks.REDSTONE_FENCE);
        method_46025(ModBlocks.REDSTONE_FENCE_GATE);
        method_46025(ModBlocks.REDSTONE_WALL);
        method_46025(ModBlocks.REDSTONE_TRAPDOOR);
        method_45988(ModBlocks.REDSTONE_SLAB, method_45980(ModBlocks.REDSTONE_SLAB));
        method_45988(ModBlocks.REDSTONE_DOOR, method_46022(ModBlocks.REDSTONE_DOOR));
        method_46025(ModBlocks.POLISHED_REDSTONE_BLOCK);
        method_46025(ModBlocks.CALCIFIED_REDSTONE_BLOCK);
        method_46025(ModBlocks.REDSTONE_BRICKS);

        method_46025(ModBlocks.REDSTONE_BRICK_STAIRS);
        method_45988(ModBlocks.REDSTONE_BRICK_SLAB, method_45980(ModBlocks.REDSTONE_BRICK_SLAB));
        method_46025(ModBlocks.REDSTONE_BRICK_FENCE);
        method_46025(ModBlocks.REDSTONE_BRICK_FENCE_GATE);
        method_46025(ModBlocks.REDSTONE_BRICK_WALL);
        method_46025(ModBlocks.POLISHED_REDSTONE_STAIRS);
        method_45988(ModBlocks.POLISHED_REDSTONE_SLAB, method_45980(ModBlocks.POLISHED_REDSTONE_SLAB));
        method_46025(ModBlocks.POLISHED_REDSTONE_FENCE);
        method_46025(ModBlocks.POLISHED_REDSTONE_FENCE_GATE);
        method_46025(ModBlocks.POLISHED_REDSTONE_WALL);
        method_46025(ModBlocks.CALCIFIED_REDSTONE_STAIRS);
        method_45988(ModBlocks.CALCIFIED_REDSTONE_SLAB, method_45980(ModBlocks.CALCIFIED_REDSTONE_SLAB));
        method_46025(ModBlocks.CALCIFIED_REDSTONE_FENCE);
        method_46025(ModBlocks.CALCIFIED_REDSTONE_FENCE_GATE);
        method_46025(ModBlocks.CALCIFIED_REDSTONE_WALL);

        method_46025(ModBlocks.OBSIDIAN_STAIRS);
        method_46025(ModBlocks.OBSIDIAN_FENCE);
        method_46025(ModBlocks.OBSIDIAN_FENCE_GATE);
        method_46025(ModBlocks.OBSIDIAN_WALL);
        method_45988(ModBlocks.OBSIDIAN_SLAB, method_45980(ModBlocks.OBSIDIAN_SLAB));

        method_46025(ModBlocks.PACKED_ICE_STAIRS);
        method_46025(ModBlocks.PACKED_ICE_FENCE);
        method_46025(ModBlocks.PACKED_ICE_FENCE_GATE);
        method_46025(ModBlocks.PACKED_ICE_WALL);
        method_45988(ModBlocks.PACKED_ICE_SLAB, method_45980(ModBlocks.PACKED_ICE_SLAB));

        method_46025(ModBlocks.BLUE_ICE_STAIRS);
        method_46025(ModBlocks.BLUE_ICE_FENCE);
        method_46025(ModBlocks.BLUE_ICE_FENCE_GATE);
        method_46025(ModBlocks.BLUE_ICE_WALL);
        method_45988(ModBlocks.BLUE_ICE_SLAB, method_45980(ModBlocks.BLUE_ICE_SLAB));

        method_46025(ModBlocks.ICE_STAIRS);
        method_46025(ModBlocks.ICE_FENCE);
        method_46025(ModBlocks.ICE_FENCE_GATE);
        method_46025(ModBlocks.ICE_WALL);
        method_45988(ModBlocks.ICE_SLAB, method_45980(ModBlocks.ICE_SLAB));

        method_46025(ModBlocks.DARK_PRISMARINE_WALL);
        method_46025(ModBlocks.PRISMARINE_BRICK_WALL);

        method_46025(ModBlocks.PROTECTOR_BLOCK);
    }

//    public LootTable.Builder multipleOreDrops(Block drop, Item item, float minDrops, float maxDrops) {
//        RegistryWrapper.Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
//        return this.dropsWithSilkTouch(drop, (LootPoolEntry.Builder<?>)this.applyExplosionDecay(drop, ((LeafEntry.Builder<?>)ItemEntry.builder(item)
//                                .apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(minDrops, maxDrops))))
//                                .apply(ApplyBonusLootFunction.oreDrops(impl.getOrThrow(Enchantments.FORTUNE)))
//                )
//        );
//    }
}
