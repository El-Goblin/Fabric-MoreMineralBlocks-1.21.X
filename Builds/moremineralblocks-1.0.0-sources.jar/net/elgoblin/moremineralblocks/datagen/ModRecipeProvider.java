package net.elgoblin.moremineralblocks.datagen;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.block.ModBlocks;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2446;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class ModRecipeProvider extends FabricRecipeProvider {
    public ModRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected class_2446 method_62766(class_7225.class_7874 wrapperLookup, class_8790 recipeExporter) {
        return new class_2446(wrapperLookup, recipeExporter) {
            @Override
            public void method_10419() {
                //List<ItemConvertible> PINK_GARNET_SMELTABLES = List.of(ModItems.RAW_PINK_GARNET, ModBlocks.PINK_GARNET_ORE, ModBlocks.PINK_GARNET_DEEPSLATE_ORE);

                //offerSmelting(exporter, PINK_GARNET_SMELTABLES, RecipeCategory.MISC, ModItems.PINK_GARNET, 0.25f, 200, "pink_garnet");
                //offerBlasting(exporter, PINK_GARNET_SMELTABLES, RecipeCategory.MISC, ModItems.PINK_GARNET, 0.25f, 100, "pink_garnet");

                // Buscar en RecipeProvider.java (haciendo ctrl + click en offerReversibleCompactingRecipes
                //offerReversibleCompactingRecipes(exporter, RecipeCategory.BUILDING_BLOCKS, ModItems.PINK_GARNET, RecipeCategory.DECORATIONS, ModBlocks.PINK_GARNET_BLOCK);

                //ShapedRecipeJsonBuilder.create(RecipeCategory.MISC, ModBlocks.RAW_PINK_GARNET_BLOCK)
                //        .pattern("RRR")
                //        .pattern("RRR")
                //        .pattern("RRR")
                //        .input('R', ModItems.RAW_PINK_GARNET)
                //        .criterion(hasItem(ModItems.RAW_PINK_GARNET), conditionsFromItem(ModItems.RAW_PINK_GARNET))
                //        .offerTo(exporter);

                //ShapelessRecipeJsonBuilder.create(RecipeCategory.MISC, ModItems.RAW_PINK_GARNET, 9)
                //        .input(ModBlocks.RAW_PINK_GARNET_BLOCK)
                //        .criterion(hasItem(ModBlocks.RAW_PINK_GARNET_BLOCK), conditionsFromItem(ModBlocks.RAW_PINK_GARNET_BLOCK))
                //        .offerTo(exporter);

                // Aca le agregamos un identifier para que cambie el nombre del json
                // Por default le pone el nombre del resultado para este tipo de crafteo pero como seria el mismo que el de arriba habria quilombo
                //ShapelessRecipeJsonBuilder.create(RecipeCategory.MISC, ModItems.RAW_PINK_GARNET, 32)
                //        .input(ModBlocks.MAGIC_BLOCK)
                //        .criterion(hasItem(ModBlocks.MAGIC_BLOCK), conditionsFromItem(ModBlocks.MAGIC_BLOCK))
                //        .offerTo(exporter, Identifier.of(MoreMineralBlocks.MOD_ID, "raw_pink_garnet_from_magic_block"));

                //createStairsRecipe(ModBlocks.PINK_GARNET_STAIRS, Ingredient.ofItems(ModBlocks.PINK_GARNET_BLOCK))
                //        .criterion(hasItem(ModBlocks.PINK_GARNET_BLOCK), conditionsFromItem(ModBlocks.PINK_GARNET_BLOCK))
                //        .offerTo(exporter);
                //offerSlabRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, ModBlocks.PINK_GARNET_SLAB, ModBlocks.PINK_GARNET_BLOCK);
                //createFenceRecipe(ModBlocks.PINK_GARNET_FENCE, Ingredient.ofItems(ModBlocks.PINK_GARNET_BLOCK))
                //        .criterion(hasItem(ModBlocks.PINK_GARNET_BLOCK), conditionsFromItem(ModBlocks.PINK_GARNET_BLOCK))
                //        .offerTo(exporter);
                //createFenceGateRecipe(ModBlocks.PINK_GARNET_FENCE_GATE, Ingredient.ofItems(ModBlocks.PINK_GARNET_BLOCK));

                // GOLD

                method_36234(List.of(class_2246.field_10445), class_7800.field_40634, class_2246.field_10340, 0.10F, 100, "stone");
                method_36234(List.of(class_2246.field_10515), class_7800.field_40634, class_1802.field_8729, 0.10F, 100, "nether_brick");

                BlockPack goldPack = new BlockPack(
                        ModBlocks.GOLD_STAIRS,
                        ModBlocks.GOLD_SLAB,
                        ModBlocks.GOLD_WALL,
                        ModBlocks.GOLD_FENCE,
                        ModBlocks.GOLD_FENCE_GATE,
                        class_2246.field_10205
                );
                goldPack.createPackRecipes(this, field_53721);

                BlockPack goldBrickPack = new BlockPack(
                        ModBlocks.GOLD_BRICK_STAIRS,
                        ModBlocks.GOLD_BRICK_SLAB,
                        ModBlocks.GOLD_BRICK_WALL,
                        ModBlocks.GOLD_BRICK_FENCE,
                        ModBlocks.GOLD_BRICK_FENCE_GATE,
                        ModBlocks.GOLD_BRICKS
                );
                goldBrickPack.createPackRecipes(this, field_53721);

                BlockPack calcifiedGoldPack = new BlockPack(
                        ModBlocks.CALCIFIED_GOLD_STAIRS,
                        ModBlocks.CALCIFIED_GOLD_SLAB,
                        ModBlocks.CALCIFIED_GOLD_WALL,
                        ModBlocks.CALCIFIED_GOLD_FENCE,
                        ModBlocks.CALCIFIED_GOLD_FENCE_GATE,
                        ModBlocks.CALCIFIED_GOLD_BLOCK
                );
                calcifiedGoldPack.createPackRecipes(this, field_53721);

                BlockPack polishedGoldPack = new BlockPack(
                        ModBlocks.POLISHED_GOLD_STAIRS,
                        ModBlocks.POLISHED_GOLD_SLAB,
                        ModBlocks.POLISHED_GOLD_WALL,
                        ModBlocks.POLISHED_GOLD_FENCE,
                        ModBlocks.POLISHED_GOLD_FENCE_GATE,
                        ModBlocks.POLISHED_GOLD_BLOCK
                );
                polishedGoldPack.createPackRecipes(this, field_53721);

                DoorPack goldDoorPack = new DoorPack(ModBlocks.GOLD_TRAPDOOR, ModBlocks.GOLD_DOOR, class_1802.field_8695, class_1802.field_8695);
                goldDoorPack.createPackRecipes(this, field_53721);

                method_33717(class_7800.field_40634, ModBlocks.POLISHED_GOLD_BLOCK, class_2246.field_10205);

                method_62750(class_7800.field_40634, ModBlocks.CALCIFIED_GOLD_BLOCK, 2)
                        .method_10454(class_2246.field_10205)
                        .method_10454(class_2246.field_27114)
                        .method_10442(method_32807(class_2246.field_10205), method_10426(class_2246.field_10205))
                        .method_10442(method_32807(class_2246.field_27114), method_10426(class_2246.field_27114))
                        .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.GOLD_BRICKS, 4)
                        .method_10439("RR")
                        .method_10439("RR")
                        .method_10434('R',class_2246.field_10205)
                        .method_10429(method_32807(class_2246.field_10205), method_10426(class_2246.field_10205))
                        .method_10431(field_53721);

                method_33717(class_7800.field_40634, ModBlocks.GOLD_BRICKS, class_2246.field_10205);

                // DIAMOND

                BlockPack diamondPack = new BlockPack(
                        ModBlocks.DIAMOND_STAIRS,
                        ModBlocks.DIAMOND_SLAB,
                        ModBlocks.DIAMOND_WALL,
                        ModBlocks.DIAMOND_FENCE,
                        ModBlocks.DIAMOND_FENCE_GATE,
                        class_2246.field_10201
                );
                diamondPack.createPackRecipes(this, field_53721);

                BlockPack diamondBrickPack = new BlockPack(
                        ModBlocks.DIAMOND_BRICK_STAIRS,
                        ModBlocks.DIAMOND_BRICK_SLAB,
                        ModBlocks.DIAMOND_BRICK_WALL,
                        ModBlocks.DIAMOND_BRICK_FENCE,
                        ModBlocks.DIAMOND_BRICK_FENCE_GATE,
                        ModBlocks.DIAMOND_BRICKS
                );
                diamondBrickPack.createPackRecipes(this, field_53721);

                BlockPack calcifiedDiamondPack = new BlockPack(
                        ModBlocks.CALCIFIED_DIAMOND_STAIRS,
                        ModBlocks.CALCIFIED_DIAMOND_SLAB,
                        ModBlocks.CALCIFIED_DIAMOND_WALL,
                        ModBlocks.CALCIFIED_DIAMOND_FENCE,
                        ModBlocks.CALCIFIED_DIAMOND_FENCE_GATE,
                        ModBlocks.CALCIFIED_DIAMOND_BLOCK
                );
                calcifiedDiamondPack.createPackRecipes(this, field_53721);

                BlockPack polishedDiamondPack = new BlockPack(
                        ModBlocks.POLISHED_DIAMOND_STAIRS,
                        ModBlocks.POLISHED_DIAMOND_SLAB,
                        ModBlocks.POLISHED_DIAMOND_WALL,
                        ModBlocks.POLISHED_DIAMOND_FENCE,
                        ModBlocks.POLISHED_DIAMOND_FENCE_GATE,
                        ModBlocks.POLISHED_DIAMOND_BLOCK
                );
                polishedDiamondPack.createPackRecipes(this, field_53721);

                DoorPack diamondDoorPack = new DoorPack(ModBlocks.DIAMOND_TRAPDOOR, ModBlocks.DIAMOND_DOOR, class_1802.field_8477, class_1802.field_8477);
                diamondDoorPack.createPackRecipes(this, field_53721);

                method_33717(class_7800.field_40634, ModBlocks.POLISHED_DIAMOND_BLOCK, class_2246.field_10201);

                method_62750(class_7800.field_40634, ModBlocks.CALCIFIED_DIAMOND_BLOCK, 2)
                        .method_10454(class_2246.field_10201)
                        .method_10454(class_2246.field_27114)
                        .method_10442(method_32807(class_2246.field_10201), method_10426(class_2246.field_10201))
                        .method_10442(method_32807(class_2246.field_27114), method_10426(class_2246.field_27114))
                        .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.DIAMOND_BRICKS, 4)
                        .method_10439("RR")
                        .method_10439("RR")
                        .method_10434('R',class_2246.field_10201)
                        .method_10429(method_32807(class_2246.field_10201), method_10426(class_2246.field_10201))
                        .method_10431(field_53721);

                method_33717(class_7800.field_40634, ModBlocks.DIAMOND_BRICKS, class_2246.field_10201);

                // IRON

                BlockPack ironPack = new BlockPack(
                        ModBlocks.IRON_STAIRS,
                        ModBlocks.IRON_SLAB,
                        ModBlocks.IRON_WALL,
                        ModBlocks.IRON_FENCE,
                        ModBlocks.IRON_FENCE_GATE,
                        class_2246.field_10085
                );
                ironPack.createPackRecipes(this, field_53721);

                BlockPack ironBrickPack = new BlockPack(
                        ModBlocks.IRON_BRICK_STAIRS,
                        ModBlocks.IRON_BRICK_SLAB,
                        ModBlocks.IRON_BRICK_WALL,
                        ModBlocks.IRON_BRICK_FENCE,
                        ModBlocks.IRON_BRICK_FENCE_GATE,
                        ModBlocks.IRON_BRICKS
                );
                ironBrickPack.createPackRecipes(this, field_53721);

                BlockPack calcifiedIronPack = new BlockPack(
                        ModBlocks.CALCIFIED_IRON_STAIRS,
                        ModBlocks.CALCIFIED_IRON_SLAB,
                        ModBlocks.CALCIFIED_IRON_WALL,
                        ModBlocks.CALCIFIED_IRON_FENCE,
                        ModBlocks.CALCIFIED_IRON_FENCE_GATE,
                        ModBlocks.CALCIFIED_IRON_BLOCK
                );
                calcifiedIronPack.createPackRecipes(this, field_53721);

                BlockPack polishedIronPack = new BlockPack(
                        ModBlocks.POLISHED_IRON_STAIRS,
                        ModBlocks.POLISHED_IRON_SLAB,
                        ModBlocks.POLISHED_IRON_WALL,
                        ModBlocks.POLISHED_IRON_FENCE,
                        ModBlocks.POLISHED_IRON_FENCE_GATE,
                        ModBlocks.POLISHED_IRON_BLOCK
                );
                polishedIronPack.createPackRecipes(this, field_53721);

                method_33717(class_7800.field_40634, ModBlocks.POLISHED_IRON_BLOCK, class_2246.field_10085);

                method_62750(class_7800.field_40634, ModBlocks.CALCIFIED_IRON_BLOCK, 2)
                        .method_10454(class_2246.field_10085)
                        .method_10454(class_2246.field_27114)
                        .method_10442(method_32807(class_2246.field_10085), method_10426(class_2246.field_10085))
                        .method_10442(method_32807(class_2246.field_27114), method_10426(class_2246.field_27114))
                        .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.IRON_BRICKS, 4)
                        .method_10439("RR")
                        .method_10439("RR")
                        .method_10434('R',class_2246.field_10085)
                        .method_10429(method_32807(class_2246.field_10085), method_10426(class_2246.field_10085))
                        .method_10431(field_53721);

                method_33717(class_7800.field_40634, ModBlocks.IRON_BRICKS, class_2246.field_10085);

                // EMERALD

                BlockPack emeraldPack = new BlockPack(
                        ModBlocks.EMERALD_STAIRS,
                        ModBlocks.EMERALD_SLAB,
                        ModBlocks.EMERALD_WALL,
                        ModBlocks.EMERALD_FENCE,
                        ModBlocks.EMERALD_FENCE_GATE,
                        class_2246.field_10234
                );
                emeraldPack.createPackRecipes(this, field_53721);

                BlockPack emeraldBrickPack = new BlockPack(
                        ModBlocks.EMERALD_BRICK_STAIRS,
                        ModBlocks.EMERALD_BRICK_SLAB,
                        ModBlocks.EMERALD_BRICK_WALL,
                        ModBlocks.EMERALD_BRICK_FENCE,
                        ModBlocks.EMERALD_BRICK_FENCE_GATE,
                        ModBlocks.EMERALD_BRICKS
                );
                emeraldBrickPack.createPackRecipes(this, field_53721);

                BlockPack calcifiedEmeraldPack = new BlockPack(
                        ModBlocks.CALCIFIED_EMERALD_STAIRS,
                        ModBlocks.CALCIFIED_EMERALD_SLAB,
                        ModBlocks.CALCIFIED_EMERALD_WALL,
                        ModBlocks.CALCIFIED_EMERALD_FENCE,
                        ModBlocks.CALCIFIED_EMERALD_FENCE_GATE,
                        ModBlocks.CALCIFIED_EMERALD_BLOCK
                );
                calcifiedEmeraldPack.createPackRecipes(this, field_53721);

                BlockPack polishedEmeraldPack = new BlockPack(
                        ModBlocks.POLISHED_EMERALD_STAIRS,
                        ModBlocks.POLISHED_EMERALD_SLAB,
                        ModBlocks.POLISHED_EMERALD_WALL,
                        ModBlocks.POLISHED_EMERALD_FENCE,
                        ModBlocks.POLISHED_EMERALD_FENCE_GATE,
                        ModBlocks.POLISHED_EMERALD_BLOCK
                );
                polishedEmeraldPack.createPackRecipes(this, field_53721);

                BlockPack chiseledEmeraldPack = new BlockPack(
                        ModBlocks.CHISELED_EMERALD_STAIRS,
                        ModBlocks.CHISELED_EMERALD_SLAB,
                        ModBlocks.CHISELED_EMERALD_WALL,
                        ModBlocks.CHISELED_EMERALD_FENCE,
                        ModBlocks.CHISELED_EMERALD_FENCE_GATE,
                        ModBlocks.CHISELED_EMERALD_BLOCK
                );
                chiseledEmeraldPack.createPackRecipes(this, field_53721);

                DoorPack emeraldDoorPack = new DoorPack(ModBlocks.EMERALD_TRAPDOOR, ModBlocks.EMERALD_DOOR, class_1802.field_8687, class_1802.field_8687);
                emeraldDoorPack.createPackRecipes(this, field_53721);

                method_33717(class_7800.field_40634, ModBlocks.POLISHED_EMERALD_BLOCK, class_2246.field_10234);

                method_33717(class_7800.field_40634, ModBlocks.CHISELED_EMERALD_BLOCK, class_2246.field_10234);

                method_62750(class_7800.field_40634, ModBlocks.CALCIFIED_EMERALD_BLOCK, 2)
                        .method_10454(class_2246.field_10234)
                        .method_10454(class_2246.field_27114)
                        .method_10442(method_32807(class_2246.field_10234), method_10426(class_2246.field_10234))
                        .method_10442(method_32807(class_2246.field_27114), method_10426(class_2246.field_27114))
                        .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.EMERALD_BRICKS, 4)
                        .method_10439("RR")
                        .method_10439("RR")
                        .method_10434('R',class_2246.field_10234)
                        .method_10429(method_32807(class_2246.field_10234), method_10426(class_2246.field_10234))
                        .method_10431(field_53721);

                method_33717(class_7800.field_40634, ModBlocks.EMERALD_BRICKS, class_2246.field_10234);

                // LAPIS

                BlockPack lapisPack = new BlockPack(
                        ModBlocks.LAPIS_STAIRS,
                        ModBlocks.LAPIS_SLAB,
                        ModBlocks.LAPIS_WALL,
                        ModBlocks.LAPIS_FENCE,
                        ModBlocks.LAPIS_FENCE_GATE,
                        class_2246.field_10441
                );
                lapisPack.createPackRecipes(this, field_53721);

                BlockPack lapisBrickPack = new BlockPack(
                        ModBlocks.LAPIS_BRICK_STAIRS,
                        ModBlocks.LAPIS_BRICK_SLAB,
                        ModBlocks.LAPIS_BRICK_WALL,
                        ModBlocks.LAPIS_BRICK_FENCE,
                        ModBlocks.LAPIS_BRICK_FENCE_GATE,
                        ModBlocks.LAPIS_BRICKS
                );
                lapisBrickPack.createPackRecipes(this, field_53721);

                BlockPack calcifiedLapisPack = new BlockPack(
                        ModBlocks.CALCIFIED_LAPIS_STAIRS,
                        ModBlocks.CALCIFIED_LAPIS_SLAB,
                        ModBlocks.CALCIFIED_LAPIS_WALL,
                        ModBlocks.CALCIFIED_LAPIS_FENCE,
                        ModBlocks.CALCIFIED_LAPIS_FENCE_GATE,
                        ModBlocks.CALCIFIED_LAPIS_BLOCK
                );
                calcifiedLapisPack.createPackRecipes(this, field_53721);

                BlockPack polishedLapisPack = new BlockPack(
                        ModBlocks.POLISHED_LAPIS_STAIRS,
                        ModBlocks.POLISHED_LAPIS_SLAB,
                        ModBlocks.POLISHED_LAPIS_WALL,
                        ModBlocks.POLISHED_LAPIS_FENCE,
                        ModBlocks.POLISHED_LAPIS_FENCE_GATE,
                        ModBlocks.POLISHED_LAPIS_BLOCK
                );
                polishedLapisPack.createPackRecipes(this, field_53721);

                DoorPack lapisDoorPack = new DoorPack(ModBlocks.LAPIS_TRAPDOOR, ModBlocks.LAPIS_DOOR, class_1802.field_8759, class_1802.field_8759);
                lapisDoorPack.createPackRecipes(this, field_53721);

                method_33717(class_7800.field_40634, ModBlocks.POLISHED_LAPIS_BLOCK, class_2246.field_10441);

                method_62750(class_7800.field_40634, ModBlocks.CALCIFIED_LAPIS_BLOCK, 2)
                        .method_10454(class_2246.field_10441)
                        .method_10454(class_2246.field_27114)
                        .method_10442(method_32807(class_2246.field_10441), method_10426(class_2246.field_10441))
                        .method_10442(method_32807(class_2246.field_27114), method_10426(class_2246.field_27114))
                        .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.LAPIS_BRICKS, 4)
                        .method_10439("RR")
                        .method_10439("RR")
                        .method_10434('R',class_2246.field_10441)
                        .method_10429(method_32807(class_2246.field_10441), method_10426(class_2246.field_10441))
                        .method_10431(field_53721);

                method_33717(class_7800.field_40634, ModBlocks.LAPIS_BRICKS, class_2246.field_10441);

                // COAL

                BlockPack coalPack = new BlockPack(
                        ModBlocks.COAL_STAIRS,
                        ModBlocks.COAL_SLAB,
                        ModBlocks.COAL_WALL,
                        ModBlocks.COAL_FENCE,
                        ModBlocks.COAL_FENCE_GATE,
                        class_2246.field_10381
                );
                coalPack.createPackRecipes(this, field_53721);

                BlockPack coalBrickPack = new BlockPack(
                        ModBlocks.COAL_BRICK_STAIRS,
                        ModBlocks.COAL_BRICK_SLAB,
                        ModBlocks.COAL_BRICK_WALL,
                        ModBlocks.COAL_BRICK_FENCE,
                        ModBlocks.COAL_BRICK_FENCE_GATE,
                        ModBlocks.COAL_BRICKS
                );
                coalBrickPack.createPackRecipes(this, field_53721);

                BlockPack calcifiedCoalPack = new BlockPack(
                        ModBlocks.CALCIFIED_COAL_STAIRS,
                        ModBlocks.CALCIFIED_COAL_SLAB,
                        ModBlocks.CALCIFIED_COAL_WALL,
                        ModBlocks.CALCIFIED_COAL_FENCE,
                        ModBlocks.CALCIFIED_COAL_FENCE_GATE,
                        ModBlocks.CALCIFIED_COAL_BLOCK
                );
                calcifiedCoalPack.createPackRecipes(this, field_53721);

                BlockPack polishedCoalPack = new BlockPack(
                        ModBlocks.POLISHED_COAL_STAIRS,
                        ModBlocks.POLISHED_COAL_SLAB,
                        ModBlocks.POLISHED_COAL_WALL,
                        ModBlocks.POLISHED_COAL_FENCE,
                        ModBlocks.POLISHED_COAL_FENCE_GATE,
                        ModBlocks.POLISHED_COAL_BLOCK
                );
                polishedCoalPack.createPackRecipes(this, field_53721);

                DoorPack coalDoorPack = new DoorPack(ModBlocks.COAL_TRAPDOOR, ModBlocks.COAL_DOOR, class_1802.field_8713, class_1802.field_8713);
                coalDoorPack.createPackRecipes(this, field_53721);

                method_33717(class_7800.field_40634, ModBlocks.POLISHED_COAL_BLOCK, class_2246.field_10381);

                method_62750(class_7800.field_40634, ModBlocks.CALCIFIED_COAL_BLOCK, 2)
                        .method_10454(class_2246.field_10381)
                        .method_10454(class_2246.field_27114)
                        .method_10442(method_32807(class_2246.field_10381), method_10426(class_2246.field_10381))
                        .method_10442(method_32807(class_2246.field_27114), method_10426(class_2246.field_27114))
                        .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.COAL_BRICKS, 4)
                        .method_10439("RR")
                        .method_10439("RR")
                        .method_10434('R',class_2246.field_10381)
                        .method_10429(method_32807(class_2246.field_10381), method_10426(class_2246.field_10381))
                        .method_10431(field_53721);

                method_33717(class_7800.field_40634, ModBlocks.COAL_BRICKS, class_2246.field_10381);

                // CALCITE

                BlockPack calcitePack = new BlockPack(
                        ModBlocks.CALCITE_STAIRS,
                        ModBlocks.CALCITE_SLAB,
                        ModBlocks.CALCITE_WALL,
                        ModBlocks.CALCITE_FENCE,
                        ModBlocks.CALCITE_FENCE_GATE,
                        class_2246.field_27114
                );
                calcitePack.createPackRecipes(this, field_53721);

                // NETHERITE

                BlockPack netheritePack = new BlockPack(
                        ModBlocks.NETHERITE_STAIRS,
                        ModBlocks.NETHERITE_SLAB,
                        ModBlocks.NETHERITE_WALL,
                        ModBlocks.NETHERITE_FENCE,
                        ModBlocks.NETHERITE_FENCE_GATE,
                        class_2246.field_22108
                );
                netheritePack.createPackRecipes(this, field_53721);

                BlockPack netheriteBrickPack = new BlockPack(
                        ModBlocks.NETHERITE_BRICK_STAIRS,
                        ModBlocks.NETHERITE_BRICK_SLAB,
                        ModBlocks.NETHERITE_BRICK_WALL,
                        ModBlocks.NETHERITE_BRICK_FENCE,
                        ModBlocks.NETHERITE_BRICK_FENCE_GATE,
                        ModBlocks.NETHERITE_BRICKS
                );
                netheriteBrickPack.createPackRecipes(this, field_53721);

                BlockPack calcifiedNetheritePack = new BlockPack(
                        ModBlocks.CALCIFIED_NETHERITE_STAIRS,
                        ModBlocks.CALCIFIED_NETHERITE_SLAB,
                        ModBlocks.CALCIFIED_NETHERITE_WALL,
                        ModBlocks.CALCIFIED_NETHERITE_FENCE,
                        ModBlocks.CALCIFIED_NETHERITE_FENCE_GATE,
                        ModBlocks.CALCIFIED_NETHERITE_BLOCK
                );
                calcifiedNetheritePack.createPackRecipes(this, field_53721);

                BlockPack polishedNetheritePack = new BlockPack(
                        ModBlocks.POLISHED_NETHERITE_STAIRS,
                        ModBlocks.POLISHED_NETHERITE_SLAB,
                        ModBlocks.POLISHED_NETHERITE_WALL,
                        ModBlocks.POLISHED_NETHERITE_FENCE,
                        ModBlocks.POLISHED_NETHERITE_FENCE_GATE,
                        ModBlocks.POLISHED_NETHERITE_BLOCK
                );
                polishedNetheritePack.createPackRecipes(this, field_53721);

                DoorPack netheriteDoorPack = new DoorPack(ModBlocks.NETHERITE_TRAPDOOR, ModBlocks.NETHERITE_DOOR, class_1802.field_22020, class_1802.field_22020);
                netheriteDoorPack.createPackRecipes(this, field_53721);

                method_33717(class_7800.field_40634, ModBlocks.POLISHED_NETHERITE_BLOCK, class_2246.field_22108);

                method_62750(class_7800.field_40634, ModBlocks.CALCIFIED_NETHERITE_BLOCK, 2)
                        .method_10454(class_2246.field_22108)
                        .method_10454(class_2246.field_27114)
                        .method_10442(method_32807(class_2246.field_22108), method_10426(class_2246.field_22108))
                        .method_10442(method_32807(class_2246.field_27114), method_10426(class_2246.field_27114))
                        .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.NETHERITE_BRICKS, 4)
                        .method_10439("RR")
                        .method_10439("RR")
                        .method_10434('R',class_2246.field_22108)
                        .method_10429(method_32807(class_2246.field_22108), method_10426(class_2246.field_22108))
                        .method_10431(field_53721);

                method_33717(class_7800.field_40634, ModBlocks.NETHERITE_BRICKS, class_2246.field_22108);

                // AMETHYST

                BlockPack amethystPack = new BlockPack(
                        ModBlocks.AMETHYST_STAIRS,
                        ModBlocks.AMETHYST_SLAB,
                        ModBlocks.AMETHYST_WALL,
                        ModBlocks.AMETHYST_FENCE,
                        ModBlocks.AMETHYST_FENCE_GATE,
                        class_2246.field_27159
                );
                amethystPack.createPackRecipes(this, field_53721);

                BlockPack amethystBrickPack = new BlockPack(
                        ModBlocks.AMETHYST_BRICK_STAIRS,
                        ModBlocks.AMETHYST_BRICK_SLAB,
                        ModBlocks.AMETHYST_BRICK_WALL,
                        ModBlocks.AMETHYST_BRICK_FENCE,
                        ModBlocks.AMETHYST_BRICK_FENCE_GATE,
                        ModBlocks.AMETHYST_BRICKS
                );
                amethystBrickPack.createPackRecipes(this, field_53721);

                BlockPack calcifiedAmethystPack = new BlockPack(
                        ModBlocks.CALCIFIED_AMETHYST_STAIRS,
                        ModBlocks.CALCIFIED_AMETHYST_SLAB,
                        ModBlocks.CALCIFIED_AMETHYST_WALL,
                        ModBlocks.CALCIFIED_AMETHYST_FENCE,
                        ModBlocks.CALCIFIED_AMETHYST_FENCE_GATE,
                        ModBlocks.CALCIFIED_AMETHYST_BLOCK
                );
                calcifiedAmethystPack.createPackRecipes(this, field_53721);

                BlockPack polishedAmethystPack = new BlockPack(
                        ModBlocks.POLISHED_AMETHYST_STAIRS,
                        ModBlocks.POLISHED_AMETHYST_SLAB,
                        ModBlocks.POLISHED_AMETHYST_WALL,
                        ModBlocks.POLISHED_AMETHYST_FENCE,
                        ModBlocks.POLISHED_AMETHYST_FENCE_GATE,
                        ModBlocks.POLISHED_AMETHYST_BLOCK
                );
                polishedAmethystPack.createPackRecipes(this, field_53721);

                // ESTA ES DISTINTA PORQUE SE HACEN BLOQUES DE AMATISTA DE LA OTRA FORMA
                method_62746(class_7800.field_40634, ModBlocks.AMETHYST_TRAPDOOR)
                        .method_10439("RRR")
                        .method_10439("RRR")
                        .method_10434('R', class_1802.field_27063)
                        .method_10429(method_32807(class_1802.field_27063), method_10426(class_1802.field_27063))
                        .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.AMETHYST_DOOR, 3)
                        .method_10439("RR")
                        .method_10439("RR")
                        .method_10439("RR")
                        .method_10434('R',class_1802.field_27063)
                        .method_10429(method_32807(class_1802.field_27063), method_10426(class_1802.field_27063))
                        .method_10431(field_53721);

                method_62750(class_7800.field_40642, class_1802.field_27063, 4)
                        .method_10454(class_2246.field_27159)
                        .method_10442(method_32807(class_2246.field_27159), method_10426(class_2246.field_27159))
                        .method_10431(field_53721);

                method_33717(class_7800.field_40634, ModBlocks.POLISHED_AMETHYST_BLOCK, class_2246.field_27159);

                method_62750(class_7800.field_40634, ModBlocks.CALCIFIED_AMETHYST_BLOCK, 2)
                        .method_10454(class_2246.field_27159)
                        .method_10454(class_2246.field_27114)
                        .method_10442(method_32807(class_2246.field_27159), method_10426(class_2246.field_27159))
                        .method_10442(method_32807(class_2246.field_27114), method_10426(class_2246.field_27114))
                        .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.AMETHYST_BRICKS, 4)
                        .method_10439("RR")
                        .method_10439("RR")
                        .method_10434('R',class_2246.field_27159)
                        .method_10429(method_32807(class_2246.field_27159), method_10426(class_2246.field_27159))
                        .method_10431(field_53721);

                method_33717(class_7800.field_40634, ModBlocks.AMETHYST_BRICKS, class_2246.field_27159);

                // REDSTONE

                BlockPack redstonePack = new BlockPack(
                        ModBlocks.REDSTONE_STAIRS,
                        ModBlocks.REDSTONE_SLAB,
                        ModBlocks.REDSTONE_WALL,
                        ModBlocks.REDSTONE_FENCE,
                        ModBlocks.REDSTONE_FENCE_GATE,
                        class_2246.field_10002
                );
                redstonePack.createPackRecipes(this, field_53721);

                BlockPack redstoneBrickPack = new BlockPack(
                        ModBlocks.REDSTONE_BRICK_STAIRS,
                        ModBlocks.REDSTONE_BRICK_SLAB,
                        ModBlocks.REDSTONE_BRICK_WALL,
                        ModBlocks.REDSTONE_BRICK_FENCE,
                        ModBlocks.REDSTONE_BRICK_FENCE_GATE,
                        ModBlocks.REDSTONE_BRICKS
                );
                redstoneBrickPack.createPackRecipes(this, field_53721);

                BlockPack calcifiedRedstonePack = new BlockPack(
                        ModBlocks.CALCIFIED_REDSTONE_STAIRS,
                        ModBlocks.CALCIFIED_REDSTONE_SLAB,
                        ModBlocks.CALCIFIED_REDSTONE_WALL,
                        ModBlocks.CALCIFIED_REDSTONE_FENCE,
                        ModBlocks.CALCIFIED_REDSTONE_FENCE_GATE,
                        ModBlocks.CALCIFIED_REDSTONE_BLOCK
                );
                calcifiedRedstonePack.createPackRecipes(this, field_53721);

                BlockPack polishedRedstonePack = new BlockPack(
                        ModBlocks.POLISHED_REDSTONE_STAIRS,
                        ModBlocks.POLISHED_REDSTONE_SLAB,
                        ModBlocks.POLISHED_REDSTONE_WALL,
                        ModBlocks.POLISHED_REDSTONE_FENCE,
                        ModBlocks.POLISHED_REDSTONE_FENCE_GATE,
                        ModBlocks.POLISHED_REDSTONE_BLOCK
                );
                polishedRedstonePack.createPackRecipes(this, field_53721);

                DoorPack redstoneDoorPack = new DoorPack(ModBlocks.REDSTONE_TRAPDOOR, ModBlocks.REDSTONE_DOOR, class_1802.field_8725, class_1802.field_8725);
                redstoneDoorPack.createPackRecipes(this, field_53721);

                method_33717(class_7800.field_40634, ModBlocks.POLISHED_REDSTONE_BLOCK, class_2246.field_10002);

                method_62750(class_7800.field_40634, ModBlocks.CALCIFIED_REDSTONE_BLOCK, 2)
                        .method_10454(class_2246.field_10002)
                        .method_10454(class_2246.field_27114)
                        .method_10442(method_32807(class_2246.field_10002), method_10426(class_2246.field_10002))
                        .method_10442(method_32807(class_2246.field_27114), method_10426(class_2246.field_27114))
                        .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.REDSTONE_BRICKS, 4)
                        .method_10439("RR")
                        .method_10439("RR")
                        .method_10434('R',class_2246.field_10002)
                        .method_10429(method_32807(class_2246.field_10002), method_10426(class_2246.field_10002))
                        .method_10431(field_53721);

                method_33717(class_7800.field_40634, ModBlocks.REDSTONE_BRICKS, class_2246.field_10002);

                // OBSIDIAN

                BlockPack obsidianPack = new BlockPack(
                        ModBlocks.OBSIDIAN_STAIRS,
                        ModBlocks.OBSIDIAN_SLAB,
                        ModBlocks.OBSIDIAN_WALL,
                        ModBlocks.OBSIDIAN_FENCE,
                        ModBlocks.OBSIDIAN_FENCE_GATE,
                        class_2246.field_10540
                );
                obsidianPack.createPackRecipes(this, field_53721);

                // BEDROCK

                BlockPack bedrockPack = new BlockPack(
                        ModBlocks.BEDROCK_STAIRS,
                        ModBlocks.BEDROCK_SLAB,
                        ModBlocks.BEDROCK_WALL,
                        ModBlocks.BEDROCK_FENCE,
                        ModBlocks.BEDROCK_FENCE_GATE,
                        class_2246.field_9987
                );
                bedrockPack.createPackRecipes(this, field_53721);

                // SCULK

                BlockPack sculkPack = new BlockPack(
                        ModBlocks.SCULK_STAIRS,
                        ModBlocks.SCULK_SLAB,
                        ModBlocks.SCULK_WALL,
                        ModBlocks.SCULK_FENCE,
                        ModBlocks.SCULK_FENCE_GATE,
                        class_2246.field_37568
                );
                sculkPack.createPackRecipes(this, field_53721);

                // PACKED ICE

                BlockPack packedIcePack = new BlockPack(
                        ModBlocks.PACKED_ICE_STAIRS,
                        ModBlocks.PACKED_ICE_SLAB,
                        ModBlocks.PACKED_ICE_WALL,
                        ModBlocks.PACKED_ICE_FENCE,
                        ModBlocks.PACKED_ICE_FENCE_GATE,
                        class_2246.field_10225
                );
                packedIcePack.createPackRecipes(this, field_53721);

                // BLUE ICE

                BlockPack blueIcePack = new BlockPack(
                        ModBlocks.BLUE_ICE_STAIRS,
                        ModBlocks.BLUE_ICE_SLAB,
                        ModBlocks.BLUE_ICE_WALL,
                        ModBlocks.BLUE_ICE_FENCE,
                        ModBlocks.BLUE_ICE_FENCE_GATE,
                        class_2246.field_10384
                );
                blueIcePack.createPackRecipes(this, field_53721);

                // ICE

                BlockPack icePack = new BlockPack(
                        ModBlocks.ICE_STAIRS,
                        ModBlocks.ICE_SLAB,
                        ModBlocks.ICE_WALL,
                        ModBlocks.ICE_FENCE,
                        ModBlocks.ICE_FENCE_GATE,
                        class_2246.field_10295
                );
                icePack.createPackRecipes(this, field_53721);

                // PRISMARINE

                method_32809(class_7800.field_40634, ModBlocks.PRISMARINE_BRICK_WALL, class_2246.field_10006);
                method_32809(class_7800.field_40634, ModBlocks.DARK_PRISMARINE_WALL, class_2246.field_10297);
                method_33717(class_7800.field_40634, ModBlocks.PRISMARINE_BRICK_WALL, class_2246.field_10006);
                method_33717(class_7800.field_40634, ModBlocks.DARK_PRISMARINE_WALL, class_2246.field_10297);

                // OTHER

                method_62750(class_7800.field_40637, ModItems.MAGIC_MIRROR, 1)
                        .method_10454(ModItems.REFLECTIVE_MIRROR)
                        .method_10442(method_32807(ModItems.REFLECTIVE_MIRROR), method_10426(ModItems.REFLECTIVE_MIRROR))
                        .method_10431(field_53721);

                method_62750(class_7800.field_40634, class_1802.field_29025, 1)
                        .method_10454(class_1802.field_28866)
                        .method_10442(method_32807(class_1802.field_28866), method_10426(class_1802.field_28866))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.WOODEN_LONGSWORD)
                        .method_10439("  P")
                        .method_10439(" P ")
                        .method_10439("S  ")
                        .method_10434('S', class_1802.field_8091)
                        .method_10433('P', class_3489.field_15537)
                        .method_10429(method_32807(class_1802.field_8091), method_10426(class_1802.field_8091))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.STONE_LONGSWORD)
                        .method_10439("  C")
                        .method_10439(" C ")
                        .method_10439("S  ")
                        .method_10434('S', class_1802.field_8528)
                        .method_10433('C', class_3489.field_23802)
                        .method_10429(method_32807(class_1802.field_8528), method_10426(class_1802.field_8528))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.COPPER_LONGSWORD)
                        .method_10439("  C")
                        .method_10439(" C ")
                        .method_10439("S  ")
                        .method_10434('S', class_1802.field_61338)
                        .method_10433('C', class_3489.field_61216)
                        .method_10429(method_32807(class_1802.field_61338), method_10426(class_1802.field_61338))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.IRON_LONGSWORD)
                        .method_10439("  I")
                        .method_10439(" I ")
                        .method_10439("S  ")
                        .method_10434('S', class_1802.field_8371)
                        .method_10434('I', class_1802.field_8620)
                        .method_10429(method_32807(class_1802.field_8371), method_10426(class_1802.field_8371))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.GOLDEN_LONGSWORD)
                        .method_10439("  G")
                        .method_10439(" G ")
                        .method_10439("S  ")
                        .method_10434('S', class_1802.field_8845)
                        .method_10434('G', class_1802.field_8695)
                        .method_10429(method_32807(class_1802.field_8845), method_10426(class_1802.field_8845))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.DIAMOND_LONGSWORD)
                        .method_10439("  D")
                        .method_10439(" D ")
                        .method_10439("S  ")
                        .method_10434('S', class_1802.field_8802)
                        .method_10434('D', class_1802.field_8477)
                        .method_10429(method_32807(class_1802.field_8802), method_10426(class_1802.field_8802))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40635, ModBlocks.PROTECTOR_BLOCK)
                        .method_10439("DED")
                        .method_10439("DHD")
                        .method_10439("ABA")
                        .method_10434('D', class_2246.field_10201)
                        .method_10434('E', class_1802.field_8301)
                        .method_10434('H', class_1802.field_49813)
                        .method_10434('B', class_2246.field_10327)
                        .method_10434('A', class_2246.field_23152)
                        .method_10429(method_32807(class_2246.field_10201), method_10426(class_2246.field_10201))
                        .method_10429(method_32807(class_2246.field_10327), method_10426(class_2246.field_10327))
                        .method_10429(method_32807(class_2246.field_23152), method_10426(class_2246.field_23152))
                        .method_10429(method_32807(class_1802.field_8301), method_10426(class_1802.field_8301))
                        .method_10429(method_32807(class_1802.field_49813), method_10426(class_1802.field_49813))
                        .method_10431(field_53721);

                method_29728(ModItems.DIAMOND_LONGSWORD, class_7800.field_40639,ModItems.NETHERITE_LONGSWORD);
            }
        };
    }

    @Override
    public String method_10321() {
        return MoreMineralBlocks.MOD_ID + " Recipes";
    }

    private record BlockPack(
            class_1935 stairs,
            class_1935 slab,
            class_1935 wall,
            class_1935 fence,
            class_1935 fenceGate,
            class_2248 baseBlock

    ) {
        public void createPackRecipes(class_2446 generator, class_8790 exporter) {

            generator.method_32808(this.stairs, class_1856.method_8091(this.baseBlock)).method_33530(class_2446.method_32807(this.baseBlock), generator.method_10426(this.baseBlock)).method_10431(exporter);
            generator.method_33717(class_7800.field_40634, this.stairs, this.baseBlock);
            generator.method_32814(class_7800.field_40634, this.slab, this.baseBlock);
            generator.method_33715(class_7800.field_40634, this.slab, this.baseBlock, 2);
            generator.method_33546(this.fence, class_1856.method_8091(this.baseBlock)).method_33530(class_2446.method_32807(this.baseBlock), generator.method_10426(this.baseBlock)).method_10431(exporter);
            generator.method_33715(class_7800.field_40634, this.fence, this.baseBlock, 2);
            generator.method_33548(this.fenceGate, class_1856.method_8091(this.baseBlock)).method_33530(class_2446.method_32807(this.baseBlock), generator.method_10426(this.baseBlock)).method_10431(exporter);
            generator.method_33715(class_7800.field_40634, this.fenceGate, this.baseBlock, 2);
            generator.method_32809(class_7800.field_40634, this.wall, this.baseBlock);
            generator.method_33717(class_7800.field_40634, this.wall, this.baseBlock);
        }
    }

    private record DoorPack(
            class_1935 trapdoor,
            class_1935 door,
            class_1792 trapDoorIngredient,
            class_1792 doorIngredient
    ) {
        public void createPackRecipes(class_2446 generator, class_8790 exporter) {
            generator.method_62746(class_7800.field_40634, this.trapdoor)
                    .method_10439("RR")
                    .method_10439("RR")
                    .method_10434('R', this.trapDoorIngredient)
                    .method_10429(class_2446.method_32807(this.trapDoorIngredient), generator.method_10426(this.trapDoorIngredient))
                    .method_10431(exporter);

            generator.method_62747(class_7800.field_40634, this.door, 3)
                    .method_10439("RR")
                    .method_10439("RR")
                    .method_10439("RR")
                    .method_10434('R',this.doorIngredient)
                    .method_10429(class_2446.method_32807(this.doorIngredient), generator.method_10426(this.doorIngredient))
                    .method_10431(exporter);
        }
    }


}
