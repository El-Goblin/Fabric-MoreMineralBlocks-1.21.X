package net.elgoblin.moremineralblocks.datagen;

import net.elgoblin.moremineralblocks.item.ModItems;
import net.elgoblin.moremineralblocks.util.ModTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ModItemTagProvider extends FabricTagProvider.ItemTagProvider {
    public ModItemTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        valueLookupBuilder(ModTags.Items.LEGENDARY_TOOLS)
                .method_71554(ModItems.LEGENDARY_AXE)
                .method_71554(ModItems.LEGENDARY_PICKAXE)
                .method_71554(ModItems.LEGENDARY_SHOVEL)
                .method_71554(ModItems.LEGENDARY_SWORD)
                .method_71554(ModItems.LEGENDARY_LONGSWORD)
                .method_71554(ModItems.LEGENDARY_HOE);

        valueLookupBuilder(ModTags.Items.LEGENDARY_REPAIR);

        valueLookupBuilder(ModTags.Items.LONGSWORDS).method_71554(ModItems.LEGENDARY_LONGSWORD);
        valueLookupBuilder(ModTags.Items.LONGSWORDS).method_71554(ModItems.WOODEN_LONGSWORD);
        valueLookupBuilder(ModTags.Items.LONGSWORDS).method_71554(ModItems.STONE_LONGSWORD);
        valueLookupBuilder(ModTags.Items.LONGSWORDS).method_71554(ModItems.IRON_LONGSWORD);
        valueLookupBuilder(ModTags.Items.LONGSWORDS).method_71554(ModItems.GOLDEN_LONGSWORD);
        valueLookupBuilder(ModTags.Items.LONGSWORDS).method_71554(ModItems.DIAMOND_LONGSWORD);
        valueLookupBuilder(ModTags.Items.LONGSWORDS).method_71554(ModItems.NETHERITE_LONGSWORD);
        valueLookupBuilder(ModTags.Items.LONGSWORDS).method_71554(ModItems.FIENDBLADE_LONGSWORD);
        valueLookupBuilder(ModTags.Items.LONGSWORDS).method_71554(ModItems.FLAMEBERGE_LONGSWORD);
        valueLookupBuilder(ModTags.Items.LONGSWORDS).method_71554(ModItems.FIRE_DRAGONSWORD_LONGSWORD);

        valueLookupBuilder(class_3489.field_42614).method_71554(ModItems.LEGENDARY_PICKAXE);
        valueLookupBuilder(class_3489.field_42615).method_71554(ModItems.LEGENDARY_SHOVEL);
        valueLookupBuilder(class_3489.field_42612).method_71554(ModItems.LEGENDARY_AXE);
        valueLookupBuilder(class_3489.field_42613).method_71554(ModItems.LEGENDARY_HOE);
        valueLookupBuilder(class_3489.field_42611).method_71554(ModItems.LEGENDARY_SWORD);
        valueLookupBuilder(class_3489.field_42611).method_71554(ModItems.WOODEN_LONGSWORD);
        valueLookupBuilder(class_3489.field_42611).method_71554(ModItems.STONE_LONGSWORD);
        valueLookupBuilder(class_3489.field_42611).method_71554(ModItems.GOLDEN_LONGSWORD);
        valueLookupBuilder(class_3489.field_42611).method_71554(ModItems.IRON_LONGSWORD);
        valueLookupBuilder(class_3489.field_42611).method_71554(ModItems.DIAMOND_LONGSWORD);
        valueLookupBuilder(class_3489.field_42611).method_71554(ModItems.NETHERITE_LONGSWORD);
        valueLookupBuilder(class_3489.field_42611).method_71554(ModItems.FIENDBLADE_LONGSWORD);
        valueLookupBuilder(class_3489.field_42611).method_71554(ModItems.FIRE_DRAGONSWORD_LONGSWORD);
        valueLookupBuilder(class_3489.field_42611).method_71554(ModItems.FLAMEBERGE_LONGSWORD);
        valueLookupBuilder(class_3489.field_42611).method_71554(ModItems.LEGENDARY_LONGSWORD);
    }
}
