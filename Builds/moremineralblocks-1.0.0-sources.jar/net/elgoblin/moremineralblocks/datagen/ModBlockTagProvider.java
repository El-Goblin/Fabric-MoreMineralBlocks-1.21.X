package net.elgoblin.moremineralblocks.datagen;

import net.elgoblin.moremineralblocks.block.ModBlocks;
import net.elgoblin.moremineralblocks.util.ModTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {
    public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        //valueLookupBuilder(BlockTags.PICKAXE_MINEABLE)
        //        .add(ModBlocks.PINK_GARNET_BLOCK)
        //        .add(ModBlocks.RAW_PINK_GARNET_BLOCK)
        //        .add(ModBlocks.PINK_GARNET_ORE)
        //        .add(ModBlocks.PINK_GARNET_DEEPSLATE_ORE)
        //        .add(ModBlocks.MAGIC_BLOCK);

        valueLookupBuilder(class_3481.field_33718)
                .method_71554(ModBlocks.GOLD_STAIRS)
                .method_71554(ModBlocks.GOLD_SLAB)
                .method_71554(ModBlocks.GOLD_FENCE)
                .method_71554(ModBlocks.GOLD_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_GOLD_BLOCK)
                .method_71554(ModBlocks.GOLD_DOOR)
                .method_71554(ModBlocks.GOLD_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_GOLD_BLOCK)
                .method_71554(ModBlocks.GOLD_BRICKS)
                .method_71554(ModBlocks.GOLD_WALL)

                .method_71554(ModBlocks.GOLD_BRICK_STAIRS)
                .method_71554(ModBlocks.GOLD_BRICK_SLAB)
                .method_71554(ModBlocks.GOLD_BRICK_WALL)
                .method_71554(ModBlocks.GOLD_BRICK_FENCE)
                .method_71554(ModBlocks.GOLD_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_GOLD_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_GOLD_SLAB)
                .method_71554(ModBlocks.CALCIFIED_GOLD_WALL)
                .method_71554(ModBlocks.CALCIFIED_GOLD_FENCE)
                .method_71554(ModBlocks.CALCIFIED_GOLD_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_GOLD_STAIRS)
                .method_71554(ModBlocks.POLISHED_GOLD_SLAB)
                .method_71554(ModBlocks.POLISHED_GOLD_WALL)
                .method_71554(ModBlocks.POLISHED_GOLD_FENCE)
                .method_71554(ModBlocks.POLISHED_GOLD_FENCE_GATE)

                .method_71554(ModBlocks.DIAMOND_STAIRS)
                .method_71554(ModBlocks.DIAMOND_SLAB)
                .method_71554(ModBlocks.DIAMOND_FENCE)
                .method_71554(ModBlocks.DIAMOND_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_DIAMOND_BLOCK)
                .method_71554(ModBlocks.DIAMOND_DOOR)
                .method_71554(ModBlocks.DIAMOND_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_BLOCK)
                .method_71554(ModBlocks.DIAMOND_BRICKS)
                .method_71554(ModBlocks.DIAMOND_WALL)

                .method_71554(ModBlocks.DIAMOND_BRICK_STAIRS)
                .method_71554(ModBlocks.DIAMOND_BRICK_SLAB)
                .method_71554(ModBlocks.DIAMOND_BRICK_WALL)
                .method_71554(ModBlocks.DIAMOND_BRICK_FENCE)
                .method_71554(ModBlocks.DIAMOND_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_SLAB)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_WALL)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_FENCE)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_DIAMOND_STAIRS)
                .method_71554(ModBlocks.POLISHED_DIAMOND_SLAB)
                .method_71554(ModBlocks.POLISHED_DIAMOND_WALL)
                .method_71554(ModBlocks.POLISHED_DIAMOND_FENCE)
                .method_71554(ModBlocks.POLISHED_DIAMOND_FENCE_GATE)

                .method_71554(ModBlocks.EMERALD_STAIRS)
                .method_71554(ModBlocks.EMERALD_SLAB)
                .method_71554(ModBlocks.EMERALD_FENCE)
                .method_71554(ModBlocks.EMERALD_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_EMERALD_BLOCK)
                .method_71554(ModBlocks.EMERALD_DOOR)
                .method_71554(ModBlocks.EMERALD_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_BLOCK)
                .method_71554(ModBlocks.CHISELED_EMERALD_BLOCK)
                .method_71554(ModBlocks.EMERALD_BRICKS)
                .method_71554(ModBlocks.EMERALD_WALL)

                .method_71554(ModBlocks.EMERALD_BRICK_STAIRS)
                .method_71554(ModBlocks.EMERALD_BRICK_SLAB)
                .method_71554(ModBlocks.EMERALD_BRICK_WALL)
                .method_71554(ModBlocks.EMERALD_BRICK_FENCE)
                .method_71554(ModBlocks.EMERALD_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_SLAB)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_WALL)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_FENCE)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_EMERALD_STAIRS)
                .method_71554(ModBlocks.POLISHED_EMERALD_SLAB)
                .method_71554(ModBlocks.POLISHED_EMERALD_WALL)
                .method_71554(ModBlocks.POLISHED_EMERALD_FENCE)
                .method_71554(ModBlocks.POLISHED_EMERALD_FENCE_GATE)
                .method_71554(ModBlocks.CHISELED_EMERALD_STAIRS)
                .method_71554(ModBlocks.CHISELED_EMERALD_SLAB)
                .method_71554(ModBlocks.CHISELED_EMERALD_WALL)
                .method_71554(ModBlocks.CHISELED_EMERALD_FENCE)
                .method_71554(ModBlocks.CHISELED_EMERALD_FENCE_GATE)

                .method_71554(ModBlocks.REDSTONE_STAIRS)
                .method_71554(ModBlocks.REDSTONE_SLAB)
                .method_71554(ModBlocks.REDSTONE_FENCE)
                .method_71554(ModBlocks.REDSTONE_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_REDSTONE_BLOCK)
                .method_71554(ModBlocks.REDSTONE_DOOR)
                .method_71554(ModBlocks.REDSTONE_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_BLOCK)
                .method_71554(ModBlocks.REDSTONE_BRICKS)
                .method_71554(ModBlocks.REDSTONE_WALL)

                .method_71554(ModBlocks.REDSTONE_BRICK_STAIRS)
                .method_71554(ModBlocks.REDSTONE_BRICK_SLAB)
                .method_71554(ModBlocks.REDSTONE_BRICK_WALL)
                .method_71554(ModBlocks.REDSTONE_BRICK_FENCE)
                .method_71554(ModBlocks.REDSTONE_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_SLAB)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_WALL)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_FENCE)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_REDSTONE_STAIRS)
                .method_71554(ModBlocks.POLISHED_REDSTONE_SLAB)
                .method_71554(ModBlocks.POLISHED_REDSTONE_WALL)
                .method_71554(ModBlocks.POLISHED_REDSTONE_FENCE)
                .method_71554(ModBlocks.POLISHED_REDSTONE_FENCE_GATE)
                .method_71554(ModBlocks.PROTECTOR_BLOCK);


        valueLookupBuilder(class_3481.field_33719)
                .method_71554(ModBlocks.IRON_STAIRS)
                .method_71554(ModBlocks.IRON_SLAB)
                .method_71554(ModBlocks.IRON_FENCE)
                .method_71554(ModBlocks.IRON_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_IRON_BLOCK)
                .method_71554(ModBlocks.CALCIFIED_IRON_BLOCK)
                .method_71554(ModBlocks.IRON_BRICKS)
                .method_71554(ModBlocks.IRON_WALL)

                .method_71554(ModBlocks.IRON_BRICK_STAIRS)
                .method_71554(ModBlocks.IRON_BRICK_SLAB)
                .method_71554(ModBlocks.IRON_BRICK_WALL)
                .method_71554(ModBlocks.IRON_BRICK_FENCE)
                .method_71554(ModBlocks.IRON_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_IRON_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_IRON_SLAB)
                .method_71554(ModBlocks.CALCIFIED_IRON_WALL)
                .method_71554(ModBlocks.CALCIFIED_IRON_FENCE)
                .method_71554(ModBlocks.CALCIFIED_IRON_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_IRON_STAIRS)
                .method_71554(ModBlocks.POLISHED_IRON_SLAB)
                .method_71554(ModBlocks.POLISHED_IRON_WALL)
                .method_71554(ModBlocks.POLISHED_IRON_FENCE)
                .method_71554(ModBlocks.POLISHED_IRON_FENCE_GATE)

                .method_71554(ModBlocks.LAPIS_STAIRS)
                .method_71554(ModBlocks.LAPIS_SLAB)
                .method_71554(ModBlocks.LAPIS_FENCE)
                .method_71554(ModBlocks.LAPIS_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_LAPIS_BLOCK)
                .method_71554(ModBlocks.LAPIS_DOOR)
                .method_71554(ModBlocks.LAPIS_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_BLOCK)
                .method_71554(ModBlocks.LAPIS_BRICKS)
                .method_71554(ModBlocks.LAPIS_WALL)

                .method_71554(ModBlocks.LAPIS_BRICK_STAIRS)
                .method_71554(ModBlocks.LAPIS_BRICK_SLAB)
                .method_71554(ModBlocks.LAPIS_BRICK_WALL)
                .method_71554(ModBlocks.LAPIS_BRICK_FENCE)
                .method_71554(ModBlocks.LAPIS_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_SLAB)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_WALL)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_FENCE)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_LAPIS_STAIRS)
                .method_71554(ModBlocks.POLISHED_LAPIS_SLAB)
                .method_71554(ModBlocks.POLISHED_LAPIS_WALL)
                .method_71554(ModBlocks.POLISHED_LAPIS_FENCE)
                .method_71554(ModBlocks.POLISHED_LAPIS_FENCE_GATE);

        valueLookupBuilder(class_3481.field_33717)
                .method_71554(ModBlocks.NETHERITE_STAIRS)
                .method_71554(ModBlocks.NETHERITE_SLAB)
                .method_71554(ModBlocks.NETHERITE_FENCE)
                .method_71554(ModBlocks.NETHERITE_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_NETHERITE_BLOCK)
                .method_71554(ModBlocks.NETHERITE_DOOR)
                .method_71554(ModBlocks.NETHERITE_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_BLOCK)
                .method_71554(ModBlocks.NETHERITE_BRICKS)
                .method_71554(ModBlocks.NETHERITE_WALL)

                .method_71554(ModBlocks.NETHERITE_BRICK_STAIRS)
                .method_71554(ModBlocks.NETHERITE_BRICK_SLAB)
                .method_71554(ModBlocks.NETHERITE_BRICK_WALL)
                .method_71554(ModBlocks.NETHERITE_BRICK_FENCE)
                .method_71554(ModBlocks.NETHERITE_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_SLAB)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_WALL)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_FENCE)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_NETHERITE_STAIRS)
                .method_71554(ModBlocks.POLISHED_NETHERITE_SLAB)
                .method_71554(ModBlocks.POLISHED_NETHERITE_WALL)
                .method_71554(ModBlocks.POLISHED_NETHERITE_FENCE)
                .method_71554(ModBlocks.POLISHED_NETHERITE_FENCE_GATE)

                .method_71554(ModBlocks.OBSIDIAN_STAIRS)
                .method_71554(ModBlocks.OBSIDIAN_SLAB)
                .method_71554(ModBlocks.OBSIDIAN_FENCE)
                .method_71554(ModBlocks.OBSIDIAN_FENCE_GATE)
                .method_71554(ModBlocks.OBSIDIAN_WALL);

        //valueLookupBuilder(BlockTags.FENCES).add(ModBlocks.PINK_GARNET_FENCE);
        //valueLookupBuilder(BlockTags.FENCE_GATES).add(ModBlocks.PINK_GARNET_FENCE_GATE);
        //valueLookupBuilder(BlockTags.WALLS).add(ModBlocks.PINK_GARNET_WALL);

        // GOLD

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.GOLD_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.GOLD_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.GOLD_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.CALCIFIED_GOLD_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.CALCIFIED_GOLD_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.CALCIFIED_GOLD_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.GOLD_BRICK_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.GOLD_BRICK_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.GOLD_BRICK_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.POLISHED_GOLD_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.POLISHED_GOLD_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.POLISHED_GOLD_WALL);

        // DIAMOND

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.DIAMOND_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.DIAMOND_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.DIAMOND_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.CALCIFIED_DIAMOND_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.CALCIFIED_DIAMOND_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.CALCIFIED_DIAMOND_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.DIAMOND_BRICK_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.DIAMOND_BRICK_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.DIAMOND_BRICK_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.POLISHED_DIAMOND_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.POLISHED_DIAMOND_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.POLISHED_DIAMOND_WALL);

        // EMERALD

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.EMERALD_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.EMERALD_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.EMERALD_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.CALCIFIED_EMERALD_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.CALCIFIED_EMERALD_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.CALCIFIED_EMERALD_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.EMERALD_BRICK_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.EMERALD_BRICK_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.EMERALD_BRICK_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.POLISHED_EMERALD_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.POLISHED_EMERALD_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.POLISHED_EMERALD_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.CHISELED_EMERALD_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.CHISELED_EMERALD_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.CHISELED_EMERALD_WALL);

        // IRON

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.IRON_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.IRON_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.IRON_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.CALCIFIED_IRON_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.CALCIFIED_IRON_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.CALCIFIED_IRON_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.IRON_BRICK_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.IRON_BRICK_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.IRON_BRICK_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.POLISHED_IRON_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.POLISHED_IRON_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.POLISHED_IRON_WALL);

        // LAPIS

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.LAPIS_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.LAPIS_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.LAPIS_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.CALCIFIED_LAPIS_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.CALCIFIED_LAPIS_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.CALCIFIED_LAPIS_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.LAPIS_BRICK_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.LAPIS_BRICK_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.LAPIS_BRICK_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.POLISHED_LAPIS_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.POLISHED_LAPIS_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.POLISHED_LAPIS_WALL);

        // NETHERITE

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.NETHERITE_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.NETHERITE_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.NETHERITE_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.CALCIFIED_NETHERITE_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.CALCIFIED_NETHERITE_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.CALCIFIED_NETHERITE_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.NETHERITE_BRICK_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.NETHERITE_BRICK_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.NETHERITE_BRICK_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.POLISHED_NETHERITE_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.POLISHED_NETHERITE_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.POLISHED_NETHERITE_WALL);

        // AMETHYST

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.AMETHYST_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.AMETHYST_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.AMETHYST_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.CALCIFIED_AMETHYST_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.CALCIFIED_AMETHYST_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.CALCIFIED_AMETHYST_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.AMETHYST_BRICK_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.AMETHYST_BRICK_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.AMETHYST_BRICK_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.POLISHED_AMETHYST_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.POLISHED_AMETHYST_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.POLISHED_AMETHYST_WALL);

        // CALCITE

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.CALCITE_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.CALCITE_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.CALCITE_WALL);

        // COAL

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.COAL_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.COAL_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.COAL_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.CALCIFIED_COAL_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.CALCIFIED_COAL_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.CALCIFIED_COAL_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.COAL_BRICK_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.COAL_BRICK_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.COAL_BRICK_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.POLISHED_COAL_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.POLISHED_COAL_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.POLISHED_COAL_WALL);

        // REDSTONE

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.REDSTONE_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.REDSTONE_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.REDSTONE_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.CALCIFIED_REDSTONE_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.CALCIFIED_REDSTONE_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.CALCIFIED_REDSTONE_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.REDSTONE_BRICK_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.REDSTONE_BRICK_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.REDSTONE_BRICK_WALL);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.POLISHED_REDSTONE_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.POLISHED_REDSTONE_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.POLISHED_REDSTONE_WALL);

        // OBSIDIAN

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.OBSIDIAN_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.OBSIDIAN_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.OBSIDIAN_WALL);

        // BEDROCK

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.BEDROCK_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.BEDROCK_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.BEDROCK_WALL);

        // SCULK

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.SCULK_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.SCULK_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.SCULK_WALL);

        // PACKED_ICE

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.PACKED_ICE_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.PACKED_ICE_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.PACKED_ICE_WALL);

        // BLUE ICE

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.BLUE_ICE_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.BLUE_ICE_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.BLUE_ICE_WALL);

        // ICE

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.ICE_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.ICE_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.ICE_WALL);

//        valueLookupBuilder(BlockTags.FENCES).add(ModBlocks.DEEPSLATE_EMERALD_ORE_FENCE);
//        valueLookupBuilder(BlockTags.FENCE_GATES).add(ModBlocks.DEEPSLATE_EMERALD_ORE_FENCE_GATE);
//        valueLookupBuilder(BlockTags.WALLS).add(ModBlocks.DEEPSLATE_EMERALD_ORE_WALL);

        // PRISMARINE

        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.DARK_PRISMARINE_WALL);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.PRISMARINE_BRICK_WALL);

        valueLookupBuilder(class_3481.field_33715)
                .method_71554(ModBlocks.GOLD_STAIRS)
                .method_71554(ModBlocks.GOLD_SLAB)
                .method_71554(ModBlocks.GOLD_FENCE)
                .method_71554(ModBlocks.GOLD_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_GOLD_BLOCK)
                .method_71554(ModBlocks.GOLD_DOOR)
                .method_71554(ModBlocks.GOLD_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_GOLD_BLOCK)
                .method_71554(ModBlocks.GOLD_BRICKS)

                .method_71554(ModBlocks.GOLD_BRICK_STAIRS)
                .method_71554(ModBlocks.GOLD_BRICK_SLAB)
                .method_71554(ModBlocks.GOLD_BRICK_WALL)
                .method_71554(ModBlocks.GOLD_BRICK_FENCE)
                .method_71554(ModBlocks.GOLD_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_GOLD_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_GOLD_SLAB)
                .method_71554(ModBlocks.CALCIFIED_GOLD_WALL)
                .method_71554(ModBlocks.CALCIFIED_GOLD_FENCE)
                .method_71554(ModBlocks.CALCIFIED_GOLD_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_GOLD_STAIRS)
                .method_71554(ModBlocks.POLISHED_GOLD_SLAB)
                .method_71554(ModBlocks.POLISHED_GOLD_WALL)
                .method_71554(ModBlocks.POLISHED_GOLD_FENCE)
                .method_71554(ModBlocks.POLISHED_GOLD_FENCE_GATE)

                .method_71554(ModBlocks.DIAMOND_STAIRS)
                .method_71554(ModBlocks.DIAMOND_SLAB)
                .method_71554(ModBlocks.DIAMOND_FENCE)
                .method_71554(ModBlocks.DIAMOND_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_DIAMOND_BLOCK)
                .method_71554(ModBlocks.DIAMOND_DOOR)
                .method_71554(ModBlocks.DIAMOND_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_BLOCK)
                .method_71554(ModBlocks.DIAMOND_BRICKS)

                .method_71554(ModBlocks.DIAMOND_BRICK_STAIRS)
                .method_71554(ModBlocks.DIAMOND_BRICK_SLAB)
                .method_71554(ModBlocks.DIAMOND_BRICK_WALL)
                .method_71554(ModBlocks.DIAMOND_BRICK_FENCE)
                .method_71554(ModBlocks.DIAMOND_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_SLAB)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_WALL)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_FENCE)
                .method_71554(ModBlocks.CALCIFIED_DIAMOND_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_DIAMOND_STAIRS)
                .method_71554(ModBlocks.POLISHED_DIAMOND_SLAB)
                .method_71554(ModBlocks.POLISHED_DIAMOND_WALL)
                .method_71554(ModBlocks.POLISHED_DIAMOND_FENCE)
                .method_71554(ModBlocks.POLISHED_DIAMOND_FENCE_GATE)

                .method_71554(ModBlocks.IRON_STAIRS)
                .method_71554(ModBlocks.IRON_SLAB)
                .method_71554(ModBlocks.IRON_FENCE)
                .method_71554(ModBlocks.IRON_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_IRON_BLOCK)
                .method_71554(ModBlocks.CALCIFIED_IRON_BLOCK)
                .method_71554(ModBlocks.IRON_BRICKS)

                .method_71554(ModBlocks.IRON_BRICK_STAIRS)
                .method_71554(ModBlocks.IRON_BRICK_SLAB)
                .method_71554(ModBlocks.IRON_BRICK_WALL)
                .method_71554(ModBlocks.IRON_BRICK_FENCE)
                .method_71554(ModBlocks.IRON_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_IRON_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_IRON_SLAB)
                .method_71554(ModBlocks.CALCIFIED_IRON_WALL)
                .method_71554(ModBlocks.CALCIFIED_IRON_FENCE)
                .method_71554(ModBlocks.CALCIFIED_IRON_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_IRON_STAIRS)
                .method_71554(ModBlocks.POLISHED_IRON_SLAB)
                .method_71554(ModBlocks.POLISHED_IRON_WALL)
                .method_71554(ModBlocks.POLISHED_IRON_FENCE)
                .method_71554(ModBlocks.POLISHED_IRON_FENCE_GATE)

                .method_71554(ModBlocks.EMERALD_STAIRS)
                .method_71554(ModBlocks.EMERALD_SLAB)
                .method_71554(ModBlocks.EMERALD_FENCE)
                .method_71554(ModBlocks.EMERALD_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_EMERALD_BLOCK)
                .method_71554(ModBlocks.EMERALD_DOOR)
                .method_71554(ModBlocks.EMERALD_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_BLOCK)
                .method_71554(ModBlocks.CHISELED_EMERALD_BLOCK)
                .method_71554(ModBlocks.EMERALD_BRICKS)

                .method_71554(ModBlocks.EMERALD_BRICK_STAIRS)
                .method_71554(ModBlocks.EMERALD_BRICK_SLAB)
                .method_71554(ModBlocks.EMERALD_BRICK_WALL)
                .method_71554(ModBlocks.EMERALD_BRICK_FENCE)
                .method_71554(ModBlocks.EMERALD_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_SLAB)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_WALL)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_FENCE)
                .method_71554(ModBlocks.CALCIFIED_EMERALD_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_EMERALD_STAIRS)
                .method_71554(ModBlocks.POLISHED_EMERALD_SLAB)
                .method_71554(ModBlocks.POLISHED_EMERALD_WALL)
                .method_71554(ModBlocks.POLISHED_EMERALD_FENCE)
                .method_71554(ModBlocks.POLISHED_EMERALD_FENCE_GATE)
                .method_71554(ModBlocks.CHISELED_EMERALD_STAIRS)
                .method_71554(ModBlocks.CHISELED_EMERALD_SLAB)
                .method_71554(ModBlocks.CHISELED_EMERALD_WALL)
                .method_71554(ModBlocks.CHISELED_EMERALD_FENCE)
                .method_71554(ModBlocks.CHISELED_EMERALD_FENCE_GATE)

                .method_71554(ModBlocks.AMETHYST_STAIRS)
                .method_71554(ModBlocks.AMETHYST_SLAB)
                .method_71554(ModBlocks.AMETHYST_FENCE)
                .method_71554(ModBlocks.AMETHYST_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_AMETHYST_BLOCK)
                .method_71554(ModBlocks.AMETHYST_DOOR)
                .method_71554(ModBlocks.AMETHYST_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_AMETHYST_BLOCK)
                .method_71554(ModBlocks.AMETHYST_BRICKS)
                .method_71554(ModBlocks.AMETHYST_BRICK_STAIRS)
                .method_71554(ModBlocks.AMETHYST_BRICK_SLAB)
                .method_71554(ModBlocks.AMETHYST_BRICK_WALL)
                .method_71554(ModBlocks.AMETHYST_BRICK_FENCE)
                .method_71554(ModBlocks.AMETHYST_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_AMETHYST_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_AMETHYST_SLAB)
                .method_71554(ModBlocks.CALCIFIED_AMETHYST_WALL)
                .method_71554(ModBlocks.CALCIFIED_AMETHYST_FENCE)
                .method_71554(ModBlocks.CALCIFIED_AMETHYST_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_AMETHYST_STAIRS)
                .method_71554(ModBlocks.POLISHED_AMETHYST_SLAB)
                .method_71554(ModBlocks.POLISHED_AMETHYST_WALL)
                .method_71554(ModBlocks.POLISHED_AMETHYST_FENCE)
                .method_71554(ModBlocks.POLISHED_AMETHYST_FENCE_GATE)

                .method_71554(ModBlocks.CALCITE_STAIRS)
                .method_71554(ModBlocks.CALCITE_SLAB)
                .method_71554(ModBlocks.CALCITE_FENCE)
                .method_71554(ModBlocks.CALCITE_FENCE_GATE)

                .method_71554(ModBlocks.COAL_STAIRS)
                .method_71554(ModBlocks.COAL_SLAB)
                .method_71554(ModBlocks.COAL_FENCE)
                .method_71554(ModBlocks.COAL_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_COAL_BLOCK)
                .method_71554(ModBlocks.COAL_DOOR)
                .method_71554(ModBlocks.COAL_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_COAL_BLOCK)
                .method_71554(ModBlocks.COAL_BRICKS)
                .method_71554(ModBlocks.COAL_BRICK_STAIRS)
                .method_71554(ModBlocks.COAL_BRICK_SLAB)
                .method_71554(ModBlocks.COAL_BRICK_WALL)
                .method_71554(ModBlocks.COAL_BRICK_FENCE)
                .method_71554(ModBlocks.COAL_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_COAL_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_COAL_SLAB)
                .method_71554(ModBlocks.CALCIFIED_COAL_WALL)
                .method_71554(ModBlocks.CALCIFIED_COAL_FENCE)
                .method_71554(ModBlocks.CALCIFIED_COAL_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_COAL_STAIRS)
                .method_71554(ModBlocks.POLISHED_COAL_SLAB)
                .method_71554(ModBlocks.POLISHED_COAL_WALL)
                .method_71554(ModBlocks.POLISHED_COAL_FENCE)
                .method_71554(ModBlocks.POLISHED_COAL_FENCE_GATE)

                .method_71554(ModBlocks.LAPIS_STAIRS)
                .method_71554(ModBlocks.LAPIS_SLAB)
                .method_71554(ModBlocks.LAPIS_FENCE)
                .method_71554(ModBlocks.LAPIS_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_LAPIS_BLOCK)
                .method_71554(ModBlocks.LAPIS_DOOR)
                .method_71554(ModBlocks.LAPIS_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_BLOCK)
                .method_71554(ModBlocks.LAPIS_BRICKS)
                .method_71554(ModBlocks.LAPIS_BRICK_STAIRS)
                .method_71554(ModBlocks.LAPIS_BRICK_SLAB)
                .method_71554(ModBlocks.LAPIS_BRICK_WALL)
                .method_71554(ModBlocks.LAPIS_BRICK_FENCE)
                .method_71554(ModBlocks.LAPIS_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_SLAB)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_WALL)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_FENCE)
                .method_71554(ModBlocks.CALCIFIED_LAPIS_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_LAPIS_STAIRS)
                .method_71554(ModBlocks.POLISHED_LAPIS_SLAB)
                .method_71554(ModBlocks.POLISHED_LAPIS_WALL)
                .method_71554(ModBlocks.POLISHED_LAPIS_FENCE)
                .method_71554(ModBlocks.POLISHED_LAPIS_FENCE_GATE)

                .method_71554(ModBlocks.REDSTONE_STAIRS)
                .method_71554(ModBlocks.REDSTONE_SLAB)
                .method_71554(ModBlocks.REDSTONE_FENCE)
                .method_71554(ModBlocks.REDSTONE_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_REDSTONE_BLOCK)
                .method_71554(ModBlocks.REDSTONE_DOOR)
                .method_71554(ModBlocks.REDSTONE_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_BLOCK)
                .method_71554(ModBlocks.REDSTONE_BRICKS)
                .method_71554(ModBlocks.REDSTONE_BRICK_STAIRS)
                .method_71554(ModBlocks.REDSTONE_BRICK_SLAB)
                .method_71554(ModBlocks.REDSTONE_BRICK_WALL)
                .method_71554(ModBlocks.REDSTONE_BRICK_FENCE)
                .method_71554(ModBlocks.REDSTONE_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_SLAB)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_WALL)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_FENCE)
                .method_71554(ModBlocks.CALCIFIED_REDSTONE_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_REDSTONE_STAIRS)
                .method_71554(ModBlocks.POLISHED_REDSTONE_SLAB)
                .method_71554(ModBlocks.POLISHED_REDSTONE_WALL)
                .method_71554(ModBlocks.POLISHED_REDSTONE_FENCE)
                .method_71554(ModBlocks.POLISHED_REDSTONE_FENCE_GATE)

                .method_71554(ModBlocks.NETHERITE_STAIRS)
                .method_71554(ModBlocks.NETHERITE_SLAB)
                .method_71554(ModBlocks.NETHERITE_FENCE)
                .method_71554(ModBlocks.NETHERITE_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_NETHERITE_BLOCK)
                .method_71554(ModBlocks.NETHERITE_DOOR)
                .method_71554(ModBlocks.NETHERITE_TRAPDOOR)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_BLOCK)
                .method_71554(ModBlocks.NETHERITE_BRICKS)
                .method_71554(ModBlocks.NETHERITE_BRICK_STAIRS)
                .method_71554(ModBlocks.NETHERITE_BRICK_SLAB)
                .method_71554(ModBlocks.NETHERITE_BRICK_WALL)
                .method_71554(ModBlocks.NETHERITE_BRICK_FENCE)
                .method_71554(ModBlocks.NETHERITE_BRICK_FENCE_GATE)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_STAIRS)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_SLAB)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_WALL)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_FENCE)
                .method_71554(ModBlocks.CALCIFIED_NETHERITE_FENCE_GATE)
                .method_71554(ModBlocks.POLISHED_NETHERITE_STAIRS)
                .method_71554(ModBlocks.POLISHED_NETHERITE_SLAB)
                .method_71554(ModBlocks.POLISHED_NETHERITE_WALL)
                .method_71554(ModBlocks.POLISHED_NETHERITE_FENCE)
                .method_71554(ModBlocks.POLISHED_NETHERITE_FENCE_GATE)

                .method_71554(ModBlocks.OBSIDIAN_STAIRS)
                .method_71554(ModBlocks.OBSIDIAN_SLAB)
                .method_71554(ModBlocks.OBSIDIAN_FENCE)
                .method_71554(ModBlocks.OBSIDIAN_FENCE_GATE)

                .method_71554(ModBlocks.PACKED_ICE_STAIRS)
                .method_71554(ModBlocks.PACKED_ICE_SLAB)
                .method_71554(ModBlocks.PACKED_ICE_FENCE)
                .method_71554(ModBlocks.PACKED_ICE_FENCE_GATE)

                .method_71554(ModBlocks.BLUE_ICE_STAIRS)
                .method_71554(ModBlocks.BLUE_ICE_SLAB)
                .method_71554(ModBlocks.BLUE_ICE_FENCE)
                .method_71554(ModBlocks.BLUE_ICE_FENCE_GATE)

                .method_71554(ModBlocks.ICE_STAIRS)
                .method_71554(ModBlocks.ICE_SLAB)
                .method_71554(ModBlocks.ICE_FENCE)
                .method_71554(ModBlocks.ICE_FENCE_GATE)

                .method_71554(ModBlocks.PROTECTOR_BLOCK);



        valueLookupBuilder(ModTags.Blocks.NEEDS_LEGENDARY_TOOL);
    }
}
