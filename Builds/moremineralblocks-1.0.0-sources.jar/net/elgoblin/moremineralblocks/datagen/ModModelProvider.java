package net.elgoblin.moremineralblocks.datagen;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.block.ModBlocks;
import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_2246;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;
import net.minecraft.client.data.*;
import java.util.List;
import java.util.Optional;

public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        //BlockStateModelGenerator.BlockTexturePool pinkGarnetPool = blockStateModelGenerator.registerCubeAllModelTexturePool(ModBlocks.PINK_GARNET_BLOCK);
        //pinkGarnetPool.stairs(ModBlocks.PINK_GARNET_STAIRS);
        //pinkGarnetPool.slab(ModBlocks.PINK_GARNET_SLAB);
        //pinkGarnetPool.button(ModBlocks.PINK_GARNET_BUTTON);
        //pinkGarnetPool.pressurePlate(ModBlocks.PINK_GARNET_PRESSURE_PLATE);
        //pinkGarnetPool.fence(ModBlocks.PINK_GARNET_FENCE);
        //pinkGarnetPool.fenceGate(ModBlocks.PINK_GARNET_FENCE_GATE);
        //pinkGarnetPool.wall(ModBlocks.PINK_GARNET_WALL);


        //blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.RAW_PINK_GARNET_BLOCK);
        //blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.PINK_GARNET_DEEPSLATE_ORE);
        //blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.PINK_GARNET_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.PROTECTOR_BLOCK);

        class_4910.class_4912 goldPool = blockStateModelGenerator.method_25650(class_2246.field_10205);
        goldPool.method_25725(ModBlocks.GOLD_STAIRS);
        goldPool.method_25724(ModBlocks.GOLD_SLAB);
        goldPool.method_25721(ModBlocks.GOLD_FENCE);
        goldPool.method_25722(ModBlocks.GOLD_FENCE_GATE);
        goldPool.method_25720(ModBlocks.GOLD_WALL);
        blockStateModelGenerator.method_25658(ModBlocks.GOLD_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.GOLD_TRAPDOOR);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.POLISHED_GOLD_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.CALCIFIED_GOLD_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.GOLD_BRICKS);

        class_4910.class_4912 goldBrickPool = blockStateModelGenerator.method_25650(ModBlocks.GOLD_BRICKS);
        goldBrickPool.method_25725(ModBlocks.GOLD_BRICK_STAIRS);
        goldBrickPool.method_25724(ModBlocks.GOLD_BRICK_SLAB);
        goldBrickPool.method_25721(ModBlocks.GOLD_BRICK_FENCE);
        goldBrickPool.method_25722(ModBlocks.GOLD_BRICK_FENCE_GATE);
        goldBrickPool.method_25720(ModBlocks.GOLD_BRICK_WALL);

        class_4910.class_4912 calcifiedGoldPool = blockStateModelGenerator.method_25650(ModBlocks.CALCIFIED_GOLD_BLOCK);
        calcifiedGoldPool.method_25725(ModBlocks.CALCIFIED_GOLD_STAIRS);
        calcifiedGoldPool.method_25724(ModBlocks.CALCIFIED_GOLD_SLAB);
        calcifiedGoldPool.method_25721(ModBlocks.CALCIFIED_GOLD_FENCE);
        calcifiedGoldPool.method_25722(ModBlocks.CALCIFIED_GOLD_FENCE_GATE);
        calcifiedGoldPool.method_25720(ModBlocks.CALCIFIED_GOLD_WALL);

        class_4910.class_4912 polishedGoldPool = blockStateModelGenerator.method_25650(ModBlocks.POLISHED_GOLD_BLOCK);
        polishedGoldPool.method_25725(ModBlocks.POLISHED_GOLD_STAIRS);
        polishedGoldPool.method_25724(ModBlocks.POLISHED_GOLD_SLAB);
        polishedGoldPool.method_25721(ModBlocks.POLISHED_GOLD_FENCE);
        polishedGoldPool.method_25722(ModBlocks.POLISHED_GOLD_FENCE_GATE);
        polishedGoldPool.method_25720(ModBlocks.POLISHED_GOLD_WALL);

        class_4910.class_4912 diamondPool = blockStateModelGenerator.method_25650(class_2246.field_10201);
        diamondPool.method_25725(ModBlocks.DIAMOND_STAIRS);
        diamondPool.method_25724(ModBlocks.DIAMOND_SLAB);
        diamondPool.method_25721(ModBlocks.DIAMOND_FENCE);
        diamondPool.method_25722(ModBlocks.DIAMOND_FENCE_GATE);
        diamondPool.method_25720(ModBlocks.DIAMOND_WALL);
        blockStateModelGenerator.method_25658(ModBlocks.DIAMOND_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.DIAMOND_TRAPDOOR);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.POLISHED_DIAMOND_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.CALCIFIED_DIAMOND_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.DIAMOND_BRICKS);

        class_4910.class_4912 diamondBrickPool = blockStateModelGenerator.method_25650(ModBlocks.DIAMOND_BRICKS);
        diamondBrickPool.method_25725(ModBlocks.DIAMOND_BRICK_STAIRS);
        diamondBrickPool.method_25724(ModBlocks.DIAMOND_BRICK_SLAB);
        diamondBrickPool.method_25721(ModBlocks.DIAMOND_BRICK_FENCE);
        diamondBrickPool.method_25722(ModBlocks.DIAMOND_BRICK_FENCE_GATE);
        diamondBrickPool.method_25720(ModBlocks.DIAMOND_BRICK_WALL);

        class_4910.class_4912 calcifiedDiamondPool = blockStateModelGenerator.method_25650(ModBlocks.CALCIFIED_DIAMOND_BLOCK);
        calcifiedDiamondPool.method_25725(ModBlocks.CALCIFIED_DIAMOND_STAIRS);
        calcifiedDiamondPool.method_25724(ModBlocks.CALCIFIED_DIAMOND_SLAB);
        calcifiedDiamondPool.method_25721(ModBlocks.CALCIFIED_DIAMOND_FENCE);
        calcifiedDiamondPool.method_25722(ModBlocks.CALCIFIED_DIAMOND_FENCE_GATE);
        calcifiedDiamondPool.method_25720(ModBlocks.CALCIFIED_DIAMOND_WALL);

        class_4910.class_4912 polishedDiamondPool = blockStateModelGenerator.method_25650(ModBlocks.POLISHED_DIAMOND_BLOCK);
        polishedDiamondPool.method_25725(ModBlocks.POLISHED_DIAMOND_STAIRS);
        polishedDiamondPool.method_25724(ModBlocks.POLISHED_DIAMOND_SLAB);
        polishedDiamondPool.method_25721(ModBlocks.POLISHED_DIAMOND_FENCE);
        polishedDiamondPool.method_25722(ModBlocks.POLISHED_DIAMOND_FENCE_GATE);
        polishedDiamondPool.method_25720(ModBlocks.POLISHED_DIAMOND_WALL);

        class_4910.class_4912 ironPool = blockStateModelGenerator.method_25650(class_2246.field_10085);
        ironPool.method_25725(ModBlocks.IRON_STAIRS);
        ironPool.method_25724(ModBlocks.IRON_SLAB);
        ironPool.method_25721(ModBlocks.IRON_FENCE);
        ironPool.method_25722(ModBlocks.IRON_FENCE_GATE);
        ironPool.method_25720(ModBlocks.IRON_WALL);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.POLISHED_IRON_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.CALCIFIED_IRON_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.IRON_BRICKS);

        class_4910.class_4912 ironBrickPool = blockStateModelGenerator.method_25650(ModBlocks.IRON_BRICKS);
        ironBrickPool.method_25725(ModBlocks.IRON_BRICK_STAIRS);
        ironBrickPool.method_25724(ModBlocks.IRON_BRICK_SLAB);
        ironBrickPool.method_25721(ModBlocks.IRON_BRICK_FENCE);
        ironBrickPool.method_25722(ModBlocks.IRON_BRICK_FENCE_GATE);
        ironBrickPool.method_25720(ModBlocks.IRON_BRICK_WALL);

        class_4910.class_4912 calcifiedIronPool = blockStateModelGenerator.method_25650(ModBlocks.CALCIFIED_IRON_BLOCK);
        calcifiedIronPool.method_25725(ModBlocks.CALCIFIED_IRON_STAIRS);
        calcifiedIronPool.method_25724(ModBlocks.CALCIFIED_IRON_SLAB);
        calcifiedIronPool.method_25721(ModBlocks.CALCIFIED_IRON_FENCE);
        calcifiedIronPool.method_25722(ModBlocks.CALCIFIED_IRON_FENCE_GATE);
        calcifiedIronPool.method_25720(ModBlocks.CALCIFIED_IRON_WALL);

        class_4910.class_4912 polishedIronPool = blockStateModelGenerator.method_25650(ModBlocks.POLISHED_IRON_BLOCK);
        polishedIronPool.method_25725(ModBlocks.POLISHED_IRON_STAIRS);
        polishedIronPool.method_25724(ModBlocks.POLISHED_IRON_SLAB);
        polishedIronPool.method_25721(ModBlocks.POLISHED_IRON_FENCE);
        polishedIronPool.method_25722(ModBlocks.POLISHED_IRON_FENCE_GATE);
        polishedIronPool.method_25720(ModBlocks.POLISHED_IRON_WALL);

        class_4910.class_4912 emeraldPool = blockStateModelGenerator.method_25650(class_2246.field_10234);
        emeraldPool.method_25725(ModBlocks.EMERALD_STAIRS);
        emeraldPool.method_25724(ModBlocks.EMERALD_SLAB);
        emeraldPool.method_25721(ModBlocks.EMERALD_FENCE);
        emeraldPool.method_25722(ModBlocks.EMERALD_FENCE_GATE);
        emeraldPool.method_25720(ModBlocks.EMERALD_WALL);
        blockStateModelGenerator.method_25658(ModBlocks.EMERALD_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.EMERALD_TRAPDOOR);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.POLISHED_EMERALD_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.CHISELED_EMERALD_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.CALCIFIED_EMERALD_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.EMERALD_BRICKS);

        class_4910.class_4912 emeraldBrickPool = blockStateModelGenerator.method_25650(ModBlocks.EMERALD_BRICKS);
        emeraldBrickPool.method_25725(ModBlocks.EMERALD_BRICK_STAIRS);
        emeraldBrickPool.method_25724(ModBlocks.EMERALD_BRICK_SLAB);
        emeraldBrickPool.method_25721(ModBlocks.EMERALD_BRICK_FENCE);
        emeraldBrickPool.method_25722(ModBlocks.EMERALD_BRICK_FENCE_GATE);
        emeraldBrickPool.method_25720(ModBlocks.EMERALD_BRICK_WALL);

        class_4910.class_4912 calcifiedEmeraldPool = blockStateModelGenerator.method_25650(ModBlocks.CALCIFIED_EMERALD_BLOCK);
        calcifiedEmeraldPool.method_25725(ModBlocks.CALCIFIED_EMERALD_STAIRS);
        calcifiedEmeraldPool.method_25724(ModBlocks.CALCIFIED_EMERALD_SLAB);
        calcifiedEmeraldPool.method_25721(ModBlocks.CALCIFIED_EMERALD_FENCE);
        calcifiedEmeraldPool.method_25722(ModBlocks.CALCIFIED_EMERALD_FENCE_GATE);
        calcifiedEmeraldPool.method_25720(ModBlocks.CALCIFIED_EMERALD_WALL);

        class_4910.class_4912 polishedEmeraldPool = blockStateModelGenerator.method_25650(ModBlocks.POLISHED_EMERALD_BLOCK);
        polishedEmeraldPool.method_25725(ModBlocks.POLISHED_EMERALD_STAIRS);
        polishedEmeraldPool.method_25724(ModBlocks.POLISHED_EMERALD_SLAB);
        polishedEmeraldPool.method_25721(ModBlocks.POLISHED_EMERALD_FENCE);
        polishedEmeraldPool.method_25722(ModBlocks.POLISHED_EMERALD_FENCE_GATE);
        polishedEmeraldPool.method_25720(ModBlocks.POLISHED_EMERALD_WALL);

        class_4910.class_4912 chiseledGoldPool = blockStateModelGenerator.method_25650(ModBlocks.CHISELED_EMERALD_BLOCK);
        chiseledGoldPool.method_25725(ModBlocks.CHISELED_EMERALD_STAIRS);
        chiseledGoldPool.method_25724(ModBlocks.CHISELED_EMERALD_SLAB);
        chiseledGoldPool.method_25721(ModBlocks.CHISELED_EMERALD_FENCE);
        chiseledGoldPool.method_25722(ModBlocks.CHISELED_EMERALD_FENCE_GATE);
        chiseledGoldPool.method_25720(ModBlocks.CHISELED_EMERALD_WALL);

        class_4910.class_4912 amethystPool = blockStateModelGenerator.method_25650(class_2246.field_27159);
        amethystPool.method_25725(ModBlocks.AMETHYST_STAIRS);
        amethystPool.method_25724(ModBlocks.AMETHYST_SLAB);
        amethystPool.method_25721(ModBlocks.AMETHYST_FENCE);
        amethystPool.method_25722(ModBlocks.AMETHYST_FENCE_GATE);
        amethystPool.method_25720(ModBlocks.AMETHYST_WALL);
        blockStateModelGenerator.method_25658(ModBlocks.AMETHYST_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.AMETHYST_TRAPDOOR);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.POLISHED_AMETHYST_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.CALCIFIED_AMETHYST_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.AMETHYST_BRICKS);

        class_4910.class_4912 amethystBrickPool = blockStateModelGenerator.method_25650(ModBlocks.AMETHYST_BRICKS);
        amethystBrickPool.method_25725(ModBlocks.AMETHYST_BRICK_STAIRS);
        amethystBrickPool.method_25724(ModBlocks.AMETHYST_BRICK_SLAB);
        amethystBrickPool.method_25721(ModBlocks.AMETHYST_BRICK_FENCE);
        amethystBrickPool.method_25722(ModBlocks.AMETHYST_BRICK_FENCE_GATE);
        amethystBrickPool.method_25720(ModBlocks.AMETHYST_BRICK_WALL);

        class_4910.class_4912 calcifiedAmethystPool = blockStateModelGenerator.method_25650(ModBlocks.CALCIFIED_AMETHYST_BLOCK);
        calcifiedAmethystPool.method_25725(ModBlocks.CALCIFIED_AMETHYST_STAIRS);
        calcifiedAmethystPool.method_25724(ModBlocks.CALCIFIED_AMETHYST_SLAB);
        calcifiedAmethystPool.method_25721(ModBlocks.CALCIFIED_AMETHYST_FENCE);
        calcifiedAmethystPool.method_25722(ModBlocks.CALCIFIED_AMETHYST_FENCE_GATE);
        calcifiedAmethystPool.method_25720(ModBlocks.CALCIFIED_AMETHYST_WALL);

        class_4910.class_4912 polishedAmethystPool = blockStateModelGenerator.method_25650(ModBlocks.POLISHED_AMETHYST_BLOCK);
        polishedAmethystPool.method_25725(ModBlocks.POLISHED_AMETHYST_STAIRS);
        polishedAmethystPool.method_25724(ModBlocks.POLISHED_AMETHYST_SLAB);
        polishedAmethystPool.method_25721(ModBlocks.POLISHED_AMETHYST_FENCE);
        polishedAmethystPool.method_25722(ModBlocks.POLISHED_AMETHYST_FENCE_GATE);
        polishedAmethystPool.method_25720(ModBlocks.POLISHED_AMETHYST_WALL);

        class_4910.class_4912 coalPool = blockStateModelGenerator.method_25650(class_2246.field_10381);
        coalPool.method_25725(ModBlocks.COAL_STAIRS);
        coalPool.method_25724(ModBlocks.COAL_SLAB);
        coalPool.method_25721(ModBlocks.COAL_FENCE);
        coalPool.method_25722(ModBlocks.COAL_FENCE_GATE);
        coalPool.method_25720(ModBlocks.COAL_WALL);
        blockStateModelGenerator.method_25658(ModBlocks.COAL_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.COAL_TRAPDOOR);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.POLISHED_COAL_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.CALCIFIED_COAL_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.COAL_BRICKS);

        class_4910.class_4912 coalBrickPool = blockStateModelGenerator.method_25650(ModBlocks.COAL_BRICKS);
        coalBrickPool.method_25725(ModBlocks.COAL_BRICK_STAIRS);
        coalBrickPool.method_25724(ModBlocks.COAL_BRICK_SLAB);
        coalBrickPool.method_25721(ModBlocks.COAL_BRICK_FENCE);
        coalBrickPool.method_25722(ModBlocks.COAL_BRICK_FENCE_GATE);
        coalBrickPool.method_25720(ModBlocks.COAL_BRICK_WALL);

        class_4910.class_4912 calcifiedCoalPool = blockStateModelGenerator.method_25650(ModBlocks.CALCIFIED_COAL_BLOCK);
        calcifiedCoalPool.method_25725(ModBlocks.CALCIFIED_COAL_STAIRS);
        calcifiedCoalPool.method_25724(ModBlocks.CALCIFIED_COAL_SLAB);
        calcifiedCoalPool.method_25721(ModBlocks.CALCIFIED_COAL_FENCE);
        calcifiedCoalPool.method_25722(ModBlocks.CALCIFIED_COAL_FENCE_GATE);
        calcifiedCoalPool.method_25720(ModBlocks.CALCIFIED_COAL_WALL);

        class_4910.class_4912 polishedCoalPool = blockStateModelGenerator.method_25650(ModBlocks.POLISHED_COAL_BLOCK);
        polishedCoalPool.method_25725(ModBlocks.POLISHED_COAL_STAIRS);
        polishedCoalPool.method_25724(ModBlocks.POLISHED_COAL_SLAB);
        polishedCoalPool.method_25721(ModBlocks.POLISHED_COAL_FENCE);
        polishedCoalPool.method_25722(ModBlocks.POLISHED_COAL_FENCE_GATE);
        polishedCoalPool.method_25720(ModBlocks.POLISHED_COAL_WALL);

        class_4910.class_4912 netheritePool = blockStateModelGenerator.method_25650(class_2246.field_22108);
        netheritePool.method_25725(ModBlocks.NETHERITE_STAIRS);
        netheritePool.method_25724(ModBlocks.NETHERITE_SLAB);
        netheritePool.method_25721(ModBlocks.NETHERITE_FENCE);
        netheritePool.method_25722(ModBlocks.NETHERITE_FENCE_GATE);
        netheritePool.method_25720(ModBlocks.NETHERITE_WALL);
        blockStateModelGenerator.method_25658(ModBlocks.NETHERITE_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.NETHERITE_TRAPDOOR);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.POLISHED_NETHERITE_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.CALCIFIED_NETHERITE_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.NETHERITE_BRICKS);

        class_4910.class_4912 netheriteBrickPool = blockStateModelGenerator.method_25650(ModBlocks.NETHERITE_BRICKS);
        netheriteBrickPool.method_25725(ModBlocks.NETHERITE_BRICK_STAIRS);
        netheriteBrickPool.method_25724(ModBlocks.NETHERITE_BRICK_SLAB);
        netheriteBrickPool.method_25721(ModBlocks.NETHERITE_BRICK_FENCE);
        netheriteBrickPool.method_25722(ModBlocks.NETHERITE_BRICK_FENCE_GATE);
        netheriteBrickPool.method_25720(ModBlocks.NETHERITE_BRICK_WALL);

        class_4910.class_4912 calcifiedNetheritePool = blockStateModelGenerator.method_25650(ModBlocks.CALCIFIED_NETHERITE_BLOCK);
        calcifiedNetheritePool.method_25725(ModBlocks.CALCIFIED_NETHERITE_STAIRS);
        calcifiedNetheritePool.method_25724(ModBlocks.CALCIFIED_NETHERITE_SLAB);
        calcifiedNetheritePool.method_25721(ModBlocks.CALCIFIED_NETHERITE_FENCE);
        calcifiedNetheritePool.method_25722(ModBlocks.CALCIFIED_NETHERITE_FENCE_GATE);
        calcifiedNetheritePool.method_25720(ModBlocks.CALCIFIED_NETHERITE_WALL);

        class_4910.class_4912 polishedNetheritePool = blockStateModelGenerator.method_25650(ModBlocks.POLISHED_NETHERITE_BLOCK);
        polishedNetheritePool.method_25725(ModBlocks.POLISHED_NETHERITE_STAIRS);
        polishedNetheritePool.method_25724(ModBlocks.POLISHED_NETHERITE_SLAB);
        polishedNetheritePool.method_25721(ModBlocks.POLISHED_NETHERITE_FENCE);
        polishedNetheritePool.method_25722(ModBlocks.POLISHED_NETHERITE_FENCE_GATE);
        polishedNetheritePool.method_25720(ModBlocks.POLISHED_NETHERITE_WALL);

        class_4910.class_4912 calcitePool = blockStateModelGenerator.method_25650(class_2246.field_27114);
        calcitePool.method_25725(ModBlocks.CALCITE_STAIRS);
        calcitePool.method_25724(ModBlocks.CALCITE_SLAB);
        calcitePool.method_25721(ModBlocks.CALCITE_FENCE);
        calcitePool.method_25722(ModBlocks.CALCITE_FENCE_GATE);
        calcitePool.method_25720(ModBlocks.CALCITE_WALL);

        class_4910.class_4912 lapisPool = blockStateModelGenerator.method_25650(class_2246.field_10441);
        lapisPool.method_25725(ModBlocks.LAPIS_STAIRS);
        lapisPool.method_25724(ModBlocks.LAPIS_SLAB);
        lapisPool.method_25721(ModBlocks.LAPIS_FENCE);
        lapisPool.method_25722(ModBlocks.LAPIS_FENCE_GATE);
        lapisPool.method_25720(ModBlocks.LAPIS_WALL);
        blockStateModelGenerator.method_25658(ModBlocks.LAPIS_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.LAPIS_TRAPDOOR);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.POLISHED_LAPIS_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.CALCIFIED_LAPIS_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.LAPIS_BRICKS);

        class_4910.class_4912 lapisBrickPool = blockStateModelGenerator.method_25650(ModBlocks.LAPIS_BRICKS);
        lapisBrickPool.method_25725(ModBlocks.LAPIS_BRICK_STAIRS);
        lapisBrickPool.method_25724(ModBlocks.LAPIS_BRICK_SLAB);
        lapisBrickPool.method_25721(ModBlocks.LAPIS_BRICK_FENCE);
        lapisBrickPool.method_25722(ModBlocks.LAPIS_BRICK_FENCE_GATE);
        lapisBrickPool.method_25720(ModBlocks.LAPIS_BRICK_WALL);

        class_4910.class_4912 calcifiedLapisPool = blockStateModelGenerator.method_25650(ModBlocks.CALCIFIED_LAPIS_BLOCK);
        calcifiedLapisPool.method_25725(ModBlocks.CALCIFIED_LAPIS_STAIRS);
        calcifiedLapisPool.method_25724(ModBlocks.CALCIFIED_LAPIS_SLAB);
        calcifiedLapisPool.method_25721(ModBlocks.CALCIFIED_LAPIS_FENCE);
        calcifiedLapisPool.method_25722(ModBlocks.CALCIFIED_LAPIS_FENCE_GATE);
        calcifiedLapisPool.method_25720(ModBlocks.CALCIFIED_LAPIS_WALL);

        class_4910.class_4912 polishedLapisPool = blockStateModelGenerator.method_25650(ModBlocks.POLISHED_LAPIS_BLOCK);
        polishedLapisPool.method_25725(ModBlocks.POLISHED_LAPIS_STAIRS);
        polishedLapisPool.method_25724(ModBlocks.POLISHED_LAPIS_SLAB);
        polishedLapisPool.method_25721(ModBlocks.POLISHED_LAPIS_FENCE);
        polishedLapisPool.method_25722(ModBlocks.POLISHED_LAPIS_FENCE_GATE);
        polishedLapisPool.method_25720(ModBlocks.POLISHED_LAPIS_WALL);

        class_4910.class_4912 redstonePool = blockStateModelGenerator.method_25650(class_2246.field_10002);
        redstonePool.method_25725(ModBlocks.REDSTONE_STAIRS);
        redstonePool.method_25724(ModBlocks.REDSTONE_SLAB);
        redstonePool.method_25721(ModBlocks.REDSTONE_FENCE);
        redstonePool.method_25722(ModBlocks.REDSTONE_FENCE_GATE);
        redstonePool.method_25720(ModBlocks.REDSTONE_WALL);
        blockStateModelGenerator.method_25658(ModBlocks.REDSTONE_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.REDSTONE_TRAPDOOR);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.POLISHED_REDSTONE_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.CALCIFIED_REDSTONE_BLOCK);
//        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.REDSTONE_BRICKS);

        class_4910.class_4912 redstoneBrickPool = blockStateModelGenerator.method_25650(ModBlocks.REDSTONE_BRICKS);
        redstoneBrickPool.method_25725(ModBlocks.REDSTONE_BRICK_STAIRS);
        redstoneBrickPool.method_25724(ModBlocks.REDSTONE_BRICK_SLAB);
        redstoneBrickPool.method_25721(ModBlocks.REDSTONE_BRICK_FENCE);
        redstoneBrickPool.method_25722(ModBlocks.REDSTONE_BRICK_FENCE_GATE);
        redstoneBrickPool.method_25720(ModBlocks.REDSTONE_BRICK_WALL);

        class_4910.class_4912 calcifiedRedstonePool = blockStateModelGenerator.method_25650(ModBlocks.CALCIFIED_REDSTONE_BLOCK);
        calcifiedRedstonePool.method_25725(ModBlocks.CALCIFIED_REDSTONE_STAIRS);
        calcifiedRedstonePool.method_25724(ModBlocks.CALCIFIED_REDSTONE_SLAB);
        calcifiedRedstonePool.method_25721(ModBlocks.CALCIFIED_REDSTONE_FENCE);
        calcifiedRedstonePool.method_25722(ModBlocks.CALCIFIED_REDSTONE_FENCE_GATE);
        calcifiedRedstonePool.method_25720(ModBlocks.CALCIFIED_REDSTONE_WALL);

        class_4910.class_4912 polishedRedstonePool = blockStateModelGenerator.method_25650(ModBlocks.POLISHED_REDSTONE_BLOCK);
        polishedRedstonePool.method_25725(ModBlocks.POLISHED_REDSTONE_STAIRS);
        polishedRedstonePool.method_25724(ModBlocks.POLISHED_REDSTONE_SLAB);
        polishedRedstonePool.method_25721(ModBlocks.POLISHED_REDSTONE_FENCE);
        polishedRedstonePool.method_25722(ModBlocks.POLISHED_REDSTONE_FENCE_GATE);
        polishedRedstonePool.method_25720(ModBlocks.POLISHED_REDSTONE_WALL);

        class_4910.class_4912 obsidianPool = blockStateModelGenerator.method_25650(class_2246.field_10540);
        obsidianPool.method_25725(ModBlocks.OBSIDIAN_STAIRS);
        obsidianPool.method_25724(ModBlocks.OBSIDIAN_SLAB);
        obsidianPool.method_25721(ModBlocks.OBSIDIAN_FENCE);
        obsidianPool.method_25722(ModBlocks.OBSIDIAN_FENCE_GATE);
        obsidianPool.method_25720(ModBlocks.OBSIDIAN_WALL);

        class_4910.class_4912 bedrockPool = blockStateModelGenerator.method_25650(class_2246.field_9987);
        bedrockPool.method_25725(ModBlocks.BEDROCK_STAIRS);
        bedrockPool.method_25724(ModBlocks.BEDROCK_SLAB);
        bedrockPool.method_25721(ModBlocks.BEDROCK_FENCE);
        bedrockPool.method_25722(ModBlocks.BEDROCK_FENCE_GATE);
        bedrockPool.method_25720(ModBlocks.BEDROCK_WALL);

        class_4910.class_4912 sculkPool = blockStateModelGenerator.method_25650(class_2246.field_37568);
        sculkPool.method_25725(ModBlocks.SCULK_STAIRS);
        sculkPool.method_25724(ModBlocks.SCULK_SLAB);
        sculkPool.method_25721(ModBlocks.SCULK_FENCE);
        sculkPool.method_25722(ModBlocks.SCULK_FENCE_GATE);
        sculkPool.method_25720(ModBlocks.SCULK_WALL);

        class_4910.class_4912 packedIcePool = blockStateModelGenerator.method_25650(class_2246.field_10225);
        packedIcePool.method_25725(ModBlocks.PACKED_ICE_STAIRS);
        packedIcePool.method_25724(ModBlocks.PACKED_ICE_SLAB);
        packedIcePool.method_25721(ModBlocks.PACKED_ICE_FENCE);
        packedIcePool.method_25722(ModBlocks.PACKED_ICE_FENCE_GATE);
        packedIcePool.method_25720(ModBlocks.PACKED_ICE_WALL);

        class_4910.class_4912 blueIcePool = blockStateModelGenerator.method_25650(class_2246.field_10384);
        blueIcePool.method_25725(ModBlocks.BLUE_ICE_STAIRS);
        blueIcePool.method_25724(ModBlocks.BLUE_ICE_SLAB);
        blueIcePool.method_25721(ModBlocks.BLUE_ICE_FENCE);
        blueIcePool.method_25722(ModBlocks.BLUE_ICE_FENCE_GATE);
        blueIcePool.method_25720(ModBlocks.BLUE_ICE_WALL);

        class_4910.class_4912 icePool = blockStateModelGenerator.method_25650(class_2246.field_10295);
        icePool.method_25725(ModBlocks.ICE_STAIRS);
        icePool.method_25724(ModBlocks.ICE_SLAB);
        icePool.method_25721(ModBlocks.ICE_FENCE);
        icePool.method_25722(ModBlocks.ICE_FENCE_GATE);
        icePool.method_25720(ModBlocks.ICE_WALL);

        class_4910.class_4912 deepslateEmeraldOrePool = blockStateModelGenerator.method_25650(class_2246.field_29220);
        deepslateEmeraldOrePool.method_25725(ModBlocks.DEEPSLATE_EMERALD_ORE_STAIRS);
        deepslateEmeraldOrePool.method_25724(ModBlocks.DEEPSLATE_EMERALD_ORE_SLAB);
        deepslateEmeraldOrePool.method_25721(ModBlocks.DEEPSLATE_EMERALD_ORE_FENCE);
        deepslateEmeraldOrePool.method_25722(ModBlocks.DEEPSLATE_EMERALD_ORE_FENCE_GATE);
        deepslateEmeraldOrePool.method_25720(ModBlocks.DEEPSLATE_EMERALD_ORE_WALL);

        class_4910.class_4912 prismarineBricksPool = blockStateModelGenerator.method_25650(class_2246.field_10006);
        class_4910.class_4912 darkPrismarinePool = blockStateModelGenerator.method_25650(class_2246.field_10297);
        prismarineBricksPool.method_25720(ModBlocks.PRISMARINE_BRICK_WALL);
        darkPrismarinePool.method_25720(ModBlocks.DARK_PRISMARINE_WALL);


    }

//    private static Model item(TextureKey... requiredTextureKeys) {
//        return new Model(Optional.of(Identifier.of(MoreMineralBlocks.MOD_ID+":item/longswords_parent")), Optional.empty(), requiredTextureKeys);
//    }
//
//    public static final Model LONGSWORD = item(TextureKey.LAYER0);
//public static final Model LONGSWORD = Models.item(Identifier.of(MoreMineralBlocks.MOD_ID, "item/longswords_parent"));

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        //itemModelGenerator.register(ModItems.PINK_GARNET, Models.GENERATED);
        //itemModelGenerator.register(ModItems.RAW_PINK_GARNET, Models.GENERATED);
        //itemModelGenerator.register(ModItems.CHISEL, Models.GENERATED);
        itemModelGenerator.method_65442(ModItems.LEGENDARY_PICKAXE, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.LEGENDARY_SHOVEL, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.LEGENDARY_AXE, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.LEGENDARY_HOE, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.LEGENDARY_SWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.WOODEN_LONGSWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.STONE_LONGSWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.IRON_LONGSWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.GOLDEN_LONGSWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.DIAMOND_LONGSWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.NETHERITE_LONGSWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.FLAMEBERGE_LONGSWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.FIRE_DRAGONSWORD_LONGSWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.FIENDBLADE_LONGSWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.LEGENDARY_LONGSWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.FLASH, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.MAGIC_MIRROR, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.REFLECTIVE_MIRROR, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.CHAOS_MIRROR, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.CHAOS_ORB, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.LEGENDARY_ROCKET, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.INFINITE_ITEMSTACK, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.SURVIVAL_DEBUG_STICK, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.LA_LECHONA, class_4943.field_22939);


//        ItemModel.Unbaked unbakedLegendaryPickaxe = ItemModels.basic(itemModelGenerator.upload(ModItems.LEGENDARY_PICKAXE, Models.HANDHELD));
//        ItemModel.Unbaked unbakedLegendaryPickaxeSet2Enchantments = ItemModels.basic(itemModelGenerator.registerSubModel(ModItems.LEGENDARY_PICKAXE, "_set_2_enchantments", Models.HANDHELD));
//
//
//        ItemModel.Unbaked unbakedSword = ItemModels.basic(itemModelGenerator.upload(ModItems.LEGENDARY_SWORD, Models.HANDHELD));
//        ItemModel.Unbaked unbakedSword2 = ItemModels.basic(itemModelGenerator.registerSubModel(ModItems.LEGENDARY_SWORD, "_used", Models.HANDHELD));
//
////        List<SelectItemModel.SwitchCase<Float>> cases = List.of(
////                new SelectItemModel.SwitchCase<>(List.of(0.0f), unbakedSword2)
//////                new SelectItemModel.SwitchCase<>(List.of(1), unbakedSword2)
//////                new SelectItemModel.SwitchCase<>(List.of(2), unbakedSword3)
////        );
//
//
//
//        itemModelGenerator.output.accept(ModItems.LEGENDARY_SWORD,
//                new ItemAsset(new ,
//                        new ItemAsset.Properties(false, false, 1)).model());
    }
}
