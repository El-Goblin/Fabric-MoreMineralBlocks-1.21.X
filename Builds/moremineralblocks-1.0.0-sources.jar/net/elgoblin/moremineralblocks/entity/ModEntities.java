package net.elgoblin.moremineralblocks.entity;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.entity.custom.*;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModEntities {

    public static final class_1299<ChaosOrbEntity> CHAOS_ORB = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(MoreMineralBlocks.MOD_ID, "chaos_orb"),
            class_1299.class_1300.<ChaosOrbEntity>method_5903(ChaosOrbEntity::new, class_1311.field_17715)
                    .method_17687(0.25F,0.25F).method_27299(4).method_27300(10)
                    .method_5905(class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "chaos_orb"))));

//    public static final EntityType<MantisEntity> MANTIS = Registry.register(Registries.ENTITY_TYPE,
//            Identifier.of(MoreMineralBlocks.MOD_ID, "mantis"),
//            EntityType.Builder.create(MantisEntity::new, SpawnGroup.CREATURE)
//                    .dimensions(1f, 2.5f).build());
//
//    public static final EntityType<DevilmonEntity> DEVILMON = Registry.register(Registries.ENTITY_TYPE,
//            Identifier.of(MoreMineralBlocks.MOD_ID, "devilmon"),
//            EntityType.Builder.create(DevilmonEntity::new, SpawnGroup.CREATURE)
//                    .dimensions(0.35F, 0.6F)
//                    .eyeHeight(0.36F)
//                    .vehicleAttachment(0.04F)
//                    .maxTrackingRange(8)
//                    .trackingTickInterval(2)
//                    .build());

    public static void registerModEntities() {
        MoreMineralBlocks.LOGGER.info("Registering Mod Entities for " + MoreMineralBlocks.MOD_ID);
    }
}
