package net.elgoblin.moremineralblocks.entity.custom;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.block.ModBlocks;
import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.effect.ModEffects;
import net.elgoblin.moremineralblocks.entity.ModEntities;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.elgoblin.moremineralblocks.item.custom.ChaosOrbItem;
import net.elgoblin.moremineralblocks.particle.ModParticles;
import net.elgoblin.moremineralblocks.terrain.SingleBlockSphereJob;
//import net.elgoblin.moremineralblocks.terrain.SkyBlockJob;
import net.elgoblin.moremineralblocks.terrain.TerrainManager;
//import net.elgoblin.moremineralblocks.util.ProtectorManager;
import net.elgoblin.moremineralblocks.util.ProtectorManager;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1506;
import net.minecraft.class_1528;
import net.minecraft.class_1538;
import net.minecraft.class_1589;
import net.minecraft.class_1621;
import net.minecraft.class_1657;
import net.minecraft.class_1674;
import net.minecraft.class_1747;
import net.minecraft.class_1749;
import net.minecraft.class_1752;
import net.minecraft.class_1769;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1778;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1808;
import net.minecraft.class_1812;
import net.minecraft.class_1823;
import net.minecraft.class_1826;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2580;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3545;
import net.minecraft.class_3730;
import net.minecraft.class_3857;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_5454;
import net.minecraft.class_5633;
import net.minecraft.class_5819;
import net.minecraft.class_6019;
import net.minecraft.class_6024;
import net.minecraft.class_6880;
import net.minecraft.class_7871;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8232;
import net.minecraft.class_8233;
import net.minecraft.class_9239;
import net.minecraft.class_9298;
import net.minecraft.class_9334;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class ChaosOrbEntity extends class_3857 {

    private final Map<String, class_2400> particleMap = Map.of("minecraft:haste", ModParticles.CHAOS_ORB_HASTE_PARTICLE,
            "minecraft:jump_boost", ModParticles.CHAOS_ORB_JUMP_BOOST_PARTICLE,
            "minecraft:regeneration", ModParticles.CHAOS_ORB_REGENERATION_PARTICLE,
            "minecraft:resistance", ModParticles.CHAOS_ORB_RESISTANCE_PARTICLE,
            "minecraft:speed", ModParticles.CHAOS_ORB_SPEED_PARTICLE,
            "minecraft:strength", ModParticles.CHAOS_ORB_STRENGTH_PARTICLE);
    private final class_5819 random = class_5819.method_43047();
    private class_3218 world = null;

    private String seededEvent = "none";
    private final Map<String, class_3545<Integer, Integer>> eventMap = Map.ofEntries(
            Map.entry("mobpack", new class_3545<>(0,0)),
            Map.entry("mythicitem", new class_3545<>(0,1)),
            Map.entry("skeletonhorse", new class_3545<>(0,2)),
            Map.entry("progression", new class_3545<>(0,3)),
            Map.entry("armor", new class_3545<>(0,4)),
            Map.entry("tools", new class_3545<>(0,5)),
            Map.entry("chaos", new class_3545<>(0,6)),
            Map.entry("terrainsphere", new class_3545<>(0,7)),
            Map.entry("explosion", new class_3545<>(0,8)),
            Map.entry("fireexplosion", new class_3545<>(0,9)),
            Map.entry("food", new class_3545<>(0,10)),
            Map.entry("book", new class_3545<>(0,11)),
            Map.entry("prize", new class_3545<>(0, 12)),
            Map.entry("xp", new class_3545<>(0, 13)),

            Map.entry("beacon", new class_3545<>(1,0)),

            Map.entry("range", new class_3545<>(2, 0)),
            Map.entry("fragile", new class_3545<>(2,1)),

            Map.entry("storm", new class_3545<>(4,0)),
            Map.entry("teleport", new class_3545<>(4,1)),

            Map.entry("counterBlink", new class_3545<>(5,0)),
            Map.entry("blinking", new class_3545<>(5,1)),
            Map.entry("20", new class_3545<>(5,2)),
            Map.entry("scale", new class_3545<>(5,3)),

            Map.entry("help", new class_3545<>(6,0))
    );

    private boolean tunneler = false;
    private LinkedList<class_2338> tunnelQueue = new LinkedList<>();
    private static boolean skyBlockHappened = false;

    private List<Consumer<class_239>> pointChaosEffects = new ArrayList<>(List.of(
            this::spawnMobPack,
            this::getMythicItem,
            this::spawnSkeletonHorse,
            this::breakGameProgression,
            this::getArmorSet,
            this::getToolsSet,
            this::spawn5ChaosOrbs,
            this::voidSphere,
            this::explosion, // Ponerle timer
            this::fireExplosion, // Ponerle timer
            this::getFood,
            this::getEnchantedBook,
            this::smallPrize,
            this::xp
//            this::getInfiniteItem
    ));
    private List<BiConsumer<class_239, class_238>> areaChaosEffects = new ArrayList<>(List.of(
            this::applyBeaconEffect
    ));
    private List<BiConsumer<class_239, class_238>> selfAreaChaosEffects = new ArrayList<>(List.of(
            this::increaseInteractionRange,
            this::fragile
    ));
    private List<Consumer<class_239>> selfChaosEffects = new ArrayList<>(List.of(
//            this::crash
    ));
    private List<Consumer<class_239>> globalChaosEffects = new ArrayList<>(List.of(
            this::beginThunderstorm,
            this::randomizePlayersPositions
//            this::createSkyblock
            // Skyblock se va a ir agregando en cada llamado hasta que salga una vez.
    ));
    private List<BiConsumer<class_239, class_238>> targetsOrSelfChaosEffects = new ArrayList<>(List.of(
            this::counterBlinking,
//            this::adventureGamemode
//            this::onanaHands,
            this::blinking,
            this::moveXBlocks,
            this::changeScale
    ));

    private List<Consumer<class_239>> debugChaosEffects = new ArrayList<>(List.of(
            this::debugHelp
    ));


    public ChaosOrbEntity(class_1299<? extends ChaosOrbEntity> entityType, class_1937 world) {
        super(entityType, world);
//        this.addSkyBlock();
        this.tunneler = field_5974.method_39332(0, this.effectCount()) == 0;
        if (!world.method_8608()) {
            this.world = (class_3218) world;
        }
    }

    public ChaosOrbEntity(class_1937 world, class_1309 owner, class_1799 stack) {
        super(ModEntities.CHAOS_ORB, owner, world, stack);
//        this.addSkyBlock();
        this.tunneler = field_5974.method_39332(0, this.effectCount()) == 0;
        if (!world.method_8608()) {
            this.world = (class_3218) world;
        }
        if (stack.method_65130() != null) {
            seededEvent = stack.method_65130().getString().toLowerCase();
            if (stack.method_65130().getString().equalsIgnoreCase("tunneler")) {
                tunneler = true;
            }
        }
    }

    public ChaosOrbEntity(class_1937 world, double x, double y, double z, class_1799 stack) {
        super(ModEntities.CHAOS_ORB, x, y, z, world, stack);
//        this.addSkyBlock();
        this.tunneler = field_5974.method_39332(0, this.effectCount()) == 0;
        if (!world.method_8608()) {
            this.world = (class_3218) world;
        }
        if (stack.method_65130() != null) {
            seededEvent = stack.method_65130().getString().toLowerCase();
            if (stack.method_65130().getString().equalsIgnoreCase("tunneler")) {
                tunneler = true;
            }
        }
    }


//    private void addSkyBlock() {
//        MinecraftServer server = this.getEntityWorld().getServer();
//        if (server != null) {
//            if (!MoreMineralBlocks.getStateSaverAndLoader(server).hasSkyblockHappened()) {
//                this.globalChaosEffects.add(this::createSkyblock);
//            }
//        }
//    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.tunneler) {
            if (!this.method_73183().method_8608()) {
                class_2338 center = new class_2338(new class_2382((int) this.method_23317(), (int) this.method_23318(), (int) this.method_23321()));

                for (int x = -5; x <= 5; x++) {
                    for (int z = -5; z <= 5; z++) {
                        for (int y = -5; y <= 5; y++) {
                            if (x * x + y * y + z * z > 25) {
                                continue;
                            }

                            class_2338 currentBlock = center.method_10069(x, y, z);
                            this.tunnelQueue.add(currentBlock);
                        }
                    }
                }
                class_1937 world = this.method_73183();
                while (!tunnelQueue.isEmpty()) {
                    class_2338 blockToRemove = tunnelQueue.pop();
                    class_2680 currentState = world.method_8320(blockToRemove);

                    MinecraftServer server = this.method_73183().method_8503();
                    if (server != null) {
                        ProtectorManager protectorManager = ProtectorManager.getProtectorManager(this.method_73183().method_8503());

                        if (!currentState.method_26215() && !protectorManager.isProtected(blockToRemove)) {
                            world.method_8652(blockToRemove, class_2246.field_10124.method_9564(), 50);
                        }
                    }
                }
            }
        }
    }

    private int nextCategory() {

        int pointChaosEffectsInterval = pointChaosEffects.size();
        int areaChaosEffectsInterval = pointChaosEffectsInterval + areaChaosEffects.size();
        int selfAreaChaosEffectsInterval = areaChaosEffectsInterval + selfAreaChaosEffects.size();
        int selfChaosEffectsInterval = selfAreaChaosEffectsInterval + selfChaosEffects.size();
        int globalChaosEffectsInterval = selfChaosEffectsInterval + globalChaosEffects.size();
        int targetsOrSelfChaosEffectsInterval = globalChaosEffectsInterval + targetsOrSelfChaosEffects.size();


        int category = this.field_5974.method_39332(0, targetsOrSelfChaosEffectsInterval-1);

        if (category < pointChaosEffectsInterval) {
            return 0;
        } else if (category < areaChaosEffectsInterval) {
            return 1;
        } else if (category < selfAreaChaosEffectsInterval) {
            return 2;
        } else if (category < selfChaosEffectsInterval) {
            return 3;
        } else if (category < globalChaosEffectsInterval) {
            return 4;
        } else { // Targets or Self Chaos Effects Interval
            return 5;
        }
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {
        super.method_7454(entityHitResult);
        class_1297 entity = entityHitResult.method_17782();
        if (!entity.method_73183().method_8608()) {
            if (this.method_24921() != null) {
                entity.method_64397((class_3218) entity.method_73183(), this.method_48923().method_48811(this, this.method_24921()), 0);
            }
        }
    }

    @Override
    protected void method_7488(class_239 hitResult) {
        super.method_7488(hitResult);
        if (!this.method_73183().method_8608()) {
            this.method_73183().method_8421(this, class_6024.field_30028);

            int eventCategory = nextCategory();
            int nextEffect;
            class_238 boundingBox = this.method_5829();

            if (eventMap.containsKey(seededEvent)) {
                eventCategory = eventMap.get(seededEvent).method_15442();
            }

            switch (eventCategory) {
                case 0: // POINT
                    // Deberia pasar siempre pero si en algun momento llega a no pasar, crashearia y seria irrecuperable el mundo salvo tocar NBTs
                    if (!pointChaosEffects.isEmpty()) {
                        nextEffect = field_5974.method_39332(0, pointChaosEffects.size()-1);
                        if (eventMap.containsKey(seededEvent)) {
                            nextEffect = eventMap.get(seededEvent).method_15441();
                        }
                        pointChaosEffects.get(nextEffect).accept(hitResult);
                    }
                    break;
                case 1: //AREA
                    if (!areaChaosEffects.isEmpty()) {
                        nextEffect = field_5974.method_39332(0, areaChaosEffects.size()-1);
                        if (eventMap.containsKey(seededEvent)) {
                            nextEffect = eventMap.get(seededEvent).method_15441();
                        }
                        areaChaosEffects.get(nextEffect).accept(hitResult, boundingBox);
                    }
                    break;
                case 2: //SELF AREA
                    if (!selfAreaChaosEffects.isEmpty()) {
                        nextEffect = field_5974.method_39332(0, selfAreaChaosEffects.size()-1);
                        if (eventMap.containsKey(seededEvent)) {
                            nextEffect = eventMap.get(seededEvent).method_15441();
                        }
                        selfAreaChaosEffects.get(nextEffect).accept(hitResult, boundingBox);
                    }
                    break;
                case 3: //SELF
                    if (!selfChaosEffects.isEmpty()) {
                        nextEffect = field_5974.method_39332(0, selfChaosEffects.size()-1);
                        if (eventMap.containsKey(seededEvent)) {
                            nextEffect = eventMap.get(seededEvent).method_15441();
                        }
                        selfChaosEffects.get(nextEffect).accept(hitResult);
                    }
                    break;
                case 4: //GLOBAL
                    if (!globalChaosEffects.isEmpty()) {
                        nextEffect = field_5974.method_39332(0, globalChaosEffects.size()-1);
                        if (eventMap.containsKey(seededEvent)) {
                            nextEffect = eventMap.get(seededEvent).method_15441();
                        }
                        globalChaosEffects.get(nextEffect).accept(hitResult);
                    }
                    break;
                case 5: //TARGET SELF
                    if (!targetsOrSelfChaosEffects.isEmpty()) {
                        nextEffect = field_5974.method_39332(0, targetsOrSelfChaosEffects.size()-1);
                        if (eventMap.containsKey(seededEvent)) {
                            nextEffect = eventMap.get(seededEvent).method_15441();
                        }
                        targetsOrSelfChaosEffects.get(nextEffect).accept(hitResult, boundingBox);
                    }
                    break;
                case 6: // DEBUG
                    nextEffect = 0;
                    if (eventMap.containsKey(seededEvent)) {
                        nextEffect = eventMap.get(seededEvent).method_15441();
                    }
                    debugChaosEffects.get(nextEffect).accept(hitResult);
            }

            this.method_31472();
        }
    }

    @Override
    protected class_1792 method_16942() {
        return ModItems.CHAOS_ORB;
    }

    public int effectCount() {
        return this.pointChaosEffects.size() +
                this.areaChaosEffects.size() +
                this.selfAreaChaosEffects.size() +
                this.selfChaosEffects.size() +
                this.globalChaosEffects.size() +
                this.targetsOrSelfChaosEffects.size();
    }

    {
//    private static final List<TropicalFishEntity.Variant> TROPICAL_FISH_VARIANTS = List.of(
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.STRIPEY, DyeColor.ORANGE, DyeColor.GRAY),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.FLOPPER, DyeColor.GRAY, DyeColor.GRAY),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.FLOPPER, DyeColor.GRAY, DyeColor.BLUE),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.CLAYFISH, DyeColor.WHITE, DyeColor.GRAY),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.SUNSTREAK, DyeColor.BLUE, DyeColor.GRAY),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.KOB, DyeColor.ORANGE, DyeColor.WHITE),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.SPOTTY, DyeColor.PINK, DyeColor.LIGHT_BLUE),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.BLOCKFISH, DyeColor.PURPLE, DyeColor.YELLOW),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.CLAYFISH, DyeColor.WHITE, DyeColor.RED),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.SPOTTY, DyeColor.WHITE, DyeColor.YELLOW),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.GLITTER, DyeColor.WHITE, DyeColor.GRAY),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.CLAYFISH, DyeColor.WHITE, DyeColor.ORANGE),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.DASHER, DyeColor.CYAN, DyeColor.PINK),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.BRINELY, DyeColor.LIME, DyeColor.LIGHT_BLUE),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.BETTY, DyeColor.RED, DyeColor.WHITE),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.SNOOPER, DyeColor.GRAY, DyeColor.RED),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.BLOCKFISH, DyeColor.RED, DyeColor.WHITE),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.FLOPPER, DyeColor.WHITE, DyeColor.YELLOW),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.KOB, DyeColor.RED, DyeColor.WHITE),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.SUNSTREAK, DyeColor.GRAY, DyeColor.WHITE),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.DASHER, DyeColor.CYAN, DyeColor.YELLOW),
//            new TropicalFishEntity.Variant(TropicalFishEntity.Variety.FLOPPER, DyeColor.YELLOW, DyeColor.YELLOW)
//    );
    }

    // Falta axolotl y tropical fish TODO
    private void spawnMobPack(class_239 hitResult) {

        // Como es esto un tipo???
        List<class_1299<?>> mobs = class_7923.field_41177.method_10220()
                .filter(type -> type.method_5891() != class_1311.field_17715)
                .toList();

        int nextEntity = this.field_5974.method_39332(0, mobs.size()-1);
        int spawnsToPerform = this.field_5974.method_39332(5, 14);

        class_1299<?> entityType = mobs.get(nextEntity);
        class_2960 entityTypeID = class_7923.field_41177.method_10221(entityType);

        while (spawnsToPerform-- > 0) {
            class_1297 entity = entityType.method_5883(world, class_3730.field_16467);

            switch (entityTypeID.toString()) {

                case "minecraft:wither":
                    if (entity != null) {
                        ((class_1528) entity).method_6875(440);
                    }
                    spawnsToPerform -= 4;
                    break;

                case "minecraft:ender_dragon", "minecraft:warden", "moremineralblocks:devilmon":
                    nextEntity = this.field_5974.method_39332(0, mobs.size() - 1);
                    entityType = mobs.get(nextEntity);
                    entityTypeID = class_7923.field_41177.method_10221(entityType);
                    entity = entityType.method_5883(world, class_3730.field_16467);
                    spawnsToPerform++;
                    break;


                case "minecraft:bat", "minecraft:bee", "minecraft:chicken", "minecraft:cod", "minecraft:frog", "minecraft:pufferfish", "minecraft:rabbit", "minecraft:salmon", "minecraft:silverfish", "minecraft:endermite", "minecraft:tadpole":
                    class_1297 entity2 = entityType.method_5883(world, class_3730.field_16467);
                    if (entity2 != null) {
                        entity2.method_5808(this.method_23317(), this.method_23318(), this.method_23321(), this.method_36454(), 0.0F);
                        world.method_8649(entity2);
                    }
                    class_1297 entity3 = entityType.method_5883(world, class_3730.field_16467);
                    if (entity3 != null) {
                        entity3.method_5808(this.method_23317(), this.method_23318(), this.method_23321(), this.method_36454(), 0.0F);
                        world.method_8649(entity3);
                    }
                    break;

//                case "minecraft:tropical_fish":
//                    for (int i = 0 ; i < 3 ; i++) {
//                        entity = entityType.create(world, SpawnReason.EVENT);
//                        if (entity != null) {
//                            TropicalFishEntity.Variant variant = TROPICAL_FISH_VARIANTS.get(random.nextBetween(0, TROPICAL_FISH_VARIANTS.size()-1));
//                            int variantInt = variant.variety().getId() & 65535 |  (variant.baseColor().getId() & 0xFF) << 16 | (variant.patternColor().getId() & 0xFF) << 24;
//
//                            NbtCompound nbt = new NbtCompound();
//                            entity.writeNbt(nbt);
//                            nbt.putInt("Variant", variantInt);
//                            entity.readNbt(nbt);
//                            entity.refreshPositionAndAngles(this.getX(), this.getY(), this.getZ(), this.getYaw(), 0.0F);
//                            world.spawnEntity(entity);
//                        }
//                    }
//                    break;

//                case "minecraft:axolotl":
//                    spawnsToPerform -= 3;
//                    if (entity != null) {
//                        ((AxolotlEntity) entity).setVariant(AxolotlEntity.Variant.byId(random.nextBetween(0,4)));
//                    }
//                    break;

                case "minecraft:elder_guardian":
                    spawnsToPerform-=4;
                    break;

                case "minecraft:slime":
                    if (entity != null) {
                        ((class_1621) entity).method_7161(field_5974.method_39332(1, 4), true);
                    }
                    break;

                case "minecraft:magma_cube":
                    if (entity != null) {
                        ((class_1589) entity).method_7161(field_5974.method_39332(1, 4), true);
                    }
                    break;

                case "minecraft:evoker", "minecraft:ravager":
                    spawnsToPerform-=2;
                    break;
            }

            if (entity != null) {
                entity.method_5808(this.method_23317(), this.method_23318(), this.method_23321(), this.method_36454(), 0.0F);
                world.method_8649(entity);
            }
        }
    }

    private void spawnSkeletonHorse(class_239 hitResult) {
        class_1506 skeletonHorseEntity = class_1299.field_6075.method_5883(world, class_3730.field_16467);
        if (skeletonHorseEntity != null) {
            skeletonHorseEntity.method_6813(true);
            skeletonHorseEntity.method_5614(0);
            skeletonHorseEntity.method_5808(this.method_23317(), this.method_23318(), this.method_23321(), this.method_36454(), 0.0F);

            world.method_8649(skeletonHorseEntity);
        }
    }

    private void beginThunderstorm(class_239 hitResult) {
        if (world.method_8503() != null) {
            class_3218 serverWorld = world.method_8503().method_30002();
            serverWorld.method_27910(0, class_6019.method_35017(3600, 15600).method_35008(serverWorld.method_8409()), true, true);
            class_1538 bolt = class_1299.field_6112.method_5883(world, class_3730.field_16467);
            if (bolt != null) {
                bolt.method_60949(hitResult.method_17784(),1f, 1f);
                world.method_8649(bolt);
            }
        }
    }

    private void increaseInteractionRange(class_239 hitResult, class_238 boundingBox) {
        List<class_1309> entities = world.method_18467(class_1309.class, boundingBox.method_1009(16.0, 8.0, 16.0));

        for (class_1309 entity : entities) {
            if (entity instanceof class_1657 player) {
                player.method_7353(class_2561.method_30163("+1"), false);

                class_2960 entityInteractionRangeModifierID = class_2960.method_60654(MoreMineralBlocks.MOD_ID + ":entity_interaction_range_modifier");
                class_2960 blockInteractionRangeModifierID = class_2960.method_60654(MoreMineralBlocks.MOD_ID + ":block_interaction_range_modifier");

                if (player.method_6127().method_45330(class_5134.field_47759, entityInteractionRangeModifierID)) {
                    class_1322 rangeModifier = new class_1322(entityInteractionRangeModifierID
                            , class_3532.method_15391(player.method_6127().method_45332(class_5134.field_47759, entityInteractionRangeModifierID) + 1, 5)
                            , class_1322.class_1323.field_6328);

                    class_1324 entityInteractionRangeInstance = player.method_5996(class_5134.field_47759);
                    if (entityInteractionRangeInstance != null) {
                        entityInteractionRangeInstance.method_6200(entityInteractionRangeModifierID);
                        entityInteractionRangeInstance.method_26837(rangeModifier);
                    }
                } else {
                    class_1324 entityInteractionRangeInstance = player.method_5996(class_5134.field_47759);
                    class_1322 rangeModifier = new class_1322(entityInteractionRangeModifierID
                            , 1
                            , class_1322.class_1323.field_6328);

                    if (entityInteractionRangeInstance != null) {
                        entityInteractionRangeInstance.method_26837(rangeModifier);
                    }
                }

                if (player.method_6127().method_45330(class_5134.field_47758, blockInteractionRangeModifierID)) {
                    class_1322 rangeModifier = new class_1322(blockInteractionRangeModifierID
                            , class_3532.method_15391(player.method_6127().method_45332(class_5134.field_47758, blockInteractionRangeModifierID) + 1, 5)
                            , class_1322.class_1323.field_6328);

                    class_1324 entityInteractionRangeInstance = player.method_5996(class_5134.field_47758);
                    if (entityInteractionRangeInstance != null) {
                        entityInteractionRangeInstance.method_6200(blockInteractionRangeModifierID);
                        entityInteractionRangeInstance.method_26837(rangeModifier);
                    }
                } else {
                    class_1324 entityInteractionRangeInstance = player.method_5996(class_5134.field_47758);
                    class_1322 rangeModifier = new class_1322(blockInteractionRangeModifierID
                            , 1
                            , class_1322.class_1323.field_6328);

                    if (entityInteractionRangeInstance != null) {
                        entityInteractionRangeInstance.method_26837(rangeModifier);
                    }
                }
            }
        }
    }

    private record ScalePack(
            double scale,
            double max_hp,
            double step_height,
            double fall_height,
//            double fall_damage,
            double speed,
            double jump,
            double block_interaction_range,
            double entity_interaction_range,
            double block_break_speed) {

    };

    private static final List<ScalePack> scalePacks = new ArrayList<ScalePack>(List.of(
            new ScalePack(0.25,10, 0.6, 2, 0.08, 0.4, 3.5, 2.5, 1),
            new ScalePack(0.5, 16, 0.6, 2.5, 0.09, 0.42, 4, 3, 1),
            new ScalePack(1.5, 24, 1.126, 4.5,  0.125, 0.52, 5, 4, 2),
            new ScalePack(2, 30, 1.126, 6,  0.15, 0.62, 6.5, 4.5, 2)));

    private void applyAttributeChange(class_6880<class_1320> attribute, double value, class_1309 player) {
        class_1324 currentStat = player.method_5996(attribute);
        if (currentStat != null) {
            currentStat.method_6192(value);
        }
    }

    private void changeScale(class_239 hitResult, class_238 boundingBox) {
        List<class_1309> entities = world.method_18467(class_1309.class, boundingBox.method_1009(16.0, 8.0, 16.0));

        ScalePack chosenPack = scalePacks.get(field_5974.method_43048(scalePacks.size()));

        if (this.method_24921() != null && !entities.contains((class_1309) this.method_24921())) {
            entities.add((class_1309) this.method_24921());
        }

        for (class_1309 entity : entities) {
            applyAttributeChange(class_5134.field_47760, chosenPack.scale, entity);

            if (entity instanceof class_1657 player) {
                applyAttributeChange(class_5134.field_23716, chosenPack.max_hp, player);
                applyAttributeChange(class_5134.field_47761, chosenPack.step_height, player);
                applyAttributeChange(class_5134.field_49079, chosenPack.fall_height, player);
                applyAttributeChange(class_5134.field_23719, chosenPack.speed, player);
                applyAttributeChange(class_5134.field_23728, chosenPack.jump, player);
                applyAttributeChange(class_5134.field_47758, chosenPack.block_interaction_range, player);
                applyAttributeChange(class_5134.field_47759, chosenPack.entity_interaction_range, player);
                applyAttributeChange(class_5134.field_49076, chosenPack.block_break_speed, player);

                player.method_7270(new class_1799(ModItems.LA_LECHONA));
            }
        }
    }

    private void moveXBlocks(class_239 hitResult, class_238 boundingBox) {
        List<class_1309> entities = world.method_18467(class_1309.class, boundingBox.method_1009(16.0, 8.0, 16.0));
        boolean goDown = this.field_5974.method_43056();

        for (class_1309 entity : entities) {

            // Ocurre cuando se muere el player antes de que se calcule la lista
            if (entity == null) {
                continue;
            }

            if (this.method_73183().method_8503() != null) {
                class_3218 server = this.method_73183().method_8503().method_3847(entity.method_73183().method_27983());
                class_5454 teleportTarget = new class_5454(server,
                        new class_243(entity.method_23317(),
                                entity.method_23318() + (goDown ? -20 : 20),
                                entity.method_23321()),
                        new class_243(0, 0, 0),
                        entity.method_36454(),
                        entity.method_36455(),
                        class_5454.field_52245);
                entity.method_5731(teleportTarget);
                if (entity instanceof class_1657 player) {
                    if (goDown) {
                        player.method_7353(class_2561.method_30163("-20"), false);
                    } else {
                        player.method_7353(class_2561.method_30163("+20"), false);
                    }
                }
            }
        }

    }

    private void randomizePlayersPositions(class_239 hitResult) {
        int forceTeleport = field_5974.method_43048(20);
        if (forceTeleport == 0 && this.method_24921() != null && this.method_24921() instanceof class_1657) {
            // Notar que de esta forma se aumenta la estadistica de veces usadas el item. Me parece correcto
            ModItems.CHAOS_MIRROR.method_7836(world, (class_1657) this.method_24921(), class_1268.field_5808);
        }
        else {
            this.method_5775(world, ModItems.CHAOS_MIRROR.method_7854());
        }
    }

    // Creo que se rompe lo visual TODO
    private void applyBeaconEffect(class_239 hitResult, class_238 boundingBox) {

        List<class_1309> entities = world.method_18467(class_1309.class, boundingBox.method_1009(32.0, 200.0, 32.0));
        List<class_6880<class_1291>> pool = class_2580.field_11801.stream().flatMap(List::stream).toList();

        long poolSize = pool.size();
        int nextEffect = this.field_5974.method_39332(0, (int) poolSize-1);
        int nextLevel = this.field_5974.method_39332(0, 9);
        class_6880<class_1291> effect = pool.get(nextEffect);
        class_2400 effectParticle = particleMap.get(effect.method_55840());
        world.method_65096(effectParticle,this.method_23317(), this.method_23318(), this.method_23321(), 1, 0.0, 1.0, 0.0, 1.0);

        for (class_1309 entity : entities) {
            class_1293 effectInstance = new class_1293(effect, 24000, nextLevel);
            if (entity != null) {
                entity.method_6092(effectInstance);
            }
        }
    }

//    private void crash(HitResult hitResult) {
//        // Esto nunca va a funcionar porque el chaosOrb corre en server
//        // Quizas podria hacer que el chequeo lo haga en ChaosOrbItem como hacia para el tunel
//        // No se si vale la pena tener este efecto y ademas mepa que va a generar una banda de bugs
//        if (this.getEntityWorld().isClient) {
//            LivingEntity entity = (LivingEntity) this.getOwner();
//            if (entity != null) { entity.sendMessage(Text.of("crash"));}
//            throw new RuntimeException("Chaos Crash");
//        }
//    }

    private void saveAndQuit(class_239 hitResult) {
    }

    private void getFood(class_239 hitResult) {
        List<class_1792> foodItems = new ArrayList<>();

        for (class_1792 item : class_7923.field_41178) {
            if (item.method_57347().method_58694(class_9334.field_50075) != null &&
                    !(item instanceof class_1812) &&
                    item != class_1802.field_8208 &&
                    item != class_1802.field_8308) {
                foodItems.add(item);
            }
        }

        class_1799 food = foodItems.get(field_5974.method_43048(foodItems.size())).method_7854();
        if (food.method_7909() != class_1802.field_8367 && food.method_7909() != class_1802.field_8463) {
            food.method_7939(32);
        }

        if (food.method_7909() == class_1802.field_8766) {
            List<class_6880<class_1291>> statusEffects = class_7923.field_41174.method_42017()
                    .map(entry -> (class_6880<class_1291>) entry)
                    .toList();
            class_6880<class_1291> effectEntry = statusEffects.get(field_5974.method_43048(statusEffects.size()));

            class_9298.class_8751 chosenEffect = new class_9298.class_8751(effectEntry, 160);

            food.method_57379(class_9334.field_49652, new class_9298(List.of(chosenEffect)));
            food.method_7939(4);
        }
        this.method_5699((class_3218) this.method_73183(), food, 0);
    }

    private void getInfiniteItem(class_239 hitResult) {
        class_1799 infiniteItem = new class_1799(ModItems.DIMENSION_POCKET);
        List<class_1792> items = new ArrayList<>();

        for (class_1792 item : class_7923.field_41178) {
//            if (item.getComponents().contains(DataComponentTypes.FOOD)) {
//                items.add(item);
//            }
                boolean isBlock = item instanceof class_1747;
                boolean isBucket = item instanceof class_5633;
                boolean isSpawnEgg = item instanceof class_1826;
                boolean isThrowableProjectile = item instanceof class_1776 ||
                        item instanceof class_1771 ||
                        item instanceof class_1823 ||
                        item instanceof class_1778 ||
                        item instanceof class_1752 ||
                        item instanceof class_9239 ||
                        item instanceof ChaosOrbItem;
                boolean isDye = item instanceof class_1769;
                boolean isBoat = item instanceof class_1749;
                boolean isInkSac = item instanceof class_8233 || item instanceof class_8232;
                boolean isMinecart = item instanceof class_1808;
                if (isBlock || isBucket || isSpawnEgg || isThrowableProjectile || isDye || isBoat || isInkSac || isMinecart) {
                    items.add(item);
                }
        }

        class_1792 chosenItem = items.get(field_5974.method_43048(items.size()-1));
//        if (chosenItem.getComponents().contains(DataComponentTypes.FOOD)) {
//            infiniteItem.set(DataComponentTypes.FOOD ,chosenItem.getComponents().get(DataComponentTypes.FOOD));
//        }
        if (this.method_24921() != null && this.method_24921() instanceof class_1657 player) {
            player.method_7353(class_2561.method_54155(chosenItem.method_63680()), false);
        }
        infiniteItem.method_57379(ModDataComponentTypes.CHOSEN_INFINITE_ITEM, chosenItem.method_7854());
        this.method_5699((class_3218) this.method_73183(), infiniteItem, 0);
    }

    private void getEnchantedBook(class_239 hitResult) {
        class_1799 enchantedBook = class_1802.field_8598.method_7854();
        List<class_1887> enchantments = world.method_30349().method_30530(class_7924.field_41265).method_10220().toList();
        class_1887 enchantment = enchantments.get(field_5974.method_39332(0, enchantments.size() - 1));
        class_6880<class_1887> enchantmentEntry = this.method_56673().method_30530(class_7924.field_41265).method_47983(enchantment);
        enchantedBook.method_7978(enchantmentEntry, field_5974.method_39332(1, enchantment.method_8183()));
        this.method_5699(world, enchantedBook, 0);
    }

    private void xp(class_239 hitResult) {
        //float prizeMultiplier = (int) Math.pow((random.nextFloat()+1),5);
        //ExperienceOrbEntity.spawn((ServerWorld) this.getEntityWorld(), this.getPos(), (int) (random.nextBetween(32, 128) * prizeMultiplier));
        // El segundo boostea ligeramente las chances para arriba
        class_1303.method_31493(world, this.method_73189(), (int) Math.pow(Math.min(field_5974.method_39332(8,32), field_5974.method_39332(16,32)),3));
    }

    private void smallPrize(class_239 hitResult) {
        List<class_1799> prizes = new ArrayList<>();
        prizes.add(new class_1799(class_1802.field_8583, 64));
        prizes.add(new class_1799(class_1802.field_8606, 64));
        prizes.add(new class_1799(class_1802.field_8713, 64));
        prizes.add(new class_1799(class_1802.field_20391, 64));
        prizes.add(new class_1799(class_1802.field_8067, 64));
        prizes.add(new class_1799(class_1802.field_8354, 64));
        prizes.add(new class_1799(class_1802.field_8281, 20));
        prizes.add(new class_1799(class_1802.field_8893, 1));
        prizes.add(new class_1799(class_1802.field_8634, 16));
        prizes.add(new class_1799(class_1802.field_8894, 12));
        prizes.add(new class_1799(class_1802.field_28042, 32));
        prizes.add(new class_1799(class_1802.field_8090, 1));
        prizes.add(new class_1799(class_1802.field_16482, 64));

        int nextItem = this.field_5974.method_39332(0, prizes.size() -1);
        class_1799 reward = prizes.get(nextItem);

        if (reward.method_7909() == class_1802.field_28042) {
            this.method_5699(world, new class_1799(class_1802.field_8187, 1), 0);
            this.method_5699(world, new class_1799(class_1802.field_8705, 1), 0);
            this.method_5699(world, new class_1799(class_1802.field_8638, 1), 0);
        }
        if (reward.method_7909() == class_1802.field_20391) {
            this.method_5699(world, new class_1799(class_1802.field_20391, 64), 0);
            this.method_5699(world, new class_1799(class_1802.field_20391, 64), 0);
        }

        this.method_5699(world, reward, 0);
    }

    private void breakGameProgression(class_239 hitResult) {
        List<class_1799> rareItems = new ArrayList<>();
        rareItems.add(class_1802.field_8833.method_7854());
        rareItems.add(class_1802.field_49814.method_7854());
        rareItems.add(class_1802.field_8840.method_7854());
        rareItems.add(class_1802.field_8668.method_7854());
        rareItems.add(class_1802.field_41946.method_7854());
        rareItems.add(class_1802.field_8288.method_7854());
        rareItems.add(class_1802.field_8547.method_7854());
        rareItems.add(class_1802.field_8545.method_7854());
        rareItems.add(ModBlocks.PROTECTOR_BLOCK.method_8389().method_7854());

        class_7871<class_1887> enchantments = world.method_30349().method_30530(class_7924.field_41265);

        class_1799 mendingBook = class_1802.field_8598.method_7854();
        class_6880<class_1887> mendingEntry = enchantments.method_46747(class_1893.field_9101);
        mendingBook.method_7978(mendingEntry, 1);
        rareItems.add(mendingBook);

        class_1799 fortuneBook = class_1802.field_8598.method_7854();
        class_6880<class_1887> fortuneEntry = enchantments.method_46747(class_1893.field_9130);
        fortuneBook.method_7978(fortuneEntry, 3);
        rareItems.add(fortuneBook);

        class_1799 lootingBook = class_1802.field_8598.method_7854();
        class_6880<class_1887> lootingEntry = enchantments.method_46747(class_1893.field_9110);
        lootingBook.method_7978(lootingEntry, 3);
        rareItems.add(lootingBook);


        class_1799 diamonds = class_1802.field_8477.method_7854();
        diamonds.method_7939(32);
        rareItems.add(diamonds);

        class_1799 goldenCarrots = class_1802.field_8071.method_7854();
        goldenCarrots.method_7939(64);
        rareItems.add(goldenCarrots);

        class_1799 netherite = class_1802.field_22020.method_7854();
        netherite.method_7939(2);
        rareItems.add(netherite);

        class_1799 bookshelves = class_1802.field_8536.method_7854();
        bookshelves.method_7939(15);
        rareItems.add(bookshelves);

        class_1799 goldenApples = class_1802.field_8367.method_7854();
        goldenApples.method_7939(8);
        rareItems.add(goldenApples);

        class_1799 sponges = class_1802.field_8535.method_7854();
        sponges.method_7939(64);
        rareItems.add(sponges);

        class_1799 iron_blocks = class_1802.field_8773.method_7854();
        iron_blocks.method_7939(16);
        rareItems.add(iron_blocks);

        int nextItem = this.field_5974.method_39332(0, rareItems.size() -1);
        class_1799 reward = rareItems.get(nextItem);

        if (reward.method_7909() == class_1802.field_8536) {
            this.method_5699(world, class_1802.field_8657.method_7854(), 0);
        }

        this.method_5699(world, reward, 0);
    }

    private void explosion(class_239 hitResult) {
        int kase = field_5974.method_43048(19);

        if (kase > 16 && this.method_24921() != null) {
            world.method_8437(this, this.method_24921().method_23317(), this.method_24921().method_23318(), this.method_24921().method_23321(),(float) 1.0, class_1937.class_7867.field_40889);
        }
        else {
            world.method_8437(this, this.method_23317(), this.method_23318(), this.method_23321(),(float) ((kase==0) ? 127.0 : 5.0), class_1937.class_7867.field_40889);
        }
    }

    private void fireExplosion(class_239 hitResult) {
        int kase = field_5974.method_43048(19);

        class_1674 fireballEntity;

//        if (kase == 20) {
//            if (this.getOwner() != null) {
//                fireballEntity = new FireballEntity(this.getEntityWorld(), (LivingEntity) this.getOwner(), new Vec3d(0, -1.0f, 0), 127);
//            }
//            else {
//                LivingEntity dummy = new PigEntity(EntityType.PIG, this.getEntityWorld());
//                dummy.setPosition(this.getX(), this.getY(), this.getZ());
//                fireballEntity = new FireballEntity(this.getEntityWorld(), dummy, new Vec3d(0, -1.0f, 0), 4);
//            }
//        }
//        else {
//            if (this.getOwner() != null) {
//                fireballEntity = new FireballEntity(this.getEntityWorld(), (LivingEntity) this.getOwner(), new Vec3d(0, -1.0f, 0), 3);
//            }
//            else {
//                LivingEntity dummy = new PigEntity(EntityType.PIG, this.getEntityWorld());
//                dummy.setPosition(this.getX(), this.getY(), this.getZ());
//                fireballEntity = new FireballEntity(this.getEntityWorld(), dummy, new Vec3d(0, -1.0f, 0), 4);
//            }
//        }
        if (this.method_24921() != null) {
            if (kase > 16) {
                fireballEntity = new class_1674(this.method_73183(), (class_1309) this.method_24921(), new class_243(0, -1.0f, 0), 1);
                fireballEntity.method_5814(this.method_24921().method_23317(), this.method_24921().method_23318()+2, this.method_24921().method_23321());
            }
            else {
                fireballEntity = new class_1674(this.method_73183(), (class_1309) this.method_24921(), new class_243(0, -1.0f, 0), 4);
                fireballEntity.method_5814(this.method_23317(), this.method_23318(), this.method_23321());
            }
            this.method_73183().method_8649(fireballEntity);
        }
    }

    private void spawn5ChaosOrbs(class_239 hitResult) {
        if (this.method_24921() != null) {
            class_1799 chaosOrbs = new class_1799(ModItems.CHAOS_ORB, 5);

            ChaosOrbEntity chaosOrbEntity = new ChaosOrbEntity(this.method_73183(), hitResult.method_17784().field_1352, hitResult.method_17784().field_1351, hitResult.method_17784().field_1350, chaosOrbs);
            chaosOrbEntity.method_7432(this.method_24921());
            chaosOrbEntity.method_7485( 1.0f, 2.0f, 0f, 0.5f, 0.0f);

            this.method_73183().method_8649(chaosOrbEntity);

            chaosOrbEntity = new ChaosOrbEntity(this.method_73183(), hitResult.method_17784().field_1352, hitResult.method_17784().field_1351, hitResult.method_17784().field_1350, chaosOrbs);
            chaosOrbEntity.method_7432(this.method_24921());
            chaosOrbEntity.method_7485( -1.0f, 2.0f, 0f, 0.5f, 0.0f);

            this.method_73183().method_8649(chaosOrbEntity);

            chaosOrbEntity = new ChaosOrbEntity(this.method_73183(), hitResult.method_17784().field_1352, hitResult.method_17784().field_1351, hitResult.method_17784().field_1350, chaosOrbs);
            chaosOrbEntity.method_7432(this.method_24921());
            chaosOrbEntity.method_7485( 0f, 2.0f, 1.0f, 0.5f, 0.0f);

            this.method_73183().method_8649(chaosOrbEntity);

            chaosOrbEntity = new ChaosOrbEntity(this.method_73183(), hitResult.method_17784().field_1352, hitResult.method_17784().field_1351, hitResult.method_17784().field_1350, chaosOrbs);
            chaosOrbEntity.method_7432(this.method_24921());
            chaosOrbEntity.method_7485( 0f, 2.0f, -1.0f, 0.5f, 0.0f);

            this.method_73183().method_8649(chaosOrbEntity);

            chaosOrbEntity = new ChaosOrbEntity(this.method_73183(), hitResult.method_17784().field_1352, hitResult.method_17784().field_1351, hitResult.method_17784().field_1350, chaosOrbs);
            chaosOrbEntity.method_7432(this.method_24921());
            chaosOrbEntity.method_7485( 0f, 2.0f, 0.0f, 0f, 0f);

            this.method_73183().method_8649(chaosOrbEntity);
        }
    }

    // Test TODO
    private void voidSphere(class_239 hitResult) {
        float randomNumber = field_5974.method_43057();
        while (randomNumber < 0.0000000001f) {
            randomNumber = field_5974.method_43057();
        }
        int radius = Math.max((int) (-1 * (5.6f * Math.log(randomNumber * 1369)/Math.log(1.375f) - 127)), 10);
        class_2338 center = new class_2338(new class_2382((int) hitResult.method_17784().field_1352, (int) hitResult.method_17784().field_1351, (int) hitResult.method_17784().field_1350));



        if (this.method_24921() != null) {
            TerrainManager.TERRAIN_MANAGER.addJob(new SingleBlockSphereJob(world, (class_1657) this.method_24921(), center, radius, class_2246.field_10124));

            class_238 boundingBox = this.method_5829();
            List<class_1309> entities = this.method_73183().method_18467(class_1309.class, boundingBox.method_1009(64.0, 64.0, 64.0));
            class_1293 slowFall = new class_1293(class_1294.field_5906, radius * 4, 0);

            for (class_1309 entity : entities) {
                if (entity instanceof class_1657 player) {
                    entity.method_6092(slowFall);
                }
            }
        }
    }
    // TODO
//    private void createSkyblock(HitResult hitResult) {
//
//        if (this.getServer() != null) {
//            List<ServerPlayerEntity> players = this.getServer().getPlayerManager().getPlayerList();
//
//            World world = this.getEntityWorld();
//
//            int tpX = random.nextInt(1) == 0 ? random.nextBetween(10000, 20000) : random.nextBetween(-20000, -10000);
//            int tpZ = random.nextInt(1) == 0 ? random.nextBetween(10000, 20000) : random.nextBetween(-20000, -10000);
//
//            for (ServerPlayerEntity playerEntity : players) {
//                if (playerEntity == null) {
//                    continue;
//                }
//                StatusEffectInstance slowFall = new StatusEffectInstance(StatusEffects.SLOW_FALLING, 600, 0);
//                playerEntity.addStatusEffect(slowFall);
//
//                ServerWorld dimension = (ServerWorld) world;
//                TeleportTarget teleportTarget = new TeleportTarget(dimension,
//                        new Vec3d(tpX,
//                                150,
//                                tpZ),
//                        new Vec3d(0, 0, 0),
//                        0,
//                        0,
//                        TeleportTarget.NO_OP);
//                playerEntity.teleportTo(teleportTarget);
//                BlockPos asd = new BlockPos((int) playerEntity.getX() - (int) playerEntity.getX() % 16 + 11, 66, (int) playerEntity.getZ() - (int) playerEntity.getZ() % 16 + 11);
//                playerEntity.setSpawnPoint(playerEntity.getEntityWorld().getRegistryKey(), asd, 0, true, false);
//            }
//
//            if (this.getOwner() != null) {
//                ChunkPos islandChunkPos = new ChunkPos(tpX >> 4, tpZ >> 4);
//
//                for (int x = -1 ; x < 2 ; x++) {
//                    for (int z = -1 ; z < 2 ; z++) {
//                        ChunkPos chunkPos = new ChunkPos(islandChunkPos.x + x, islandChunkPos.z + z);
//
//                        ServerChunkManager chunkManager = (ServerChunkManager) world.getChunkManager();
//                        WorldChunk chunk = world.getChunk(chunkPos.x, chunkPos.z);
//
//                        ChunkSection[] sections = chunk.getSectionArray();
//                        Registry<Biome> registry = world.getRegistryManager().get(RegistryKeys.BIOME);
//                        ReadableContainer<RegistryEntry<Biome>> readableContainer = new PalettedContainer<>(registry.getIndexedEntries(), registry.entryOf(BiomeKeys.SNOWY_TAIGA), PalettedContainer.PaletteProvider.BIOME);
//
//                        Box chunkBox = new Box(chunkPos.getStartX(), 0, chunkPos.getStartZ(), chunkPos.getEndX() + 1, world.getHeight(), chunkPos.getEndZ() + 1);
//                        for (Entity entity : world.getOtherEntities(this.getOwner(), chunkBox)) {
//                            entity.remove(Entity.RemovalReason.DISCARDED);
//                        }
//
//                        chunk.clear();
//                        for (int i = 0 ; i < sections.length ; i++) {
//                            ChunkSection empty = new ChunkSection(new PalettedContainer<>(Block.STATE_IDS, Blocks.AIR.getDefaultState(), PalettedContainer.PaletteProvider.BLOCK_STATE), readableContainer);
//                            sections[i] = empty;
//                        }
//
//                        chunk.setLightOn(false);
//                        ServerLightingProvider lighting = chunkManager.getLightingProvider();
//                        lighting.enqueue(chunkPos.x, chunkPos.z);
//                        chunk.setNeedsSaving(true);
//
//                        ChunkDataS2CPacket packet = new ChunkDataS2CPacket(chunk, chunkManager.getLightingProvider(), null, null);
//                        chunkManager.sendToNearbyPlayers(this.getOwner(), packet);
//                    }
//                }
//
//                ChunkPos chunkPos = new ChunkPos(islandChunkPos.x, islandChunkPos.z);
//                MinecraftServer server = world.getServer();
//                if (server != null) {
//                    StructureTemplateManager structureManager = world.getServer().getStructureTemplateManager();
//                    StructureTemplate template = structureManager.getTemplateOrBlank(Identifier.of(MoreMineralBlocks.MOD_ID, "skyblock_start"));
//
//                    StructurePlacementData settings = new StructurePlacementData()
//                            .setRotation(BlockRotation.NONE)
//                            .setMirror(BlockMirror.NONE)
//                            .setIgnoreEntities(false);
//
//
//                    template.place((ServerWorldAccess) world, chunkPos.getBlockPos(4, 63, 4), chunkPos.getBlockPos(4,63,4), settings, world.getRandom(), 50);
//                }
//                TerrainManager.TERRAIN_MANAGER.addJob(new SkyBlockJob(world, chunkPos, (PlayerEntity) this.getOwner()));
//
//                MoreMineralBlocks.getStateSaverAndLoader(this.getServer()).setSkyBlockHappened(true);
//            }
//        }
//    }

//    private void createStructure(HitResult hitResult) {
//        hitResult.getPos();
//    }

    private void getToolsSet(class_239 hitResult) {
        int material = field_5974.method_39332(0, 4);

        switch (material) {
            case 0:
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8406.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8876.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8091.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8647.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8167.method_7854(), 0);
                break;
            case 1:
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8062.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8776.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8528.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8387.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8431.method_7854(), 0);
                break;
            case 2:
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8475.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8699.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8371.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8403.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8609.method_7854(), 0);
                break;
            case 3:
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8825.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8322.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8845.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8335.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8303.method_7854(), 0);
                break;
            case 4:
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8556.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8250.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8802.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8377.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8527.method_7854(), 0);
                break;
        }
    }

    private void getArmorSet(class_239 hitResult) {
        int material = field_5974.method_39332(0, 4);

        switch (material) {
            case 0:
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8267.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_18138.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8577.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8570.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8370.method_7854(), 0);
                break;
            case 1:
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8743.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8578.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8523.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8396.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8660.method_7854(), 0);
                break;
            case 2:
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8862.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8560.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8678.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8416.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8753.method_7854(), 0);
                break;
            case 3:
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8805.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8807.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8058.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8348.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8285.method_7854(), 0);
                break;
            case 4:
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8283.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8873.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8218.method_7854(), 0);
                this.method_5699((class_3218) this.method_73183(), class_1802.field_8313.method_7854(), 0);
                break;
        }
    }

    private void fragile(class_239 hitResult, class_238 boundingBox) {
        List<class_1309> entities = this.method_73183().method_18467(class_1309.class, boundingBox.method_1009(4.0, 2.0, 4.0));
        world.method_65096(ModParticles.CHAOS_ORB_FRAGILE_PARTICLE,this.method_23317(), this.method_23318(), this.method_23321(), 1, 0.0, 1.0, 0.0, 1.0);

        for (class_1309 entity : entities) {
            class_1293 effect = new class_1293(ModEffects.FRAGILE, 6000, 0);
            if (entity != null) {
                entity.method_6092(effect);
            }
        }
    }

    private void counterBlinking(class_239 hitResult, class_238 boundingBox) {
        List<class_1309> entities = this.method_73183().method_18467(class_1309.class, boundingBox.method_1009(16.0, 8.0, 16.0));
        if (entities.isEmpty() && this.method_24921() != null) {
            entities.add((class_1309) this.method_24921());
        }

        world.method_65096(ModParticles.CHAOS_ORB_COUNTER_BLINK_PARTICLE,this.method_23317(), this.method_23318(), this.method_23321(), 1, 0.0, 1.0, 0.0, 1.0);

        for (class_1309 entity : entities) {
            class_1293 effect = new class_1293(ModEffects.COUNTER_BLINK, 9600, 0);
            if (entity != null) {
                entity.method_6092(effect);
            }
        }
    }

    private void blinking(class_239 hitResult, class_238 boundingBox) {
        List<class_1309> entities = this.method_73183().method_18467(class_1309.class, boundingBox.method_1009(8.0, 4.0, 8.0));
        if (entities.isEmpty() && this.method_24921() != null) {
            entities.add((class_1309) this.method_24921());
        }
        world.method_65096(ModParticles.CHAOS_ORB_BLINKING_PARTICLE,this.method_23317(), this.method_23318(), this.method_23321(), 1, 0.0, 1.0, 0.0, 1.0);

        for (class_1309 entity : entities) {
            class_1293 effect = new class_1293(ModEffects.BLINKING, 1200, 0);
            if (entity != null) {
                entity.method_6092(effect);
            }
        }
    }

//    private void adventureGamemode(HitResult hitResult, List<LivingEntity> entities) {
//        for (LivingEntity entity : entities) {
//            StatusEffectInstance effect = new StatusEffectInstance(ModEffects.TELEPORTIS_DODGE, 72000, 1);
//            entity.addStatusEffect(effect);
//        }
//    }

//    private void onanaHands(HitResult hitResult, List<LivingEntity> entities) {
//        for (LivingEntity entity : entities) {
//            StatusEffectInstance effect = new StatusEffectInstance(ModEffects.ONANA_HANDS, 72000, 0);
//            entity.addStatusEffect(effect);
//        }
//    }

//    private void getUnobtainableBlocks(HitResult hitResult) {
//        List<ItemStack> unobtainableBlocks = new ArrayList<>();
//
//        ItemStack light = Items.LIGHT.getDefaultStack();
//        light.setCount(32);
//        unobtainableBlocks.add(light);
//
//        ItemStack bedrock = Items.BEDROCK.getDefaultStack();
//        bedrock.setCount(64);
//        unobtainableBlocks.add(bedrock);
//
//        ItemStack reinforcedDeepslate = Items.REINFORCED_DEEPSLATE.getDefaultStack();
//        reinforcedDeepslate.setCount(64);
//        unobtainableBlocks.add(reinforcedDeepslate);
//
//        ItemStack endPortalFrame = Items.END_PORTAL_FRAME.getDefaultStack();
//        endPortalFrame.setCount(12);
//        unobtainableBlocks.add(endPortalFrame);
//
//        ItemStack buddingAmethyst = Items.BUDDING_AMETHYST.getDefaultStack();
//        buddingAmethyst.setCount(64);
//        unobtainableBlocks.add(buddingAmethyst);
//
//        ItemStack trialSpawner = Items.TRIAL_SPAWNER.getDefaultStack();
//        unobtainableBlocks.add(trialSpawner);
//
//        ItemStack spawner = Items.SPAWNER.getDefaultStack();
//        unobtainableBlocks.add(spawner);
//
//        int nextItem = this.random.nextBetween(0, (int) unobtainableBlocks.size()-1);
//        ItemStack reward = unobtainableBlocks.get(nextItem);
//
//        List<ItemStack> spawnEggs = ((ChaosOrbItem) (this.getDefaultItem())).getOrCreateSpawnEggList();
//
//        int nextEgg = this.random.nextBetween(0, (int) spawnEggs.size()-1);
//        unobtainableBlocks.add(spawnEggs.get(nextEgg));
//
//        if (reward.getItem() == Items.TRIAL_SPAWNER || reward.getItem() == Items.SPAWNER) {
//            ItemStack newEgg = spawnEggs.get(nextEgg);
//            newEgg.setCount(1);
//            this.dropStack(newEgg, 0);
//        }
//
//        this.dropStack(reward, 0);
//    }

    private void getMythicItem(class_239 hitResult) {
        List<class_1799> mythicItems = new ArrayList<>();

        class_1799 light = class_1802.field_30904.method_7854();
        light.method_7939(32);
        mythicItems.add(light);

        class_1799 bedrock = class_1802.field_8542.method_7854();
        bedrock.method_7939(64);
        mythicItems.add(bedrock);

        class_1799 reinforcedDeepslate = class_1802.field_38418.method_7854();
        reinforcedDeepslate.method_7939(64);
        mythicItems.add(reinforcedDeepslate);

        class_1799 endPortalFrame = class_1802.field_8827.method_7854();
        endPortalFrame.method_7939(12);
        mythicItems.add(endPortalFrame);

        class_1799 buddingAmethyst = class_1802.field_27065.method_7854();
        buddingAmethyst.method_7939(8);
        mythicItems.add(buddingAmethyst);

        class_1799 trialSpawner = class_1802.field_47314.method_7854();
        mythicItems.add(trialSpawner);

        class_1799 spawner = class_1802.field_8849.method_7854();
        mythicItems.add(spawner);

        List<class_1799> spawnEggs = ((ChaosOrbItem) (this.method_16942())).getOrCreateSpawnEggList();

        mythicItems.add(ModItems.LEGENDARY_PICKAXE.method_7854());
        mythicItems.add(ModItems.LEGENDARY_SHOVEL.method_7854());
        mythicItems.add(ModItems.LEGENDARY_AXE.method_7854());
        mythicItems.add(ModItems.LEGENDARY_HOE.method_7854());
        mythicItems.add(ModItems.LEGENDARY_SWORD.method_7854());
        mythicItems.add(ModItems.LEGENDARY_LONGSWORD.method_7854());
        mythicItems.add(ModItems.LEGENDARY_ROCKET.method_7854());
        mythicItems.add(ModItems.SURVIVAL_DEBUG_STICK.method_7854());
        mythicItems.add(ModItems.DIMENSION_POCKET.method_7854());
        mythicItems.add(ModItems.FLASH.method_7854());

        int nextItem = this.field_5974.method_39332(0, (int) mythicItems.size()-1);
        class_1799 reward = mythicItems.get(nextItem);

        int nextEgg = this.field_5974.method_39332(0, (int) spawnEggs.size()-1);
        mythicItems.add(spawnEggs.get(nextEgg));

        if (reward.method_7909() == class_1802.field_47314 || reward.method_7909() == class_1802.field_8849) {
            class_1799 newEgg = spawnEggs.get(nextEgg);
            newEgg.method_7939(1);
            this.method_5699((class_3218) this.method_73183(), newEgg, 0);
        }

        this.method_5699((class_3218) this.method_73183(), reward, 0);
    }

//    private void giveRole(HitResult hitResult) {
//        List<ItemStack> mythicItems = new ArrayList<>();
//
//        mythicItems.add(ModItems.LEGENDARY_PICKAXE.getDefaultStack());
//        mythicItems.add(ModItems.LEGENDARY_SHOVEL.getDefaultStack());
//        mythicItems.add(ModItems.LEGENDARY_AXE.getDefaultStack());
//        mythicItems.add(ModItems.LEGENDARY_HOE.getDefaultStack());
//        mythicItems.add(ModItems.LEGENDARY_SWORD.getDefaultStack());
//        mythicItems.add(ModItems.LEGENDARY_ROCKET.getDefaultStack());
//        mythicItems.add(ModItems.SURVIVAL_DEBUG_STICK.getDefaultStack());
//        mythicItems.add(ModItems.FLASH.getDefaultStack());
//
//        int nextItem = this.random.nextBetween(0, (int) mythicItems.size()-1);
//        ItemStack reward = mythicItems.get(nextItem);
//
//        this.dropStack(reward, 0);
//    }

    private void debugHelp(class_239 hitResult) {
        if (this.method_24921() != null && this.method_24921() instanceof class_1657 player) {
            player.method_7353(class_2561.method_30163("MobPack"), false);
            player.method_7353(class_2561.method_30163("MythicItem"), false);
            player.method_7353(class_2561.method_30163("SkeletonHorse"), false);
            player.method_7353(class_2561.method_30163("Progression"), false);
            player.method_7353(class_2561.method_30163("Armor"), false);
            player.method_7353(class_2561.method_30163("Tools"), false);
            player.method_7353(class_2561.method_30163("Chaos (5 chaos orbs)"), false);
            player.method_7353(class_2561.method_30163("TerrainSphere"), false);
            player.method_7353(class_2561.method_30163("Explosion"), false);
            player.method_7353(class_2561.method_30163("FireExplosion"), false);
            player.method_7353(class_2561.method_30163("Food"), false);
            player.method_7353(class_2561.method_30163("Book"), false);
            player.method_7353(class_2561.method_30163("Prize"), false);
            player.method_7353(class_2561.method_30163("Xp"), false);
            player.method_7353(class_2561.method_30163("Beacon"), false);
            player.method_7353(class_2561.method_30163("Range"), false);
            player.method_7353(class_2561.method_30163("Fragile"), false);
            player.method_7353(class_2561.method_30163("Storm"), false);
            player.method_7353(class_2561.method_30163("Teleport"), false);
            player.method_7353(class_2561.method_30163("CounterBlink"), false);
            player.method_7353(class_2561.method_30163("Blinking"), false);
            player.method_7353(class_2561.method_30163("20"), false);
            player.method_7353(class_2561.method_30163("Scale"), false);
            player.method_7353(class_2561.method_30163("Tunneler"), false);
        }
    }
}
