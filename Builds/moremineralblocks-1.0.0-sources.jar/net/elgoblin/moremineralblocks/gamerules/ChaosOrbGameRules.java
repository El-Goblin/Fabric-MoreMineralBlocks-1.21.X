package net.elgoblin.moremineralblocks.gamerules;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleBuilder;
import net.minecraft.class_12279;
import net.minecraft.class_2960;
import net.minecraft.class_5198;

public class ChaosOrbGameRules {

    public static final class_12279<Double> VOID_SPHERE_SIZE_MULTIPLIER = GameRuleBuilder
            .forDouble(1)
            .category(class_5198.field_24100)
            .buildAndRegister(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "void_sphere_size_multiplier"));

    public static final class_12279<Integer> VOID_SPHERE_FIXED_SIZE = GameRuleBuilder
            .forInteger(-1)
            .category(class_5198.field_24100)
            .buildAndRegister(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "void_sphere_fixed_size"));

    public static void init() {}
}
