package net.elgoblin.moremineralblocks;

import net.elgoblin.moremineralblocks.block.ModBlocks;
import net.elgoblin.moremineralblocks.block.entity.ModBlockEntities;
import net.elgoblin.moremineralblocks.client.InfiniteItemClientCache;
import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.effect.ModEffects;
import net.elgoblin.moremineralblocks.enchantment.ModEnchantmentEffects;
import net.elgoblin.moremineralblocks.entity.ModEntities;
//import net.elgoblin.moremineralblocks.entity.custom.DevilmonEntity;
//import net.elgoblin.moremineralblocks.entity.custom.MantisEntity;
import net.elgoblin.moremineralblocks.gamerules.ChaosOrbGameRules;
import net.elgoblin.moremineralblocks.item.ModItemGroups;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.elgoblin.moremineralblocks.item.ModToolMaterials;
import net.elgoblin.moremineralblocks.networking.*;
import net.elgoblin.moremineralblocks.particle.ModParticles;
import net.elgoblin.moremineralblocks.structure.MoreMineralBlocksStructure;
import net.elgoblin.moremineralblocks.structure.MoreMineralBlocksStructurePlacement;
import net.elgoblin.moremineralblocks.terrain.TerrainManager;
import net.elgoblin.moremineralblocks.util.ModLootTableModifiers;
import net.elgoblin.moremineralblocks.util.ModTags;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.ModificationPhase;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1282;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_1972;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_4019;
import net.minecraft.class_5455;
import net.minecraft.class_5712;
import net.minecraft.class_8109;
import net.minecraft.util.math.*;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MoreMineralBlocks implements ModInitializer{
	public static final String MOD_ID = "moremineralblocks";

	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
//	private static StateSaverAndLoader stateSaverAndLoader;

	@Override
	public void onInitialize() {

		ModDataComponentTypes.registerDataComponentTypes();
		ModItemGroups.registerItemGroups();

		PayloadTypeRegistry.playC2S().register(SwitchEnchantmentToggleSafeModePayload.ID, SwitchEnchantmentToggleSafeModePayload.CODEC);

		PayloadTypeRegistry.playC2S().register(DimensionalPocketDepositContentsQueryPayload.ID, DimensionalPocketDepositContentsQueryPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(DimensionalPocketDepositContentsResponsePayload.ID, DimensionalPocketDepositContentsResponsePayload.CODEC);
		PayloadTypeRegistry.playC2S().register(DimensionalPocketSelectColorPayload.ID, DimensionalPocketSelectColorPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(DimensionalPocketToggleSlotPayload.ID, DimensionalPocketToggleSlotPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(DimensionalPocketIntraGroupScrollPayload.ID, DimensionalPocketIntraGroupScrollPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(DimensionalPocketInterGroupScrollPayload.ID, DimensionalPocketInterGroupScrollPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(DimensionalPocketMiddleClickQueryPayload.ID, DimensionalPocketMiddleClickQueryPayload.CODEC);

		ServerPayloadReceivers.registerDimensionPocketGlobalReceivers();




		ModItems.registerModItems();
		ModBlocks.registerModBlocks();
		ModEffects.registerEffects();
		ModEntities.registerModEntities();
		ModLootTableModifiers.modifyLootTables();
		ModParticles.registerParticles();
		ModBlockEntities.registerBlockEntities();
		MoreMineralBlocksStructurePlacement.registerStructurePlacementTypes();
		MoreMineralBlocksStructure.registerStructureTypes();
		ModEnchantmentEffects.registerEnchantmentEffects();
		InfiniteItemClientCache.init();
		ChaosOrbGameRules.init();



		BiomeModifications.create(class_2960.method_60654("savanna_temp_change"))
				.add(ModificationPhase.REPLACEMENTS,
						BiomeSelectors.includeByKey(class_1972.field_9449),
						(biomeSelectionContext, biomeModificationContext) -> {

							biomeModificationContext.getWeather().setTemperature(0.5f);
							biomeModificationContext.getWeather().setDownfall(1f);

						}
				);

		BiomeModifications.create(class_2960.method_60654("savanna_temp_change"))
				.add(ModificationPhase.REPLACEMENTS,
						BiomeSelectors.includeByKey(class_1972.field_9430),
						(biomeSelectionContext, biomeModificationContext) -> {

							biomeModificationContext.getWeather().setTemperature(0.5f);
							biomeModificationContext.getWeather().setDownfall(1f);

						}
				);

		BiomeModifications.create(class_2960.method_60654("savanna_temp_change"))
				.add(ModificationPhase.REPLACEMENTS,
						BiomeSelectors.includeByKey(class_1972.field_35114),
						(biomeSelectionContext, biomeModificationContext) -> {

							biomeModificationContext.getWeather().setTemperature(0.5f);
							biomeModificationContext.getWeather().setDownfall(1f);

						}
				);


//
//		FabricDefaultAttributeRegistry.register(ModEntities.MANTIS, MantisEntity.createAttributes());
//		FabricDefaultAttributeRegistry.register(ModEntities.DEVILMON, DevilmonEntity.createAttributes());

		ServerPlayNetworking.registerGlobalReceiver(SwitchEnchantmentToggleSafeModePayload.ID,
				(payload, context) -> {
			    	context.server().execute(() -> {
						class_3222 player = context.player();
						class_1799 mainHandStack = player.method_6047();
						if (mainHandStack.method_31573(ModTags.Items.LEGENDARY_TOOLS)) {
							ModToolMaterials.advanceEnchantments(mainHandStack);
						}
						if (mainHandStack.method_31574(ModItems.DIMENSIONAL_POCKET)) {
							boolean currentSafeMode = mainHandStack.method_58695(ModDataComponentTypes.SAFE_MODE, false);
							mainHandStack.method_57379(ModDataComponentTypes.SAFE_MODE, !currentSafeMode);
						}
					});
				});

		ServerTickEvents.END_SERVER_TICK.register(minecraftServer -> {
			TerrainManager.TERRAIN_MANAGER.tick();
		});


		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
			if (entity.method_6059(ModEffects.FRAGILE) && !blocked) {
				class_5455 registryManager = entity.method_73183().method_30349();
				class_8109 sources = new class_8109(registryManager);
				class_1282 newSource = sources.method_48830();
				if (!entity.method_73183().method_8608() && source.method_48792() != newSource.method_48792()) {
					entity.method_64397((class_3218) entity.method_73183(),newSource, damageTaken*2);
				}
			}

//			if (entity.hasStatusEffect(ModEffects.ONANA_HANDS) && !blocked) {
//				if (entity instanceof PlayerEntity) {
//					((PlayerEntity) entity).getInventory().dropAll();
//				}
//			}

//			if (entity.hasStatusEffect(ModEffects.CUMULATIVE_DAMAGE_TAKEN) && !blocked) {
//				entity.sendMessage(Text.of("dsa"));
//
//				DynamicRegistryManager registryManager = entity.getWorld().getRegistryManager();
//				DamageSources sources = new DamageSources(registryManager);
//				DamageSource newSource = sources.generic();
//
//				entity.sendMessage(Text.of("asd"));
//				entity.sendMessage(Text.of(source.getType().toString()));
//				entity.sendMessage(Text.of(newSource.getType().toString()));
//
//				if (!entity.getWorld().isClient && source.getType() != newSource.getType()) {
//					entity.sendMessage(Text.of("sss"));
//
//					double cumulative_damage_taken = entity.getAttributeValue(ModEntityAttributes.CUMULATIVE_DAMAGE_TAKEN);
//
//					entity.sendMessage(Text.of(String.format("%f", cumulative_damage_taken)));
//
//					double newDamage = damageTaken + cumulative_damage_taken;
//
//					entity.sendMessage(Text.of("punto b"));
//
//					entity.damage(newSource, (float) (newDamage));
//					entity.getAttributeInstance(ModEntityAttributes.CUMULATIVE_DAMAGE_TAKEN).setBaseValue(cumulative_damage_taken+0.5);
//				}
//			}

			if (entity.method_6059(ModEffects.COUNTER_BLINK) && !blocked) {
				class_1937 world = entity.method_73183();
				if (!world.method_8608()) {
					for (int i = 0; i < 16; i++) {
						double d = entity.method_23317() + (entity.method_59922().method_43058() - 0.5) * 16.0;
						double e = class_3532.method_15350(
								entity.method_23318() + (entity.method_59922().method_43048(16) - 8), (double)world.method_31607(), (double)(world.method_31607() + ((class_3218)world).method_32819() - 1)
						);
						double f = entity.method_23321() + (entity.method_59922().method_43058() - 0.5) * 16.0;
						if (entity.method_5765()) {
							entity.method_5848();
						}

						class_243 vec3d = entity.method_73189();
						if (entity.method_6082(d, e, f, true)) {
							world.method_32888(class_5712.field_39446, vec3d, class_5712.class_7397.method_43285(entity));
							class_3419 soundCategory;
							class_3414 soundEvent;
							if (entity instanceof class_4019) {
								soundEvent = class_3417.field_24630;
								soundCategory = class_3419.field_15254;
							} else {
								soundEvent = class_3417.field_14890;
								soundCategory = class_3419.field_15248;
							}

							world.method_54762(null, entity.method_23317(), entity.method_23318(), entity.method_23321(), soundEvent, soundCategory);
							entity.method_38785();
							break;
						}
					}
				}
			}
		});

//		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
//			if (entity.hasStatusEffect(ModEffects.DOUBLE_DAMAGE_TAKEN) && !blocked) {
//				if (!entity.getWorld().isClient) {
//					entity.damage(source, damageTaken);
//				}
//			}
//
//		});

//		UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
//			ItemStack item = player.getStackInHand(hand);
//			List<Vec3i> possiblePositions = new ArrayList<>(List.of(
//					new Vec3i(1,0,0),
//					new Vec3i(0,1,0),
//					new Vec3i(0,0,1),
//					new Vec3i(-1,0,0),
//					new Vec3i(0,-1,0),
//					new Vec3i(0,0,-1)
//			));
//
//			ActionResult result = ActionResult.FAIL;
//
//			while (result != ActionResult.SUCCESS) {
//				Random random = Random.create();
//				Vec3i chosenPosition = possiblePositions.get(random.nextBetween(0,5));
//				BlockHitResult adjacentHitResult;
//
//				if (!world.isClient) {
//					adjacentHitResult = hitResult.withBlockPos(hitResult.getBlockPos().add(chosenPosition));
//				}
//				else {
//					adjacentHitResult = hitResult;
//				}
//
//				result = item.useOnBlock(new ItemPlacementContext(player, hand, item, adjacentHitResult));
//				if (result.isAccepted()) {
//					return ActionResult.SUCCESS;
//				}
//			}
//			return ActionResult.PASS;
//        });
	}


//	@Override
//	public void onWorldLoad(MinecraftServer minecraftServer, ServerWorld serverWorld) {
//		StateSaverAndLoader.loadSave(minecraftServer);
//	}
//
//	public static StateSaverAndLoader getStateSaverAndLoader(MinecraftServer minecraftServer) {
//		return StateSaverAndLoader.loadSave(minecraftServer);
//	}






}