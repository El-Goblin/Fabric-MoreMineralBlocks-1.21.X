package net.elgoblin.moremineralblocks;

import net.elgoblin.moremineralblocks.block.ModBlocks;
import net.elgoblin.moremineralblocks.block.entity.ModBlockEntities;
import net.elgoblin.moremineralblocks.client.InfiniteItemClientCache;
import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.effect.ModEffects;
import net.elgoblin.moremineralblocks.enchantment.ModEnchantmentEffects;
import net.elgoblin.moremineralblocks.entity.ModEntities;
//import net.elgoblin.moremineralblocks.entity.custom.DevilmonEntity;
//import net.elgoblin.moremineralblocks.entity.custom.MantisEntity;
import net.elgoblin.moremineralblocks.item.ModItemGroups;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.elgoblin.moremineralblocks.item.ModToolMaterials;
import net.elgoblin.moremineralblocks.networking.*;
import net.elgoblin.moremineralblocks.particle.ModParticles;
import net.elgoblin.moremineralblocks.structure.MoreMineralBlocksStructure;
import net.elgoblin.moremineralblocks.structure.MoreMineralBlocksStructurePlacement;
import net.elgoblin.moremineralblocks.terrain.TerrainManager;
import net.elgoblin.moremineralblocks.util.ModLootTableModifiers;
import net.elgoblin.moremineralblocks.util.ModTags;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.ModificationPhase;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1263;
import net.minecraft.class_1282;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_1972;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_4019;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5712;
import net.minecraft.class_7924;
import net.minecraft.class_8109;
import net.minecraft.class_9331;
import net.minecraft.util.math.*;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MoreMineralBlocks implements ModInitializer{
	public static final String MOD_ID = "moremineralblocks";

	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
//	private static StateSaverAndLoader stateSaverAndLoader;

	@Override
	public void onInitialize() {

		ModDataComponentTypes.registerDataComponentTypes();
		ModItemGroups.registerItemGroups();

		PayloadTypeRegistry.playC2S().register(SwitchEnchantmentToggleSafeModePayload.ID, SwitchEnchantmentToggleSafeModePayload.CODEC);

		PayloadTypeRegistry.playC2S().register(InfiniteItemstackV2ChestContentsQueryPayload.ID, InfiniteItemstackV2ChestContentsQueryPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(InfiniteItemstackV2ChestContentsResponsePayload.ID, InfiniteItemstackV2ChestContentsResponsePayload.CODEC);
		PayloadTypeRegistry.playC2S().register(InfiniteItemSelectColorPayload.ID, InfiniteItemSelectColorPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ToggleSlotPayload.ID, ToggleSlotPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(InfiniteItemStackIntraGroupScrollPayload.ID, InfiniteItemStackIntraGroupScrollPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(InfiniteItemStackInterGroupScrollPayload.ID, InfiniteItemStackInterGroupScrollPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(DimensionPocketMiddleClickQueryPayload.ID, DimensionPocketMiddleClickQueryPayload.CODEC);


		ModItems.registerModItems();
		ModBlocks.registerModBlocks();
		ModEffects.registerEffects();
		ModEntities.registerModEntities();
		ModLootTableModifiers.modifyLootTables();
		ModParticles.registerParticles();
		ModBlockEntities.registerBlockEntities();
		MoreMineralBlocksStructurePlacement.registerStructurePlacementTypes();
		MoreMineralBlocksStructure.registerStructureTypes();
		ModEnchantmentEffects.registerEnchantmentEffects();
		InfiniteItemClientCache.init();



		BiomeModifications.create(class_2960.method_60654("savanna_temp_change"))
				.add(ModificationPhase.REPLACEMENTS,
						BiomeSelectors.includeByKey(class_1972.field_9449),
						(biomeSelectionContext, biomeModificationContext) -> {

							biomeModificationContext.getWeather().setTemperature(0.5f);
							biomeModificationContext.getWeather().setDownfall(1f);

						}
				);

		BiomeModifications.create(class_2960.method_60654("savanna_temp_change"))
				.add(ModificationPhase.REPLACEMENTS,
						BiomeSelectors.includeByKey(class_1972.field_9430),
						(biomeSelectionContext, biomeModificationContext) -> {

							biomeModificationContext.getWeather().setTemperature(0.5f);
							biomeModificationContext.getWeather().setDownfall(1f);

						}
				);

		BiomeModifications.create(class_2960.method_60654("savanna_temp_change"))
				.add(ModificationPhase.REPLACEMENTS,
						BiomeSelectors.includeByKey(class_1972.field_35114),
						(biomeSelectionContext, biomeModificationContext) -> {

							biomeModificationContext.getWeather().setTemperature(0.5f);
							biomeModificationContext.getWeather().setDownfall(1f);

						}
				);


//
//		FabricDefaultAttributeRegistry.register(ModEntities.MANTIS, MantisEntity.createAttributes());
//		FabricDefaultAttributeRegistry.register(ModEntities.DEVILMON, DevilmonEntity.createAttributes());

		ServerPlayNetworking.registerGlobalReceiver(SwitchEnchantmentToggleSafeModePayload.ID,
				(payload, context) -> {
			    	context.server().execute(() -> {
						class_3222 player = context.player();
						class_1799 mainHandStack = player.method_6047();
						if (mainHandStack.method_31573(ModTags.Items.LEGENDARY_TOOLS)) {
							ModToolMaterials.advanceEnchantments(mainHandStack);
						}
						if (mainHandStack.method_31574(ModItems.DIMENSION_POCKET)) {
							boolean currentSafeMode = mainHandStack.method_58695(ModDataComponentTypes.SAFE_MODE, false);
							mainHandStack.method_57379(ModDataComponentTypes.SAFE_MODE, !currentSafeMode);
						}
					});
				});

		ServerPlayNetworking.registerGlobalReceiver(InfiniteItemstackV2ChestContentsQueryPayload.ID,
				(payload, context) -> {
					context.server().execute(() -> {
						class_1799 infiniteItem = payload.itemStack();

						if (!infiniteItem.method_31574(ModItems.DIMENSION_POCKET)) return;

						class_2338 storagePos = infiniteItem.method_58694(ModDataComponentTypes.LINKED_CHEST);
						class_2960 dimension = infiniteItem.method_58694(ModDataComponentTypes.SERVERWORLD);

						if (storagePos == null || dimension == null) {
							sendEmptyPayload(context);
							return;
						}

						class_3218 targetWorld = context.server().method_3847(class_5321.method_29179(class_7924.field_41223, dimension));
						if (targetWorld == null || !targetWorld.method_8477(storagePos)) {
							sendEmptyPayload(context);
							return;
						}

						if (!(targetWorld.method_8321(storagePos) instanceof class_1263 inventory)) {
							sendEmptyPayload(context);
							return;
						}

						class_2680 blockState = targetWorld.method_8320(storagePos);
						class_2248 inventoryBlock = blockState.method_26204();
						class_1263 deposit = null;

						if (inventoryBlock instanceof class_2281 chest) {
							deposit = class_2281.method_17458(chest, blockState, targetWorld, storagePos, true);
						}
						if (deposit == null && targetWorld.method_8321(storagePos) instanceof class_1263 otherInventory) {
							deposit = otherInventory;
						}



						Integer interGroupPointer = infiniteItem.method_58694(ModDataComponentTypes.INTER_GROUP_POINTER);
						List<Integer> intraGroupPointers = infiniteItem.method_58694(ModDataComponentTypes.INTRA_GROUP_POINTERS);

						if (interGroupPointer == null || intraGroupPointers == null) {
							sendEmptyPayload(context);
							return;
						}

						int currentGroup = interGroupPointer;
						int currentIntraIdx = intraGroupPointers.get(currentGroup);

						int prevGroup = findNextGroup(infiniteItem, currentGroup, -1);
						int nextGroup = findNextGroup(infiniteItem, currentGroup, 1);

						int prevGroupIntraIdx = intraGroupPointers.get(prevGroup);
						int nextGroupIntraIdx = intraGroupPointers.get(nextGroup);

						class_1799 mainStack = getStackFromGroup(infiniteItem, deposit, currentGroup, currentIntraIdx);

						int currentGroupPrevIndex = findNextItem(infiniteItem, deposit, currentGroup, currentIntraIdx, -1);
						int currentGroupNextIndex = findNextItem(infiniteItem, deposit, currentGroup, currentIntraIdx, 1);

						class_1799 prevHorizStack = getStackFromGroup(infiniteItem, deposit, currentGroup, currentGroupPrevIndex);
						class_1799 nextHorizStack = getStackFromGroup(infiniteItem, deposit, currentGroup, currentGroupNextIndex);

						class_1799 prevVertStack = getStackFromGroup(infiniteItem, deposit, prevGroup, prevGroupIntraIdx);
						class_1799 nextVertStack = getStackFromGroup(infiniteItem, deposit, nextGroup, nextGroupIntraIdx);

						context.responseSender().sendPacket(new InfiniteItemstackV2ChestContentsResponsePayload(
								mainStack,
								prevHorizStack,
								nextHorizStack,
								prevVertStack,
								nextVertStack
						));
					});
				});

		ServerPlayNetworking.registerGlobalReceiver(InfiniteItemStackIntraGroupScrollPayload.ID,
				(payload, context) -> {
					class_3222 player = context.player();
					class_1799 activeHand = class_1799.field_8037;
					if (player.method_6047().method_31574(ModItems.DIMENSION_POCKET)) {activeHand = player.method_6047();}
					else if (player.method_6079().method_31574(ModItems.DIMENSION_POCKET)) {activeHand = player.method_6079();}

					if (activeHand.method_7960()) {return;}

					class_2338 storagePosition = activeHand.method_58694(ModDataComponentTypes.LINKED_CHEST);
					class_2960 dimension = activeHand.method_58694(ModDataComponentTypes.SERVERWORLD);
					Integer interGroupPointer = activeHand.method_58694(ModDataComponentTypes.INTER_GROUP_POINTER);
					List<Integer> intraGroupPointers = activeHand.method_58694(ModDataComponentTypes.INTRA_GROUP_POINTERS);

					if (storagePosition == null || dimension == null || interGroupPointer == null || intraGroupPointers == null) {return;}

					class_3218 targetWorld = context.server().method_3847(class_5321.method_29179(class_7924.field_41223, dimension));
					if (targetWorld == null || !targetWorld.method_8477(storagePosition)) {return;}

					if (!(targetWorld.method_8321(storagePosition) instanceof class_1263 inventory)) {
						return;
					}

					class_2680 blockState = targetWorld.method_8320(storagePosition);
					class_2248 inventoryBlock = blockState.method_26204();
					class_1263 deposit = null;

					if (inventoryBlock instanceof class_2281 chest) {
						deposit = class_2281.method_17458(chest, blockState, targetWorld, storagePosition, true);
					}
					if (deposit == null && targetWorld.method_8321(storagePosition) instanceof class_1263 otherInventory) {
						deposit = otherInventory;
					}

					List<Integer> group = activeHand.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(interGroupPointer)));
					if (group == null) {return;}

					int oldPointer = intraGroupPointers.get(interGroupPointer);

					List<Integer> newIntraGroupPointers = new ArrayList<>(intraGroupPointers);

					int newPointer = newIntraGroupPointers.get(interGroupPointer) - payload.scroll();
					if (newPointer < 0) {newPointer = group.size()-1;}
					if (newPointer >= group.size()) {newPointer = 0;}

					while (!group.isEmpty() && deposit.method_5438(group.get(newPointer)).method_7960() && newPointer != oldPointer) {
						newPointer = newPointer - payload.scroll();
						if (newPointer < 0) {newPointer = group.size()-1;}
						if (newPointer >= group.size()) {newPointer = 0;}
					}
					newIntraGroupPointers.set(interGroupPointer, newPointer);
					activeHand.method_57379(ModDataComponentTypes.INTRA_GROUP_POINTERS, newIntraGroupPointers);
		        });

		ServerPlayNetworking.registerGlobalReceiver(InfiniteItemStackInterGroupScrollPayload.ID,
				(payload, context) -> {
					class_3222 player = context.player();
					class_1799 activeHand = class_1799.field_8037;
					if (player.method_6047().method_31574(ModItems.DIMENSION_POCKET)) {
						activeHand = player.method_6047();
					}
					else if (player.method_6079().method_31574(ModItems.DIMENSION_POCKET)) {
						activeHand = player.method_6079();
					}

					if (activeHand.method_7960()) {return;}

					class_2338 storagePosition = activeHand.method_58694(ModDataComponentTypes.LINKED_CHEST);
					class_2960 dimension = activeHand.method_58694(ModDataComponentTypes.SERVERWORLD);
					Integer interGroupPointer = activeHand.method_58694(ModDataComponentTypes.INTER_GROUP_POINTER);
					List<Integer> intraGroupPointers = activeHand.method_58694(ModDataComponentTypes.INTRA_GROUP_POINTERS);

					if (storagePosition == null || dimension == null || interGroupPointer == null || intraGroupPointers == null) {return;}

					class_3218 targetWorld = context.server().method_3847(class_5321.method_29179(class_7924.field_41223, dimension));
					if (targetWorld == null || !targetWorld.method_8477(storagePosition)) {return;}

					if (targetWorld.method_8321(storagePosition) instanceof class_1263 inventory) {

						int newInterGroupPointer = interGroupPointer + payload.scroll();
						if (newInterGroupPointer < 0) {newInterGroupPointer = 15;}
						if (newInterGroupPointer >= 16) {newInterGroupPointer = 0;}
						List<Integer> group = activeHand.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(newInterGroupPointer)));

						int newIntraGroupPointer = 0;
						if (group != null) {
							newIntraGroupPointer = isGroupEmpty(inventory, group);
						}

						while (group != null && newIntraGroupPointer == -1 && newInterGroupPointer != interGroupPointer) {
							newInterGroupPointer = newInterGroupPointer + payload.scroll();
							if (newInterGroupPointer < 0) {newInterGroupPointer = 15;}
							if (newInterGroupPointer >= 16) {newInterGroupPointer = 0;}
							group = activeHand.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(newInterGroupPointer)));
							if (group != null) {
								newIntraGroupPointer = isGroupEmpty(inventory, group);
							}
						}
						if (newInterGroupPointer == interGroupPointer) { // Di la vuelta, todos los grupos vacios
							newInterGroupPointer = 0;
							List<Integer> newIntraGroupPointers = new ArrayList<>(Collections.nCopies(16, 0));
							List<Integer> group0 = activeHand.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(0)));
							if (group0 != null && !group0.isEmpty()) {
								newIntraGroupPointers.set(0, intraGroupPointers.getFirst());
							}
							activeHand.method_57379(ModDataComponentTypes.INTRA_GROUP_POINTERS, newIntraGroupPointers);
							activeHand.method_57379(ModDataComponentTypes.INTER_GROUP_POINTER, newInterGroupPointer);
						}
						else {
							if (group != null) {
								activeHand.method_57379(ModDataComponentTypes.INTER_GROUP_POINTER, newInterGroupPointer);
								List<Integer> newIntraGroupPointers = new ArrayList<>(intraGroupPointers);
								newIntraGroupPointers.set(newInterGroupPointer, newIntraGroupPointer);
								activeHand.method_57379(ModDataComponentTypes.INTRA_GROUP_POINTERS, newIntraGroupPointers);
							}
						}
					}
				});

		ServerPlayNetworking.registerGlobalReceiver(InfiniteItemSelectColorPayload.ID, (payload, context) -> {
			context.server().execute(() -> {
				class_3222 player = context.player();
				class_1703 currentHandler = player.field_7512;

				if (currentHandler == null) {return;}

				int targetSlot = payload.slot();

				if (targetSlot >= 0 && targetSlot < currentHandler.field_7761.size()) {
					class_1799 stack = currentHandler.method_7611(targetSlot).method_7677();

					if (stack.method_31574(ModItems.DIMENSION_POCKET)) {
						stack.method_57379(ModDataComponentTypes.SELECTED_COLOR, payload.colorIndex());
					}
				}

			});
		});

		ServerPlayNetworking.registerGlobalReceiver(ToggleSlotPayload.ID, (payload, context) -> {
			context.server().execute(() -> {
				class_3222 player = context.player();
				class_1703 handler = player.field_7512;

				if (handler == null) return;

				class_1735 targetSlot = handler.method_7611(payload.targetSlotId());
				if (targetSlot == null || targetSlot.method_7677().method_7960()) {return;}
				class_1799 itemStack = targetSlot.method_7677();

				if (!itemStack.method_31574(ModItems.DIMENSION_POCKET)) {return;}

				class_1767 dyeColor = class_1767.method_7791(payload.colorIndex());
				class_9331<List<Integer>> colorComponent = ModDataComponentTypes.COLOR_INVENTORIES.get(dyeColor);

				if (colorComponent == null) {return;}

				List<Integer> existingSlots = itemStack.method_58695(colorComponent, List.of());
				List<Integer> updatedSlots = new ArrayList<>(existingSlots);

				int clickedSlotId = payload.clickedSlotId();

				if (updatedSlots.contains(clickedSlotId)) {
					updatedSlots.remove(Integer.valueOf(clickedSlotId));
				} else {
					updatedSlots.add(clickedSlotId);
				}
				itemStack.method_57379(colorComponent, updatedSlots);
				targetSlot.method_7668();
				handler.method_34252();

			});
		});

		ServerPlayNetworking.registerGlobalReceiver(DimensionPocketMiddleClickQueryPayload.ID,
				(payload, context) -> {
					context.server().execute(() -> {
						class_3222 player = context.player();
						class_1799 infiniteItem = player.method_6047();
						if (!infiniteItem.method_31574(ModItems.DIMENSION_POCKET)){
							infiniteItem = player.method_6079();
						}
						if (!infiniteItem.method_31574(ModItems.DIMENSION_POCKET)) {
							return;
						}

						if (!infiniteItem.method_31574(ModItems.DIMENSION_POCKET)) return;

						class_2338 storagePos = infiniteItem.method_58694(ModDataComponentTypes.LINKED_CHEST);
						class_2960 dimension = infiniteItem.method_58694(ModDataComponentTypes.SERVERWORLD);

						if (storagePos == null || dimension == null) {
							sendEmptyPayload(context);
							return;
						}

						class_3218 targetWorld = context.server().method_3847(class_5321.method_29179(class_7924.field_41223, dimension));
						if (targetWorld == null || !targetWorld.method_8477(storagePos)) {
							return;
						}

						if (!(targetWorld.method_8321(storagePos) instanceof class_1263 inventory)) {
							return;
						}

						class_2680 blockState = targetWorld.method_8320(storagePos);
						class_2248 inventoryBlock = blockState.method_26204();
						class_1263 deposit = null;

						if (inventoryBlock instanceof class_2281 chest) {
							deposit = class_2281.method_17458(chest, blockState, targetWorld, storagePos, true);
						}
						if (deposit == null && targetWorld.method_8321(storagePos) instanceof class_1263 otherInventory) {
							deposit = otherInventory;
						}
						if (deposit == null) {
							return;
						}

						Integer interGroupPointer = infiniteItem.method_58694(ModDataComponentTypes.INTER_GROUP_POINTER);
						List<Integer> intraGroupPointers = infiniteItem.method_58694(ModDataComponentTypes.INTRA_GROUP_POINTERS);

						if (interGroupPointer == null || intraGroupPointers == null) {
							return;
						}

						List<Integer> group = infiniteItem.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(interGroupPointer)));

						if (group == null) {
							return;
						}

						ArrayList<Integer> newIntraGroupPointers = new ArrayList<>(intraGroupPointers);

						// Esta en el grupo en el que estoy?
						for (int i = 0 ; i < group.size() ; i++) {
							if (deposit.method_5438(group.get(i)).method_7909() == payload.clicked().method_8389()) {
								newIntraGroupPointers.set(interGroupPointer, i);
								infiniteItem.method_57379(ModDataComponentTypes.INTRA_GROUP_POINTERS, newIntraGroupPointers);
								return;
							}
						}

						// Esta en algun grupo?
						int newInterGroupPointer = interGroupPointer;
						newInterGroupPointer++;
						if (newInterGroupPointer >= 16) {newInterGroupPointer = 0;}

						while (newInterGroupPointer != interGroupPointer) {
							group = infiniteItem.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(newInterGroupPointer)));

							if (group == null) {
								return;
							}

							// Esta en el grupo en el que estoy?
							for (int i = 0 ; i < group.size() ; i++) {
								if (deposit.method_5438(group.get(i)).method_7909() == payload.clicked().method_8389()) {
									newIntraGroupPointers.set(newInterGroupPointer, i);
									infiniteItem.method_57379(ModDataComponentTypes.INTER_GROUP_POINTER, newInterGroupPointer);
									infiniteItem.method_57379(ModDataComponentTypes.INTRA_GROUP_POINTERS, newIntraGroupPointers);
									return;
								}
							}

							newInterGroupPointer++;
							if (newInterGroupPointer >= 16) {newInterGroupPointer = 0;}
						}
					});
				});


		ServerTickEvents.END_SERVER_TICK.register(minecraftServer -> {
			TerrainManager.TERRAIN_MANAGER.tick();
		});


		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
			if (entity.method_6059(ModEffects.FRAGILE) && !blocked) {
				class_5455 registryManager = entity.method_73183().method_30349();
				class_8109 sources = new class_8109(registryManager);
				class_1282 newSource = sources.method_48830();
				if (!entity.method_73183().method_8608() && source.method_48792() != newSource.method_48792()) {
					entity.method_64397((class_3218) entity.method_73183(),newSource, damageTaken*2);
				}
			}

//			if (entity.hasStatusEffect(ModEffects.ONANA_HANDS) && !blocked) {
//				if (entity instanceof PlayerEntity) {
//					((PlayerEntity) entity).getInventory().dropAll();
//				}
//			}

//			if (entity.hasStatusEffect(ModEffects.CUMULATIVE_DAMAGE_TAKEN) && !blocked) {
//				entity.sendMessage(Text.of("dsa"));
//
//				DynamicRegistryManager registryManager = entity.getWorld().getRegistryManager();
//				DamageSources sources = new DamageSources(registryManager);
//				DamageSource newSource = sources.generic();
//
//				entity.sendMessage(Text.of("asd"));
//				entity.sendMessage(Text.of(source.getType().toString()));
//				entity.sendMessage(Text.of(newSource.getType().toString()));
//
//				if (!entity.getWorld().isClient && source.getType() != newSource.getType()) {
//					entity.sendMessage(Text.of("sss"));
//
//					double cumulative_damage_taken = entity.getAttributeValue(ModEntityAttributes.CUMULATIVE_DAMAGE_TAKEN);
//
//					entity.sendMessage(Text.of(String.format("%f", cumulative_damage_taken)));
//
//					double newDamage = damageTaken + cumulative_damage_taken;
//
//					entity.sendMessage(Text.of("punto b"));
//
//					entity.damage(newSource, (float) (newDamage));
//					entity.getAttributeInstance(ModEntityAttributes.CUMULATIVE_DAMAGE_TAKEN).setBaseValue(cumulative_damage_taken+0.5);
//				}
//			}

			if (entity.method_6059(ModEffects.COUNTER_BLINK) && !blocked) {
				class_1937 world = entity.method_73183();
				if (!world.method_8608()) {
					for (int i = 0; i < 16; i++) {
						double d = entity.method_23317() + (entity.method_59922().method_43058() - 0.5) * 16.0;
						double e = class_3532.method_15350(
								entity.method_23318() + (entity.method_59922().method_43048(16) - 8), (double)world.method_31607(), (double)(world.method_31607() + ((class_3218)world).method_32819() - 1)
						);
						double f = entity.method_23321() + (entity.method_59922().method_43058() - 0.5) * 16.0;
						if (entity.method_5765()) {
							entity.method_5848();
						}

						class_243 vec3d = entity.method_73189();
						if (entity.method_6082(d, e, f, true)) {
							world.method_32888(class_5712.field_39446, vec3d, class_5712.class_7397.method_43285(entity));
							class_3419 soundCategory;
							class_3414 soundEvent;
							if (entity instanceof class_4019) {
								soundEvent = class_3417.field_24630;
								soundCategory = class_3419.field_15254;
							} else {
								soundEvent = class_3417.field_14890;
								soundCategory = class_3419.field_15248;
							}

							world.method_54762(null, entity.method_23317(), entity.method_23318(), entity.method_23321(), soundEvent, soundCategory);
							entity.method_38785();
							break;
						}
					}
				}
			}
		});

//		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
//			if (entity.hasStatusEffect(ModEffects.DOUBLE_DAMAGE_TAKEN) && !blocked) {
//				if (!entity.getWorld().isClient) {
//					entity.damage(source, damageTaken);
//				}
//			}
//
//		});

//		UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
//			ItemStack item = player.getStackInHand(hand);
//			List<Vec3i> possiblePositions = new ArrayList<>(List.of(
//					new Vec3i(1,0,0),
//					new Vec3i(0,1,0),
//					new Vec3i(0,0,1),
//					new Vec3i(-1,0,0),
//					new Vec3i(0,-1,0),
//					new Vec3i(0,0,-1)
//			));
//
//			ActionResult result = ActionResult.FAIL;
//
//			while (result != ActionResult.SUCCESS) {
//				Random random = Random.create();
//				Vec3i chosenPosition = possiblePositions.get(random.nextBetween(0,5));
//				BlockHitResult adjacentHitResult;
//
//				if (!world.isClient) {
//					adjacentHitResult = hitResult.withBlockPos(hitResult.getBlockPos().add(chosenPosition));
//				}
//				else {
//					adjacentHitResult = hitResult;
//				}
//
//				result = item.useOnBlock(new ItemPlacementContext(player, hand, item, adjacentHitResult));
//				if (result.isAccepted()) {
//					return ActionResult.SUCCESS;
//				}
//			}
//			return ActionResult.PASS;
//        });
	}
	private int isGroupEmpty(class_1263 inventory, List<Integer> group) {
		for (int i = 0 ; i < group.size() ; i++) {
			if (!inventory.method_5438(group.get(i)).method_7960()) {
				return i; // El grupo no esta vacio y su slot i contiene algo
			}
		}
		return -1; // Ninguno de los slots del grupo contiene algo
	}

//	@Override
//	public void onWorldLoad(MinecraftServer minecraftServer, ServerWorld serverWorld) {
//		StateSaverAndLoader.loadSave(minecraftServer);
//	}
//
//	public static StateSaverAndLoader getStateSaverAndLoader(MinecraftServer minecraftServer) {
//		return StateSaverAndLoader.loadSave(minecraftServer);
//	}

	private static void sendEmptyPayload(ServerPlayNetworking.Context context) {
		context.responseSender().sendPacket(new InfiniteItemstackV2ChestContentsResponsePayload(
				class_1799.field_8037, class_1799.field_8037, class_1799.field_8037, class_1799.field_8037, class_1799.field_8037
		));
	}

	private static class_1799 getStackFromGroup(class_1799 infiniteItem, class_1263 inventory, int groupIndex, int intraIndex) {
		List<Integer> group = infiniteItem.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(groupIndex)));
		if (group == null || group.isEmpty()) {
			return class_1799.field_8037;
		}

		int newIndex = intraIndex;
		if (intraIndex >= group.size()) {newIndex = 0;}
		if (intraIndex < 0) {newIndex = group.size()-1;}
		int targetInventorySlot = group.get(newIndex);

		return inventory.method_5438(targetInventorySlot).method_7972();
	}

	private static int findNextItem(class_1799 infiniteItemstack, class_1263 inventory, int currentGroup, int intraGroupPointer, int direction) {
		List<Integer> group = infiniteItemstack.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(currentGroup)));
		if (group == null) {
			return 0;
		}
		int groupSize = group.size();

		int newPointer = intraGroupPointer + direction;
		if (newPointer >= groupSize) {newPointer = 0;}
		if (newPointer < 0) {newPointer = groupSize-1;}
		while (newPointer != intraGroupPointer && inventory.method_5438(group.get(newPointer)).method_7960()) {
			newPointer = newPointer + direction;
			if (newPointer >= groupSize) {newPointer = 0;}
			if (newPointer < 0) {newPointer = groupSize-1;}
		}
		return newPointer;
	}

	private static int findNextGroup(class_1799 infiniteItemstack, int currentGroup, int direction) {
		int newGroup = currentGroup + direction;
		if (newGroup >= 16) newGroup = 0;
		if (newGroup < 0) newGroup = 15;

		List<Integer> group = infiniteItemstack.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(newGroup)));
		while (group != null && group.isEmpty() && newGroup != currentGroup) {
			newGroup = newGroup + direction;
			if (newGroup >= 16) newGroup = 0;
			if (newGroup < 0) newGroup = 15;
			group = infiniteItemstack.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(newGroup)));
		}
		return newGroup;
	}
}