package net.elgoblin.moremineralblocks.item.custom;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_243;

public class FlashItem extends class_1792 {
    public FlashItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (!world.method_8608()) {

            class_243 previousVelocity = user.method_18798();
            float previousPitch = user.method_36455();
            float previousYaw = user.method_36454();
            float previousBodyYaw = user.method_73188();
            float previousHeadYaw = user.method_5791();

            user.method_7357().method_62835(user.method_5998(hand), 50);

            class_243 target = user.method_73189().method_1019(user.method_5828(1.0F).method_1021(8));
            user.method_5859(target.field_1352, target.field_1351, target.field_1350);

            user.method_18799(previousVelocity);
            user.method_36457(previousPitch);
            user.method_36456(previousYaw);
            user.method_5636(previousBodyYaw);
            user.method_5847(previousHeadYaw);

            user.field_64356 = true;

            user.field_6017 = 0;
        }
        return super.method_7836(world, user, hand);
    }
}
