package net.elgoblin.moremineralblocks.item.custom;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3965;
import org.jspecify.annotations.Nullable;

import java.util.Optional;
import java.util.function.Consumer;

public class InfiniteItemV2 extends class_1792 {

    public InfiniteItemV2(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_2338 position = context.method_8037();
        if (!context.method_8045().method_8608()) {
            if (context.method_8045().method_8321(position) instanceof class_1263 inventory) {
                context.method_8041().method_57379(ModDataComponentTypes.LINKED_CHEST, position);
                context.method_8041().method_57379(ModDataComponentTypes.SERVERWORLD, context.method_8045().method_27983().method_29177());
                if (context.method_8036() != null) {
                    context.method_8036().method_7353(class_2561.method_30163(position.toString()), false);
                }
            }
        }
        if (context.method_8045().method_8321(position) instanceof class_1263 inventory) {
            return class_1269.field_5812;
        }

        class_1657 user = context.method_8036();
        class_1937 world = context.method_8045();

        class_1799 stack = user.method_6047();
        class_2338 storagePos = stack.method_58694(ModDataComponentTypes.LINKED_CHEST);
        class_1263 inventory = (class_1263) world.method_8321(storagePos);
        class_1799 usedStack = inventory.method_5438(0);

        class_3965 hitResult = new class_3965(context.method_17698(), context.method_8038(), context.method_8037(), false);
        class_1838 newContext = new class_1838(context.method_8045(), context.method_8036(), context.method_20287(), usedStack, hitResult);
        class_1269 result = usedStack.method_7981(newContext);

        return class_1269.field_5814;
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_6047();
        class_1799 copy = stack.method_7972();
        class_2338 storagePos = stack.method_58694(ModDataComponentTypes.LINKED_CHEST);
        class_1263 inventory = (class_1263) world.method_8321(storagePos);
        class_1799 usedStack = inventory.method_5438(0);

        class_1269 result = usedStack.method_7913(world, user, hand);

        if (usedStack.method_7946() && result.method_23665()) {
            usedStack.method_57008(1, user);
        }

        user.method_5673(hand.method_73186(), copy);

        return class_1269.field_5814;
    }
}
