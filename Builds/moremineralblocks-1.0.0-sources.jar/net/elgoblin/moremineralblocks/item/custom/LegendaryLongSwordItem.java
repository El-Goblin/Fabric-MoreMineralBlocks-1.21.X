package net.elgoblin.moremineralblocks.item.custom;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.minecraft.class_1263;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_9334;
import net.minecraft.class_9424;
import net.minecraft.class_9886;

public class LegendaryLongSwordItem extends LongSwordItem {
    public LegendaryLongSwordItem(class_1793 settings, class_9886 material, float attackDamage, float attackSpeed, float entityInteractionRange, float sweepingDamage) {
        super(settings, material, attackDamage, attackSpeed, entityInteractionRange, sweepingDamage);
    }

    // Con esto hago que no pierda durabilidad al atacar cosas
    @Override
    public void method_59978(class_1799 stack, class_1309 target, class_1309 attacker) {
    }

    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        class_9424 toolComponent = stack.method_58694(class_9334.field_50077);
        return toolComponent != null;
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_2338 position = context.method_8037();
        if (!context.method_8045().method_8608()) {
            if (context.method_8045().method_8321(position) instanceof class_1263 inventory) {
                context.method_8041().method_57379(ModDataComponentTypes.LINKED_CHEST, position);
                if (context.method_8036() != null) {
                    context.method_8036().method_7353(class_2561.method_30163(position.toString()), false);
                }
            }
        }
        if (context.method_8045().method_8321(position) instanceof class_1263 inventory) {
            return class_1269.field_5812;
        }
        return super.method_7884(context);
    }
}
