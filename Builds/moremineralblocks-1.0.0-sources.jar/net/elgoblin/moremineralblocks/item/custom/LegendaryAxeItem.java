package net.elgoblin.moremineralblocks.item.custom;

import com.google.common.collect.BiMap;
import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.minecraft.block.*;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5712;
import net.minecraft.class_5953;
import net.minecraft.class_5955;
import net.minecraft.class_6088;
import net.minecraft.class_9334;
import net.minecraft.class_9424;
import net.minecraft.class_9886;
import net.minecraft.item.*;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class LegendaryAxeItem extends class_1743 {
    public LegendaryAxeItem(class_9886 material, float attackDamage, float attackSpeed, class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

//    // Con esto hago que no pierda durabilidad al atacar cosas
//    @Override
//    public void postDamageEntity(ItemStack stack, LivingEntity target, LivingEntity attacker) {
//        stack.setDamage(0);
////        super.postDamageEntity(stack, target, attacker);
//    }

    protected static boolean method_59967(class_1838 context) {
        class_1657 playerEntity = context.method_8036();
        return context.method_20287().equals(class_1268.field_5808) && playerEntity.method_6079().method_31574(class_1802.field_8255) && !playerEntity.method_21823();
    }

    protected Optional<class_2680> method_34716(class_2680 state) {
        return Optional.ofNullable((class_2248)field_7898.get(state.method_26204()))
                .map(block -> block.method_9564().method_11657(class_2465.field_11459, (class_2350.class_2351)state.method_11654(class_2465.field_11459)));
    }

    protected Optional<class_2680> method_54760(class_1937 world, class_2338 pos, @Nullable class_1657 player, class_2680 state) {
        Optional<class_2680> optional = this.method_34716(state);
        if (optional.isPresent()) {
            world.method_8396(player, pos, class_3417.field_14675, class_3419.field_15245, 1.0F, 1.0F);
            return optional;
        } else {
            Optional<class_2680> optional2 = class_5955.method_34735(state);
            if (optional2.isPresent()) {
                world.method_8396(player, pos, class_3417.field_29541, class_3419.field_15245, 1.0F, 1.0F);
                world.method_8444(player, class_6088.field_31158, pos, 0);
                return optional2;
            } else {
                Optional<class_2680> optional3 = Optional.ofNullable((class_2248)((BiMap)class_5953.field_29561.get()).get(state.method_26204()))
                        .map(block -> block.method_34725(state));
                if (optional3.isPresent()) {
                    world.method_8396(player, pos, class_3417.field_29542, class_3419.field_15245, 1.0F, 1.0F);
                    world.method_8444(player, class_6088.field_31157, pos, 0);
                    return optional3;
                } else {
                    return Optional.empty();
                }
            }
        }
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 blockPos = context.method_8037();
        class_1657 playerEntity = context.method_8036();

        class_2338 position = context.method_8037();
        if (!context.method_8045().method_8608()) {
            if (context.method_8045().method_8321(position) instanceof class_1263 inventory) {
                context.method_8041().method_57379(ModDataComponentTypes.LINKED_CHEST, position);
                if (context.method_8036() != null) {
                    context.method_8036().method_7353(class_2561.method_30163(position.toString()), false);
                }
            }
        }
        if (context.method_8045().method_8321(position) instanceof class_1263 inventory) {
            return class_1269.field_5812;
        }

        if (method_59967(context)) {
            return class_1269.field_5811;
        } else {
            Optional<class_2680> optional = this.method_54760(world, blockPos, playerEntity, world.method_8320(blockPos));
            if (optional.isEmpty()) {
                return class_1269.field_5811;
            } else {
                class_1799 itemStack = context.method_8041();
                if (playerEntity instanceof class_3222) {
                    class_174.field_24478.method_23889((class_3222)playerEntity, blockPos, itemStack);
                }

                world.method_8652(blockPos, (class_2680)optional.get(), class_2248.field_31022);
                world.method_43276(class_5712.field_28733, blockPos, class_5712.class_7397.method_43286(playerEntity, (class_2680)optional.get()));

                return class_1269.field_5812;
            }
        }
    }

    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        class_9424 toolComponent = stack.method_58694(class_9334.field_50077);
        return toolComponent != null;
    }

//    @Override
//    public void postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
//        stack.setDamage(0);
////        super.postHit(stack, target, attacker);
//    }
}
