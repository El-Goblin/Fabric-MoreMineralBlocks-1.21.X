package net.elgoblin.moremineralblocks.item.custom;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_5454;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;

public class MirrorItem extends class_1792 {

    public MirrorItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {

        class_1799 itemStack = user.method_5998(hand);

        if (!world.method_8608()) {
            MinecraftServer server = world.method_8503();

            if (server != null) {

                class_2960 world_ID = itemStack.method_58694(ModDataComponentTypes.SERVERWORLD);
                class_5321<class_1937> worldKey = class_5321.method_29179(class_7924.field_41223, world_ID);

                class_3218 targetWorld = world.method_8503().method_3847(worldKey);

                class_243 coordinates = itemStack.method_58694(ModDataComponentTypes.COORDINATES);

                if (coordinates != null) {
                    class_5454 teleportTarget = new class_5454(targetWorld,
                            coordinates,
                            new class_243(0, 0, 0),
                            user.method_36454(),
                            user.method_36455(),
                            class_5454.field_52245);
                    user.method_5731(teleportTarget);
                }
            }
        }
        itemStack.method_57008(1, user);
        return super.method_7836(world, user, hand);
    }
}
