package net.elgoblin.moremineralblocks.item.custom;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.minecraft.class_1263;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1821;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3922;
import net.minecraft.class_5712;
import net.minecraft.class_6088;
import net.minecraft.class_9334;
import net.minecraft.class_9424;
import net.minecraft.class_9886;
import net.minecraft.item.*;

public class LegendaryShovelItem extends class_1821 {
    public LegendaryShovelItem(class_9886 material, float attackDamage, float attackSpeed, class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    // Con esto hago que no pierda durabilidad al atacar cosas
    @Override
    public void method_59978(class_1799 stack, class_1309 target, class_1309 attacker) {
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 position = context.method_8037();
        class_2680 blockState = world.method_8320(position);

        if (!context.method_8045().method_8608()) {
            if (context.method_8045().method_8321(position) instanceof class_1263 inventory) {
                context.method_8041().method_57379(ModDataComponentTypes.LINKED_CHEST, position);
                context.method_8041().method_57379(ModDataComponentTypes.SERVERWORLD, context.method_8045().method_27983().method_29177());
                if (context.method_8036() != null) {
                    context.method_8036().method_7353(class_2561.method_30163("Linked successfully at position (x=" + position.method_10263() + ", y=" + position.method_10264() + ", z=" + position.method_10260() +")"), false);
                }
            }
        }
        if (context.method_8045().method_8321(position) instanceof class_1263 inventory) {
            return class_1269.field_5812;
        }

        if (context.method_8038() == class_2350.field_11033) {
            return class_1269.field_5811;
        } else {
            class_1657 playerEntity = context.method_8036();
            class_2680 blockState2 = (class_2680)field_8912.get(blockState.method_26204());
            class_2680 blockState3 = null;
            if (blockState2 != null && world.method_8320(position.method_10084()).method_26215()) {
                world.method_8396(playerEntity, position, class_3417.field_14616, class_3419.field_15245, 1.0F, 1.0F);
                blockState3 = blockState2;
            } else if (blockState.method_26204() instanceof class_3922 && (Boolean)blockState.method_11654(class_3922.field_17352)) {
                if (!world.method_8608()) {
                    world.method_8444(null, class_6088.field_31167, position, 0);
                }

                class_3922.method_29288(context.method_8036(), world, position, blockState);
                blockState3 = blockState.method_11657(class_3922.field_17352, false);
            }

            if (blockState3 != null) {
                if (!world.method_8608()) {
                    world.method_8652(position, blockState3, class_2248.field_31022);
                    world.method_43276(class_5712.field_28733, position, class_5712.class_7397.method_43286(playerEntity, blockState3));
                }

                return class_1269.field_5812;
            } else {
                return class_1269.field_5811;
            }
        }
    }

    // Al overridear esto y sacarle la parte de
    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        class_9424 toolComponent = stack.method_58694(class_9334.field_50077);
        return toolComponent != null;
    }
}
