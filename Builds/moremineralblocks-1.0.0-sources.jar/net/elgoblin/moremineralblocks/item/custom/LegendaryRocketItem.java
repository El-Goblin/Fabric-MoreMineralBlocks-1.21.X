package net.elgoblin.moremineralblocks.item.custom;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1671;
import net.minecraft.class_1781;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_3468;

public class LegendaryRocketItem extends class_1781 {
    public LegendaryRocketItem(class_1792.class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (user.method_6128()) {
            class_1799 itemStack = user.method_5998(hand);
            if (!world.method_8608()) {
                class_1671 fireworkRocketEntity = new class_1671(world, itemStack, user);
                world.method_8649(fireworkRocketEntity);
                user.method_7259(class_3468.field_15372.method_14956(this));
            }

            return class_1269.field_5812;
        } else {
            return class_1269.field_5811;
        }
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        return class_1269.field_5811;
    }
}
