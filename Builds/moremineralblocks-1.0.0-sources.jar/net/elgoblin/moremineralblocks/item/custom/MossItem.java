package net.elgoblin.moremineralblocks.item.custom;

import com.google.common.collect.BiMap;
import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5712;
import net.minecraft.item.*;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Optional;

public class MossItem extends class_1792 {
    public MossItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();

        if (!world.method_8608()) {
            class_2338 position = context.method_8037();
            class_2680 state = world.method_8320(position);
            class_2248 block = state.method_26204();
            class_2248 mossy = mossyBlocks.get(block);

            if (mossy != null) {
                world.method_8501(position, mossy.method_34725(state));

                world.method_8396(
                        null,
                        position,
                        class_3417.field_33433,
                        class_3419.field_15245,
                        1.0F,
                        1.0F
                );

                world.method_33596(context.method_8036(), class_5712.field_28733, position);

                context.method_8041().method_57008(1, context.method_8036());

                return class_1269.field_52422;
            }
        }
        return class_1269.field_5811;
    }

    private static final Map<class_2248, class_2248> mossyBlocks = Map.of(
            class_2246.field_10445, class_2246.field_9989,
            class_2246.field_10351, class_2246.field_10405,
            class_2246.field_10596, class_2246.field_10207,
            class_2246.field_10625, class_2246.field_9990,
            class_2246.field_10056, class_2246.field_10065,
            class_2246.field_10131, class_2246.field_10024,
            class_2246.field_10392, class_2246.field_10173,
            class_2246.field_10252, class_2246.field_10059,
            class_2246.field_10387, class_2246.field_10480
    );
}
