package net.elgoblin.moremineralblocks.item.custom;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5454;
import net.minecraft.class_5819;
import net.minecraft.server.MinecraftServer;
import java.util.List;

public class ChaosMirrorItem extends class_1792 {

    private final class_5819 random = class_5819.method_43047();

    public ChaosMirrorItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {

        class_1799 itemStack = user.method_5998(hand);

        if (!world.method_8608()) {
            MinecraftServer server = world.method_8503();

            if (server != null) {
                class_243 newCoordinates = new class_243(random.method_39332(-29999980, 29999980),
                        user.method_23318(),
                        random.method_39332(-29999980, 29999980));

                List<class_3222> players = server.method_3760().method_14571();

                for (class_3222 playerEntity : players) {
                    if (playerEntity == null) {
                        continue;
                    }

                    if (playerEntity.method_51469().method_8503() != null) {
                        class_3218 dimension = playerEntity.method_51469().method_8503().method_3847(playerEntity.method_51469().method_27983());

                        if (dimension != null) {
                            class_2960 world_ID = dimension.method_27983().method_29177();

                            class_243 currentCoordinates = playerEntity.method_73189();
                            class_1799 magicMirror = ModItems.REFLECTIVE_MIRROR.method_7854();
                            magicMirror.method_57379(ModDataComponentTypes.COORDINATES, currentCoordinates);
                            magicMirror.method_57379(ModDataComponentTypes.SERVERWORLD, world_ID);

                            class_5454 teleportTarget = new class_5454((class_3218) world,
                                    newCoordinates,
                                    new class_243(0, 0, 0),
                                    playerEntity.method_36454(),
                                    playerEntity.method_36455(),
                                    class_5454.field_52245);
                            playerEntity.method_61275(teleportTarget);
                            playerEntity.method_7270(magicMirror);
                        }
                    }
                }
            }
        }
        itemStack.method_57008(1, user);
        return super.method_7836(world, user, hand);
    }
}
