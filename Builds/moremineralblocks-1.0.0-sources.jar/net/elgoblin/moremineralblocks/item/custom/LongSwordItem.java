package net.elgoblin.moremineralblocks.item.custom;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5134;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.class_9886;
import net.minecraft.entity.attribute.*;
import org.jetbrains.annotations.Nullable;

public class LongSwordItem extends class_1792 {

    public LongSwordItem(class_1793 settings, class_9886 material, float attackDamage, float attackSpeed, float entityInteractionRange, float sweepingDamage) {
        super(settings.method_66333(material, attackDamage, attackSpeed).method_57348(createAttributeModifiers(attackDamage, attackSpeed, entityInteractionRange, sweepingDamage)));
    }

    public static class_9285 createAttributeModifiers(float attackDamage, float attackSpeed, float interactionRange, float sweepingDamage) {
        return class_9285.method_57480()
                .method_57487(
                        class_5134.field_23721,
                        new class_1322(class_2960.method_60654(MoreMineralBlocks.MOD_ID), attackDamage, class_1322.class_1323.field_6328),
                        class_9274.field_49217
                )
                .method_57487(
                        class_5134.field_23723,
                        new class_1322(class_2960.method_60654(MoreMineralBlocks.MOD_ID), attackSpeed, class_1322.class_1323.field_6328),
                        class_9274.field_49217
                )
                .method_57487(
                        class_5134.field_47759,
                        new class_1322(class_2960.method_60654(MoreMineralBlocks.MOD_ID), interactionRange, class_1322.class_1323.field_6328),
                        class_9274.field_49217
                )
                .method_57487(
                        class_5134.field_51577,
                        new class_1322(class_2960.method_60654(MoreMineralBlocks.MOD_ID), sweepingDamage, class_1322.class_1323.field_6328),
                        class_9274.field_49217
                )
                .method_57486();
    }



    class_2960 nonFreeOffHandPenalty = class_2960.method_60654("non_free_offhand_penalty");

    @Override
    public void method_7888(class_1799 stack, class_3218 world, class_1297 entity, @Nullable class_1304 slot) {
        if (!world.method_8608()) {
            if (entity instanceof class_1657) {
                boolean inMainHand = ((class_1657) entity).method_6047() == stack;
                boolean offHandFree = ((class_1657) entity).method_6079().method_7960();

                class_1324 attackSpeed = ((class_1657) entity).method_5996(class_5134.field_23723);

                if (inMainHand && !offHandFree) {

                    if (attackSpeed != null && !attackSpeed.method_6196(nonFreeOffHandPenalty)) {
                        attackSpeed.method_26835(new class_1322(nonFreeOffHandPenalty, -0.6f, class_1322.class_1323.field_6328));
                    }
                }
                else {
                    if (attackSpeed != null && attackSpeed.method_6196(nonFreeOffHandPenalty)) {
                        attackSpeed.method_6200(nonFreeOffHandPenalty);
                    }
                }
            }
        }
        super.method_7888(stack, world, entity, slot);
    }
}