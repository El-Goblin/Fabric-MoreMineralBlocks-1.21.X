package net.elgoblin.moremineralblocks.item.custom;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.server.MinecraftServer;

public class MagicMirrorItem extends class_1792 {

    public MagicMirrorItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {

//        ItemStack itemStack = user.getStackInHand(hand);
//
//        if (!world.isClient) {
//            MinecraftServer server = world.getServer();
//
//            if (server != null) {
//
//                ServerWorld overworld = server.getWorld(World.OVERWORLD);
//                ServerPlayerEntity serverPlayer = (ServerPlayerEntity) user;
//
//                boolean hasSetSpawnPoint = serverPlayer.getSpawnPointPosition() != null;
//                Vec3d coordinates = Vec3d.of(hasSetSpawnPoint ? serverPlayer.getSpawnPointPosition() : (overworld != null) ? overworld.getSpawnPos() : new Vec3i(0, 64, 0));
//
//                RegistryKey<World> spawnDimension = serverPlayer.getSpawnPointDimension();
//                ServerWorld targetWorld = server.getWorld(spawnDimension);
//
//                Pair<ServerWorld, Vec3d> target = new Pair<>(targetWorld, coordinates);
//
//                if (hasSetSpawnPoint && targetWorld != null) {
//                    target = getRespawnPosition(targetWorld, serverPlayer.getSpawnPointPosition(), serverPlayer.isSpawnForced());
//                }
//
//
//                TeleportTarget teleportTarget = new TeleportTarget(target.getLeft(),
//                        target.getRight(),
//                        new Vec3d(0, 0, 0),
//                        user.getYaw(),
//                        user.getPitch(),
//                        TeleportTarget.NO_OP);
//                user.teleportTo(teleportTarget);
//            }
//        }
//        itemStack.decrementUnlessCreative(1, user);
        return super.method_7836(world, user, hand);
    }

//    public Pair<ServerWorld, Vec3d> getRespawnPosition(ServerWorld world, BlockPos writtenSpawnPosition, boolean spawnForced) {
//        BlockState blockState = world.getBlockState(writtenSpawnPosition);
//        Block block = blockState.getBlock();
//
//        if (block instanceof BedBlock && BedBlock.isBedWorking(world)) {
//            return new Pair<>(world, new Vec3d(writtenSpawnPosition.getX(), writtenSpawnPosition.getY(), writtenSpawnPosition.getZ()));
//        }
//        else if (block instanceof RespawnAnchorBlock && (spawnForced || (Integer)blockState.get(RespawnAnchorBlock.CHARGES) > 0) && RespawnAnchorBlock.isNether(world)) {
//            return new Pair<>(world, new Vec3d(writtenSpawnPosition.getX(), writtenSpawnPosition.getY(), writtenSpawnPosition.getZ()));
//        }
//        else {
//            MinecraftServer server = world.getServer();
//            ServerWorld overworld = server.getWorld(World.OVERWORLD);
//            BlockPos worldSpawnPos = world.getSpawnPos();
//            return new Pair<>(overworld, (overworld != null) ? new Vec3d(worldSpawnPos.getX(), worldSpawnPos.getY(), worldSpawnPos.getZ()) : new Vec3d(0,64,0));
//        }
//    }
}
