package net.elgoblin.moremineralblocks.item.custom;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.minecraft.class_10712;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_3965;
import net.minecraft.class_9334;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class InfiniteItem extends class_1826 {
    public InfiniteItem(class_1299<? extends class_1308> type, int primaryColor, int secondaryColor, class_1793 settings) {
        super(settings.method_72499(type));
    }
    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1268 hand = context.method_20287();
        class_1268 otherHand = hand.equals(class_1268.field_5808) ? class_1268.field_5810 : class_1268.field_5808;
        if (!hasBeenUsed(context.method_8041())) {
            class_1657 player = context.method_8036();
            if (player != null && !player.method_5998(otherHand).method_7960() && player.method_5998(otherHand).method_7909() != this) {
                class_1799 toStore = player.method_5998(otherHand).method_7972();
//                toStore.increment(1);
                player.method_5998(hand).method_57379(ModDataComponentTypes.CHOSEN_INFINITE_ITEM, toStore);
            }
        }
        else {
            class_1657 player = context.method_8036();
            if (player != null) {
                class_1799 chosenItem = player.method_5998(hand).method_58694(ModDataComponentTypes.CHOSEN_INFINITE_ITEM);
                if (chosenItem != null) {
                    class_1799 originalStack = new class_1799(this, 1);
                    class_1799 copy = chosenItem.method_7972();
                    copy.method_7939(2);
                    originalStack.method_57379(ModDataComponentTypes.CHOSEN_INFINITE_ITEM, copy);

                    class_1304 slot = hand.equals(class_1268.field_5808) ? class_1304.field_6173 : class_1304.field_6171;

                    class_3965 hitResult = new class_3965(context.method_17698(), context.method_8038(), context.method_8037(), false);
                    class_1838 newContext = new class_1838(context.method_8045(), context.method_8036(), context.method_20287(), chosenItem, hitResult);
                    class_1269 result = copy.method_7981(newContext);
                    player.method_5673(slot, originalStack);
                    return class_1269.field_5811;
                }
            }
        }
        return class_1269.field_5811;
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {

        if (!hasBeenUsed(user.method_5998(hand))) {
            class_1268 otherHand = hand.equals(class_1268.field_5808) ? class_1268.field_5810 : class_1268.field_5808;
            if (!user.method_5998(otherHand).method_7960() && user.method_5998(otherHand).method_7909() != this) {
                class_1799 toStore = user.method_5998(otherHand).method_7972();
//                toStore.increment(1);
                user.method_5998(hand).method_57379(ModDataComponentTypes.CHOSEN_INFINITE_ITEM, toStore);
            }
        }
        else {
            class_1799 chosenItem = user.method_5998(hand).method_58694(ModDataComponentTypes.CHOSEN_INFINITE_ITEM);
            if (chosenItem != null) {
                class_1799 originalStack = new class_1799(this, 1);
                originalStack.method_57379(ModDataComponentTypes.CHOSEN_INFINITE_ITEM, chosenItem);

                class_1269 result = chosenItem.method_7913(world, user, hand);
                return class_1269.field_5812;
            }
        }
        return super.method_7836(world, user, hand);
    }

    @Override
    public class_1269 method_7847(class_1799 stack, class_1657 user, class_1309 entity, class_1268 hand) {
        class_1268 otherHand = hand.equals(class_1268.field_5808) ? class_1268.field_5810 : class_1268.field_5808;
        if (!hasBeenUsed(user.method_5998(hand))) {
            if (!user.method_5998(otherHand).method_7960() && user.method_5998(otherHand).method_7909() != this) {
                class_1799 toStore = user.method_5998(otherHand).method_7972();
//                toStore.increment(1);
                user.method_5998(hand).method_57379(ModDataComponentTypes.CHOSEN_INFINITE_ITEM, toStore);
            }
        }
        else {
            class_1799 chosenItem = user.method_5998(hand).method_58694(ModDataComponentTypes.CHOSEN_INFINITE_ITEM);
            if (chosenItem != null) {
                class_1799 originalStack = new class_1799(this, 1);
                class_1799 copy = chosenItem.method_7972();
                copy.method_7939(2);
                originalStack.method_57379(ModDataComponentTypes.CHOSEN_INFINITE_ITEM, copy);

                class_1304 slot = hand.equals(class_1268.field_5808) ? class_1304.field_6173 : class_1304.field_6171;

                class_1269 result = copy.method_7920(user, entity, hand);
                user.method_5673(slot, originalStack);
                return class_1269.field_5811;
            }
        }
        return super.method_7847(stack, user, entity, hand);
    }

    private boolean hasBeenUsed(class_1799 stack) {
        return stack.method_58694(ModDataComponentTypes.CHOSEN_INFINITE_ITEM) != null;
    }

    @Override
    public Optional<class_1308> method_24793(class_1657 user, class_1308 entity, class_1299<? extends class_1308> entityType, class_3218 world, class_243 pos, class_1799 stack) {
        if (hasBeenUsed(stack)) {
            class_1799 chosen = stack.method_58694(ModDataComponentTypes.CHOSEN_INFINITE_ITEM);
            if (chosen != null && chosen.method_7909() instanceof class_1826) {
                if (!((class_1826) chosen.method_7909()).method_8018(chosen, entityType)) {
                    return Optional.empty();
                } else {
                    class_1308 mobEntity;
                    if (entity instanceof class_1296) {
                        mobEntity = ((class_1296)entity).method_5613(world, (class_1296)entity);
                    } else {
                        mobEntity = entityType.method_5883(world, class_3730.field_16466);
                    }

                    if (mobEntity == null) {
                        return Optional.empty();
                    } else {
                        mobEntity.method_7217(true);
                        if (!mobEntity.method_6109()) {
                            return Optional.empty();
                        } else {
                            mobEntity.method_5808(pos.method_10216(), pos.method_10214(), pos.method_10215(), 0.0F, 0.0F);
                            world.method_30771(mobEntity);
                            mobEntity.method_5665(stack.method_58694(class_9334.field_49631));
                            return Optional.of(mobEntity);
                        }
                    }
                }
            }
        }
        return Optional.empty();
    }

    @Override
    public void method_67187(class_1799 stack, class_9635 context, class_10712 displayComponent, Consumer<class_2561> textConsumer, class_1836 type) {
        if (stack.method_58694(ModDataComponentTypes.CHOSEN_INFINITE_ITEM) != null) {
            textConsumer.accept(class_2561.method_43470("Infinite stack of " + stack.method_58694(ModDataComponentTypes.CHOSEN_INFINITE_ITEM).method_7964().getString()));
        }
        else {
            textConsumer.accept(class_2561.method_43470("Empty infinite stack"));
        }

        super.method_67187(stack, context, displayComponent, textConsumer, type);
    }
}
