package net.elgoblin.moremineralblocks.item.custom;

import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import net.minecraft.class_1269;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1763;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2769;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_9281;
import net.minecraft.class_9334;

public class SurvivalDebugStickItem extends class_1763 {
    public SurvivalDebugStickItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1657 playerEntity = context.method_8036();
        class_1937 world = context.method_8045();
        if (!world.method_8608() && playerEntity != null) {
            class_2338 blockPos = context.method_8037();
            if (!this.method_7759(playerEntity, world.method_8320(blockPos), world, blockPos, true, context.method_8041())) {
                return class_1269.field_5814;
            }
        }

        return class_1269.field_5812;
    }

    private boolean method_7759(class_1657 player, class_2680 state, class_1936 world, class_2338 pos, boolean update, class_1799 stack) {
        class_6880<class_2248> registryEntry = state.method_41520();
            class_2689<class_2248, class_2680> stateManager = registryEntry.comp_349().method_9595();
            Collection<class_2769<?>> collection = stateManager.method_11659();
            if (collection.isEmpty()) {
                method_7762(player, class_2561.method_43469(this.method_7876() + ".empty", registryEntry.method_55840()));
                return false;
            } else {
                class_9281 debugStickStateComponent = stack.method_58694(class_9334.field_49608);
                if (debugStickStateComponent == null) {
                    return false;
                } else {
                    class_2769<?> property = (class_2769<?>)debugStickStateComponent.comp_2383().get(registryEntry);
                    if (update) {
                        if (property == null) {
                            property = (class_2769<?>)collection.iterator().next();
                        }

                        class_2680 blockState = method_7758(state, property, player.method_21823());
                        world.method_8652(pos, blockState, class_2248.field_31028 | class_2248.field_31031);
                        method_7762(player, class_2561.method_43469(this.method_7876() + ".update", property.method_11899(), method_7761(blockState, property)));
                    } else {
                        property = method_7760(collection, property, player.method_21823());
                        stack.method_57379(class_9334.field_49608, debugStickStateComponent.method_57466(registryEntry, property));
                        method_7762(player, class_2561.method_43469(this.method_7876() + ".select", property.method_11899(), method_7761(state, property)));
                    }

                    return true;
                }
        }
    }

    private static <T extends Comparable<T>> class_2680 method_7758(class_2680 state, class_2769<T> property, boolean inverse) {
        return state.method_11657(property, method_7760(property.method_11898(), state.method_11654(property), inverse));
    }

    private static <T> T method_7760(Iterable<T> elements, @Nullable T current, boolean inverse) {
        return inverse ? class_156.method_645(elements, current) : class_156.method_660(elements, current);
    }

    private static void method_7762(class_1657 player, class_2561 message) {
        ((class_3222)player).method_43502(message, true);
    }

    private static <T extends Comparable<T>> String method_7761(class_2680 state, class_2769<T> property) {
        return property.method_11901(state.method_11654(property));
    }
}
