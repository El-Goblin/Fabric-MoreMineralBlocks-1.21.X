package net.elgoblin.moremineralblocks.item.custom;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.minecraft.class_10710;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1755;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7444;
import net.minecraft.class_7924;
import net.minecraft.class_9334;
import net.minecraft.item.*;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

public class DimensionalPocketItem extends class_1792 {

    public DimensionalPocketItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 positionWhereUsed = context.method_8037();

        if (world.method_8608()) {
            return class_1269.field_5811;
        }

        class_1799 infiniteItemstack = context.method_8041();
        boolean safeModeOn = infiniteItemstack.method_58695(ModDataComponentTypes.SAFE_MODE, false);

        class_2680 blockState = world.method_8320(positionWhereUsed);
        class_2248 usedOn = blockState.method_26204();
        class_1263 inventory = null;

        if (usedOn instanceof class_2281 chest) {
            inventory = class_2281.method_17458(chest, blockState, world, positionWhereUsed, true);
        }
        if (inventory == null && world.method_8321(positionWhereUsed) instanceof class_1263 otherInventory) {
            inventory = otherInventory;
        }

        if (!safeModeOn && inventory != null) {
            infiniteItemstack.method_57379(ModDataComponentTypes.LINKED_CHEST, positionWhereUsed);
            infiniteItemstack.method_57379(ModDataComponentTypes.SERVERWORLD, world.method_27983().method_29177());
            infiniteItemstack.method_57379(ModDataComponentTypes.INTER_GROUP_POINTER, 0);
            infiniteItemstack.method_57379(ModDataComponentTypes.SAFE_MODE, false);

            int startingIndex = 0;
            if (!inventory.method_5442()){
                while (inventory.method_5438(startingIndex).method_7960()) {startingIndex++;}
            }

            ArrayList<Integer> intraGroupPointers = new ArrayList<>(Collections.nCopies(16, 0));
            intraGroupPointers.set(0,startingIndex);
            infiniteItemstack.method_57379(ModDataComponentTypes.INTRA_GROUP_POINTERS, intraGroupPointers);

            infiniteItemstack.method_57379(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(0)), IntStream.range(0,inventory.method_5439()).boxed().toList());
            for (int colorIndex = 1 ; colorIndex < 16 ; colorIndex++) {
                context.method_8041().method_57379(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(colorIndex)), Collections.emptyList());
            }

            if (context.method_8036() != null) {
                context.method_8036().method_7353(class_2561.method_30163("Linked successfully at position (x=" + positionWhereUsed.method_10263() + ", y=" + positionWhereUsed.method_10264() + ", z=" + positionWhereUsed.method_10260() +")"), false);
            }
            return class_1269.field_5812;
        }

        class_1657 user = context.method_8036();

        if (user == null) {
            return class_1269.field_5814;
        }

        class_2338 storagePos = infiniteItemstack.method_58694(ModDataComponentTypes.LINKED_CHEST);
        class_2960 dimension = infiniteItemstack.method_58694(ModDataComponentTypes.SERVERWORLD);
        Integer interGroupPointer = infiniteItemstack.method_58694(ModDataComponentTypes.INTER_GROUP_POINTER);
        List<Integer> intraGroupPointers = infiniteItemstack.method_58694(ModDataComponentTypes.INTRA_GROUP_POINTERS);

        if (storagePos == null || dimension == null || interGroupPointer == null || intraGroupPointers == null) {
            return class_1269.field_5814;
        }

        MinecraftServer server = world.method_8503();
        class_3218 targetWorld = server != null ? server.method_3847(class_5321.method_29179(class_7924.field_41223, dimension)) : null;

        if (targetWorld == null || !targetWorld.method_8477(storagePos)) {
            return class_1269.field_5814;
        }

        class_2680 storageBlockState = targetWorld.method_8320(storagePos);
        class_2248 depositBlock = storageBlockState.method_26204();
        class_1263 deposit = null;
        if (depositBlock instanceof class_2281 chestDeposit) {
            deposit = class_2281.method_17458(chestDeposit, storageBlockState, targetWorld, storagePos, true);
        }
        if (deposit == null && world.method_8321(storagePos) instanceof class_1263 otherInventory) {
            deposit = otherInventory;
        }
        if (deposit == null) {
            return class_1269.field_5814;
        }

        List<Integer> group = infiniteItemstack.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(interGroupPointer)));

        if (group == null) {
            return class_1269.field_5814;
        }
        if (group.isEmpty() || isOffBounds(intraGroupPointers.get(interGroupPointer), group.size())) {
            return class_1269.field_5814;
        }

        class_1799 usedStack = deposit.method_5438(group.get(intraGroupPointers.get(interGroupPointer)));
        if (isBannedItem(usedStack)) {
            return class_1269.field_5814;
        }
        if (!user.method_56992()
                && safeModeOn
                && (usedStack.method_7963() && (usedStack.method_7936() - usedStack.method_7919()) <= 1
                || !usedStack.method_7963() && usedStack.method_7947() <= 1)) {

            usedStack = findNonEmptyStack(usedStack, deposit, group);
        }
        if (usedStack.method_7960()) {
            return class_1269.field_5814;
        }

        class_3965 hitResult = new class_3965(context.method_17698(), context.method_8038(), context.method_8037(), false);
        class_1838 newContext = new class_1838(context.method_8045(), context.method_8036(), context.method_20287(), usedStack, hitResult);
        class_1269 result = usedStack.method_7981(newContext);
        if (result == class_1269.field_5811) {
            result = method_7836(world, user, class_1268.field_5808);
        }

        if (result.method_23665()) {
            class_2680 placedState = world.method_8320(context.method_8037().method_10093(context.method_8038()));

            if (placedState.method_26215()) {
                placedState = world.method_8320(context.method_8037());
            }

            if (!placedState.method_26215()) {
                class_2498 soundGroup = placedState.method_26231();
                world.method_8396(
                        null, // Player is null so EVERYONE (including the placing player) hears it
                        context.method_8037(),
                        soundGroup.method_10598(),
                        net.minecraft.class_3419.field_15245,
                        (soundGroup.method_10597() + 1.0F) / 2.0F,
                        soundGroup.method_10599() * 0.8F
                );
            }
            user.method_23667(class_1268.field_5808, true);
        }

        return result;
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {

        if (world.method_8608()) {
            return class_1269.field_5811;
        }

        class_1799 stack = user.method_5998(hand);
        class_1799 copy = stack.method_7972();

        class_2338 storagePos = stack.method_58694(ModDataComponentTypes.LINKED_CHEST);
        class_2960 dimension = stack.method_58694(ModDataComponentTypes.SERVERWORLD);
        Integer interGroupPointer = stack.method_58694(ModDataComponentTypes.INTER_GROUP_POINTER);
        List<Integer> intraGroupPointers = stack.method_58694(ModDataComponentTypes.INTRA_GROUP_POINTERS);
        boolean safeModeOn = stack.method_58695(ModDataComponentTypes.SAFE_MODE, false);

        if (storagePos == null || dimension == null || interGroupPointer == null || intraGroupPointers == null) {
            return class_1269.field_5814;
        }

        MinecraftServer server = world.method_8503();
        class_3218 targetWorld = server != null ? server.method_3847(class_5321.method_29179(class_7924.field_41223, dimension)) : null;

        if (targetWorld == null || !targetWorld.method_8477(storagePos)) {
            return class_1269.field_5814;
        }

        class_2680 storageBlockState = world.method_8320(storagePos);
        class_2248 depositBlock = storageBlockState.method_26204();
        class_1263 deposit = class_2281.method_17458((class_2281) depositBlock, storageBlockState, world, storagePos, true);

        if (deposit == null && world.method_8321(storagePos) instanceof class_1263 otherInventory) {
            deposit = otherInventory;
        }
        if (deposit == null) {
            return class_1269.field_5814;
        }

        List<Integer> group = stack.method_58694(ModDataComponentTypes.COLOR_INVENTORIES.get(class_1767.method_7791(interGroupPointer)));

        if (group == null) {
            return class_1269.field_5814;
        }
        if (group.isEmpty() || isOffBounds(intraGroupPointers.get(interGroupPointer), group.size())) {
            return class_1269.field_5814;
        }

        class_1799 usedStack = deposit.method_5438(group.get(intraGroupPointers.get(interGroupPointer)));

        if (isBannedItem(usedStack)) {
            return class_1269.field_5814;
        }
        if (!user.method_56992()
                && safeModeOn
                && (usedStack.method_7963() && (usedStack.method_7936() - usedStack.method_7919()) <= 1
                || !usedStack.method_7963() && usedStack.method_7947() <= 1)) {

            usedStack = findNonEmptyStack(usedStack, deposit, group);
        }
        if (usedStack.method_7960()) {
            return class_1269.field_5814;
        }

        user.method_5673(hand.method_73186(), usedStack);
        class_1269 result = usedStack.method_7913(world, user, hand);

        if (result.method_23665()) {
            if (usedStack.method_31574(net.minecraft.class_1802.field_39057)) {

                class_10710 instrumentComponent = usedStack.method_58694(class_9334.field_49612);
                Optional<class_6880<class_7444>> optional = instrumentComponent != null ? instrumentComponent.method_67211(user.method_56673()) : Optional.empty();

                if (optional.isPresent()) {
                    class_7444 instrument = (class_7444)((class_6880)optional.get()).comp_349();

                    class_3414 soundEvent = instrument.comp_772().comp_349();
                    float f = instrument.comp_774() / 16.0F;
                    world.method_43129(null, user, soundEvent, class_3419.field_15247, f, 1.0F);

                    user.method_7357().method_62835(usedStack, class_3532.method_15375(instrument.comp_773() * 20.0F));
                }
            }

            user.method_23667(hand, true);
        }

        user.method_5673(hand.method_73186(), copy);
        return class_1269.field_5814;
    }

    private boolean isOffBounds(int slot, int size) {
        return slot < 0 || slot >= size;
    }

    private boolean isBannedItem(class_1799 stack) {
        if (stack.method_31574(ModItems.DIMENSIONAL_POCKET)) {return true;}
        if (stack.method_31574(class_1802.field_8449)) {return true;}
        if (stack.method_31574(ModItems.FLASH)) {return true;}
        if (stack.method_7909() instanceof class_1755) {return true;}
        if (stack.method_31574(class_1802.field_27876)) {return true;}
        return stack.method_7960();
    }

    private class_1799 findNonEmptyStack(class_1799 usedStack, class_1263 deposit, List<Integer> group) {
        for (int i = 0 ; i < group.size() ; i++) {
            int depositPointer = Math.floorMod(group.get(i), deposit.method_5439());
            class_1799 currentStack = deposit.method_5438(depositPointer);
            if (currentStack.method_31574(usedStack.method_7909()) && currentStack.method_7947() > 1) {
                return currentStack;
            }
        }
        return class_1799.field_8037;
    }

    public record DimensionalPocketData(class_2338 storagePos,
                                        class_2960 dimension,
                                        class_3218 targetWorld,
                                        List<Integer> intraGroupPointers,
                                        Integer interGroupPointer,
                                        boolean safeMode) {

    }
}