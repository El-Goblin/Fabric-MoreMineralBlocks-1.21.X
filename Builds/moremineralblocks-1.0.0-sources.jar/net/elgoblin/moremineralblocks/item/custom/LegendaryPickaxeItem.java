package net.elgoblin.moremineralblocks.item.custom;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.minecraft.class_1263;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_9334;
import net.minecraft.class_9424;
import net.minecraft.class_9886;
import net.minecraft.item.*;

public class LegendaryPickaxeItem extends class_1792{
    public LegendaryPickaxeItem(class_1793 settings, class_9886 material, float attackDamage, float attackSpeed) {
        super(settings.method_66330(material, attackDamage, attackSpeed));
    }

    // Con esto hago que no pierda durabilidad al atacar cosas
    @Override
    public void method_59978(class_1799 stack, class_1309 target, class_1309 attacker) {
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_2338 position = context.method_8037();
        if (!context.method_8045().method_8608()) {
            if (context.method_8045().method_8321(position) instanceof class_1263 inventory) {
                context.method_8041().method_57379(ModDataComponentTypes.LINKED_CHEST, position);
                if (context.method_8036() != null) {
                    context.method_8036().method_7353(class_2561.method_30163(position.toString()), false);
                }
            }
        }
        if (context.method_8045().method_8321(position) instanceof class_1263 inventory) {
            return class_1269.field_5812;
        }
        return super.method_7884(context);
    }

    //    @Override
//    public ActionResult use(World world, PlayerEntity user, Hand hand) {
//        ItemStack itemStack = user.getStackInHand(hand);
//
//        ItemEnchantmentsComponent oldEnchantments = itemStack.get(DataComponentTypes.ENCHANTMENTS);
//        ItemEnchantmentsComponent oldStoredEnchantments = itemStack.get(DataComponentTypes.STORED_ENCHANTMENTS);
//
//        ItemEnchantmentsComponent newEnchantments = itemStack.get(ModDataComponentTypes.OTHER_ENCHANTMENTS);
//        ItemEnchantmentsComponent newStoredEnchantments = itemStack.get(ModDataComponentTypes.OTHER_STORED_ENCHANTMENTS);
//
//        itemStack.set(DataComponentTypes.ENCHANTMENTS, newEnchantments);
//        itemStack.set(DataComponentTypes.STORED_ENCHANTMENTS, newStoredEnchantments);
//
//        if (newEnchantments == null) {
//            itemStack.set(DataComponentTypes.STORED_ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT);
//            itemStack.set(DataComponentTypes.ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT);
//        }
//        itemStack.set(ModDataComponentTypes.OTHER_ENCHANTMENTS, oldEnchantments);
//        itemStack.set(ModDataComponentTypes.OTHER_STORED_ENCHANTMENTS, oldStoredEnchantments);
//
//        return ActionResult.PASS;
//    }



    // Al overridear esto y sacarle la parte de
    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        class_9424 toolComponent = stack.method_58694(class_9334.field_50077);
        return toolComponent != null;
    }
}
