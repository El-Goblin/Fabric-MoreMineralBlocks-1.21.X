package net.elgoblin.moremineralblocks.item.custom;

import net.elgoblin.moremineralblocks.entity.custom.ChaosOrbEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1823;
import net.minecraft.class_1826;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_5819;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;

public class ChaosOrbItem extends class_1823 {
    public ChaosOrbItem(class_1792.class_1793 settings) {
        super(settings);
    }

    private List<class_1799> spawnEggs = new ArrayList<>();
    private long spawnEggsReady = 0;
    private net.minecraft.class_5819 random = class_5819.method_43047();

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 itemStack = user.method_5998(hand);
        world.method_43128(
                null,
                user.method_23317(),
                user.method_23318(),
                user.method_23321(),
                class_3417.field_14873,
                class_3419.field_15254,
                0.5F,
                0.4F / (world.method_8409().method_43057() * 0.4F + 0.8F)
        );
        if (!world.method_8608()) {

            ChaosOrbEntity chaosOrbEntity = new ChaosOrbEntity(world, user, user.method_5998(hand));
            chaosOrbEntity.method_16940(itemStack);
            chaosOrbEntity.method_24919(user, user.method_36455(), user.method_36454(), 0.0F, 1.5F, 1.0F);
            world.method_8649(chaosOrbEntity);
        }

        user.method_7259(class_3468.field_15372.method_14956(this));
        itemStack.method_57008(1, user);
        return class_1269.field_5812;
    }

    @Override
    public class_1676 method_58648(class_1937 world, class_2374 pos, class_1799 stack, class_2350 direction) {
        ChaosOrbEntity chaosOrbEntity = new ChaosOrbEntity(world, pos.method_10216(), pos.method_10214(), pos.method_10215(), stack);
        chaosOrbEntity.method_16940(stack);
        return chaosOrbEntity;
    }

    public List<class_1799> getOrCreateSpawnEggList() {
        if (spawnEggsReady != 1) {
            spawnEggs = new ArrayList<>();

            for (class_1792 item : class_7923.field_41178) {
                if (item instanceof class_1826) {
                    class_1799 egg = item.method_7854();
                    egg.method_7939(16);
                    spawnEggs.add(egg);
                }
            }
            spawnEggsReady = 1;
        }
        return spawnEggs;
    }
}
