package net.elgoblin.moremineralblocks.item;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.block.ModBlocks;
import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.item.custom.*;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3902;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9281;
import net.minecraft.class_9334;
import net.minecraft.class_9886;
import net.minecraft.item.*;

import static net.minecraft.class_1802.field_8550;

public class ModItems {

    public static final class_1792 LEGENDARY_PICKAXE = registerItem(
            "legendary_pickaxe",
            new LegendaryPickaxeItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "legendary_pickaxe")))
                    .method_24359().method_7894(class_1814.field_8904).method_57349(class_9334.field_49630, class_3902.field_17274),
                    ModToolMaterials.LEGENDARY, 1.0F, -2.8F)
    );
    public static final class_1792 LEGENDARY_SHOVEL = registerItem(
            "legendary_shovel",
            new LegendaryShovelItem(ModToolMaterials.LEGENDARY, 1.0F, -2.8F, new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "legendary_shovel")))
                    .method_24359().method_7894(class_1814.field_8904).method_57349(class_9334.field_49630, class_3902.field_17274))
    );
    public static final class_1792 LEGENDARY_AXE = registerItem(
            "legendary_axe",
            new LegendaryAxeItem(ModToolMaterials.LEGENDARY, 5.0F, -2.6F, new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "legendary_axe")))
                    .method_24359().method_7894(class_1814.field_8904).method_57349(class_9334.field_49630, class_3902.field_17274))
    );
    public static final class_1792 LEGENDARY_HOE = registerItem(
            "legendary_hoe",
            new LegendaryHoeItem(ModToolMaterials.LEGENDARY, 1.0F, -2.8F, new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "legendary_hoe")))
                    .method_24359().method_7894(class_1814.field_8904).method_57349(class_9334.field_49630, class_3902.field_17274))
    );
    public static final class_1792 LEGENDARY_SWORD = registerItem(
            "legendary_sword",
            new LegendarySwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "legendary_sword")))
                    .method_24359().method_7894(class_1814.field_8904).method_57349(class_9334.field_49630, class_3902.field_17274),
                    ModToolMaterials.LEGENDARY, 9.0F, -2.0F)
    );
    public static final class_1792 LEGENDARY_ROCKET = registerItem("legendary_rocket", new LegendaryRocketItem(new class_1792.class_1793()
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "legendary_rocket")))
            .method_7889(1).method_24359().method_7894(class_1814.field_8904)));
//    public static final Item INFINITE_ITEMSTACK = registerItem("infinite_itemstack", new InfiniteItem(EntityType.ARMADILLO, 2, 3,
//            new Item.Settings()
//                    .registryKey(RegistryKey.of(RegistryKeys.ITEM, Identifier.of(MoreMineralBlocks.MOD_ID, "infinite_itemstack")))
//                    .maxDamage(0).maxCount(1).rarity(Rarity.EPIC)));
    public static final class_1792 SURVIVAL_DEBUG_STICK = registerItem("survival_debug_stick", new SurvivalDebugStickItem(new class_1792.class_1793()
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "survival_debug_stick")))
            .method_7889(1)
            .method_7894(class_1814.field_8904)
            .method_57349(class_9334.field_49608, class_9281.field_49310)
            .method_57349(class_9334.field_49641, true)));
    public static final class_1792 WOODEN_LONGSWORD = registerItem(
            "wooden_longsword",
            new LongSwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "wooden_longsword"))),
                    class_9886.field_52585, 5, -2.4F, 1, 2));
    public static final class_1792 STONE_LONGSWORD = registerItem(
            "stone_longsword",
            new LongSwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "stone_longsword"))),
                    class_9886.field_52586, 5, -2.4F, 1, 2));
    public static final class_1792 COPPER_LONGSWORD = registerItem(
            "copper_longsword",
            new LongSwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "copper_longsword"))),
                    class_9886.field_61350, 5, -2.4F, 1, 2));
    public static final class_1792 IRON_LONGSWORD = registerItem(
            "iron_longsword",
            new LongSwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "iron_longsword"))),
                    class_9886.field_52587, 5, -2.4F, 1, 2));
    public static final class_1792 GOLDEN_LONGSWORD = registerItem(
            "golden_longsword",
            new LongSwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "golden_longsword"))),
                    class_9886.field_52589, 5, -2.4F, 1, 2));
    public static final class_1792 DIAMOND_LONGSWORD = registerItem(
            "diamond_longsword",
            new LongSwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "diamond_longsword"))),
                    class_9886.field_52588, 5, -2.4F, 1, 2));
    public static final class_1792 NETHERITE_LONGSWORD = registerItem(
            "netherite_longsword",
            new LongSwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "netherite_longsword"))),
                    class_9886.field_52590, 5, -2.4F, 1, 2));
    public static final class_1792 FLAMEBERGE_LONGSWORD = registerItem(
            "flameberge_longsword",
            new LongSwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "flameberge_longsword"))),
                    class_9886.field_52587, 5, -2.4F, 1, 2));
    public static final class_1792 FIRE_DRAGONSWORD_LONGSWORD = registerItem(
            "fire_dragonsword_longsword",
            new LongSwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "fire_dragonsword_longsword"))),
                    class_9886.field_52590, 5, -2.4F, 1, 2));
    public static final class_1792 FIENDBLADE_LONGSWORD = registerItem(
            "fiendblade_longsword",
            new FiendbladeLongSwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "fiendblade_longsword"))),
                    class_9886.field_52590, 5, -2.4F, 1, 2));
    public static final class_1792 LEGENDARY_LONGSWORD = registerItem(
            "legendary_longsword",
            new LegendaryLongSwordItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "legendary_longsword")))
                    .method_24359().method_7894(class_1814.field_8904).method_57349(class_9334.field_49630, class_3902.field_17274),
            ModToolMaterials.LEGENDARY, 11.0F, -2.4F, 1, 5
    ));
    public static final class_1792 LEGENDARY_SPEAR = registerItem(
            "legendary_spear",
            new LegendarySpearItem(new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "legendary_spear")))
                    .method_24359().method_7894(class_1814.field_8904).method_57349(class_9334.field_49630, class_3902.field_17274),
                    ModToolMaterials.LEGENDARY,
                            1.25F,
                            1.5F,
                            0.25F,
                            2F,
                            6F,
                            5F,
                            5.1F,
                            7F,
                            4.6F
            ));



    public static final class_1792 REFLECTIVE_MIRROR = registerItem("reflective_mirror", new MirrorItem(new class_1792.class_1793()
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "reflective_mirror")))
            .method_7889(1).method_7894(class_1814.field_8907)));
    public static final class_1792 MAGIC_MIRROR = registerItem("magic_mirror", new MagicMirrorItem(new class_1792.class_1793()
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "magic_mirror")))
            .method_7889(64).method_7894(class_1814.field_8907)));
    public static final class_1792 CHAOS_MIRROR = registerItem("chaos_mirror", new ChaosMirrorItem(new class_1792.class_1793()
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "chaos_mirror")))
            .method_7889(64).method_7894(class_1814.field_8907)));


    public static final class_1792 CHAOS_ORB = registerItem("chaos_orb", new ChaosOrbItem(new class_1792.class_1793()
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "chaos_orb")))));
    public static final class_1792 FLASH = registerItem("flash", new FlashItem(new class_1792.class_1793().method_7889(1)
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "flash")))));

    public static final class_1792 LA_LECHONA = registerItem("la_lechona", new class_1792(new class_1792.class_1793()
            .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "la_lechona")))
            .method_7896(field_8550).method_57349(class_9334.field_53964, ModDataComponentTypes.LA_LECHONA).method_62834(field_8550).method_7889(1)));

//    public static final Item CHISEL = registerItem("chisel", new ChiselItem(new Item.Settings().maxDamage(32)));
public static final class_1792 DIMENSION_POCKET = registerItem("dimension_pocket", new InfiniteItemV2(new class_1792.class_1793()
        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "dimension_pocket")))
        .method_7889(1).method_7894(class_1814.field_8904).method_7895(0)));

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MoreMineralBlocks.MOD_ID, name), item);
    }

    public static void registerModItems() {
        MoreMineralBlocks.LOGGER.info("Registering Mod Items for " + MoreMineralBlocks.MOD_ID);

        // Esto lo pone en la tab de ingredients en creativo
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries -> {
            //entries.add(PINK_GARNET);
            //entries.add(RAW_PINK_GARNET);
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> {
            entries.method_45421(ModBlocks.PROTECTOR_BLOCK);
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(entries -> {
            entries.method_45421(WOODEN_LONGSWORD);
            entries.method_45421(STONE_LONGSWORD);
            entries.method_45421(GOLDEN_LONGSWORD);
            entries.method_45421(COPPER_LONGSWORD);
            entries.method_45421(IRON_LONGSWORD);
            entries.method_45421(DIAMOND_LONGSWORD);
            entries.method_45421(NETHERITE_LONGSWORD);
            entries.method_45421(FIENDBLADE_LONGSWORD);
            entries.method_45421(FLAMEBERGE_LONGSWORD);
            entries.method_45421(FIRE_DRAGONSWORD_LONGSWORD);
            entries.method_45421(LEGENDARY_SWORD);
            entries.method_45421(LEGENDARY_AXE);
            entries.method_45421(LEGENDARY_LONGSWORD);
            entries.method_45421(LEGENDARY_SPEAR);
            entries.method_45421(FLASH);
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries -> {
            entries.method_45421(CHAOS_ORB);
//            entries.add(INFINITE_ITEMSTACK);
        });

        // Esto lo pone en la tab de ingredients en creativo
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            entries.method_45421(LEGENDARY_PICKAXE);
            entries.method_45421(LEGENDARY_SHOVEL);
            entries.method_45421(LEGENDARY_AXE);
            entries.method_45421(LEGENDARY_HOE);
            entries.method_45421(LEGENDARY_ROCKET);
            entries.method_45421(SURVIVAL_DEBUG_STICK);
//            entries.add(INFINITE_ITEMSTACK);
            entries.method_45421(MAGIC_MIRROR);
            entries.method_45421(REFLECTIVE_MIRROR);
            entries.method_45421(CHAOS_MIRROR);
            entries.method_45421(FLASH);
            entries.method_45421(DIMENSION_POCKET);
//            entries.add(LA_LECHONA);
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41061).register(entries -> {
            entries.method_45421(LA_LECHONA);
        });
    }
}
