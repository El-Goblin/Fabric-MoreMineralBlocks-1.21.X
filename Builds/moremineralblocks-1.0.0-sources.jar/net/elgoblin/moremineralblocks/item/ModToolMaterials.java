package net.elgoblin.moremineralblocks.item;

import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.util.ModTags;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_9886;

public class ModToolMaterials {
    public static final class_9886 LEGENDARY = new class_9886(ModTags.Blocks.INCORRECT_FOR_LEGENDARY_TOOL, 3600000, 30.0F, 4.0F, 30, ModTags.Items.LEGENDARY_REPAIR);
    public static final class_9886 SURVIVAL_DEBUG_STICK = new class_9886(ModTags.Blocks.INCORRECT_FOR_SURVIVAL_DEBUG_STICK, 3600000, 3600000.0F, 0.0F, 30, ModTags.Items.LEGENDARY_REPAIR);

    public static void advanceEnchantments(class_1799 itemStack) {
        class_9304 oldEnchantments = itemStack.method_58694(class_9334.field_49633);
        class_9304 oldStoredEnchantments = itemStack.method_58694(class_9334.field_49643);
        class_2338 oldLinkedChest = itemStack.method_58694(ModDataComponentTypes.LINKED_CHEST);

        class_9304 newEnchantments = itemStack.method_58694(ModDataComponentTypes.OTHER_ENCHANTMENTS);
        class_9304 newStoredEnchantments = itemStack.method_58694(ModDataComponentTypes.OTHER_STORED_ENCHANTMENTS);
        class_2338 newLinkedChest = itemStack.method_58694(ModDataComponentTypes.OTHER_LINKED_CHEST);

        itemStack.method_57379(class_9334.field_49633, newEnchantments);
        itemStack.method_57379(class_9334.field_49643, newStoredEnchantments);
        itemStack.method_57379(ModDataComponentTypes.LINKED_CHEST, newLinkedChest);

//        String currentSet = itemStack.get(ModDataComponentTypes.ENCHANTMENT_SET);

//        if (currentSet == null) {
//            itemStack.set(ModDataComponentTypes.ENCHANTMENT_SET, "third");
//        }
//        else {
//            if (currentSet.equals("second")) {
//                itemStack.set(ModDataComponentTypes.ENCHANTMENT_SET, "first");
//            }
//            else {
//                itemStack.set(ModDataComponentTypes.ENCHANTMENT_SET, "second");
//            }
//        }

        if (newEnchantments == null) {
            itemStack.method_57379(class_9334.field_49643, class_9304.field_49385);
            itemStack.method_57379(class_9334.field_49633, class_9304.field_49385);
        }
        if (newLinkedChest == null) {
            itemStack.method_57379(ModDataComponentTypes.LINKED_CHEST, null);
        }
        itemStack.method_57379(ModDataComponentTypes.OTHER_ENCHANTMENTS, oldEnchantments);
        itemStack.method_57379(ModDataComponentTypes.OTHER_STORED_ENCHANTMENTS, oldStoredEnchantments);
        itemStack.method_57379(ModDataComponentTypes.OTHER_LINKED_CHEST, oldLinkedChest);
    }
}

