package net.elgoblin.moremineralblocks.item;

import net.elgoblin.moremineralblocks.MoreMineralBlocks;
import net.elgoblin.moremineralblocks.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class ModItemGroups {
//    public static final ItemGroup PINK_GARNET_ITEMS_GROUP = Registry.register(Registries.ITEM_GROUP, Identifier.of(MoreMineralBlocks.MOD_ID, "pink_garnet_items"),
//            FabricItemGroup.builder()
//                    .displayName(Text.translatable("itemgroup.moremineralblocks.pink_garnet_items"))
//                    .entries((displayContext, entries) -> {
//
//                        entries.add(ModItems.CHISEL);
//                    })
//                    .build());

    public static final class_1761 MOD_BLOCKS_GROUP = class_2378.method_10230(class_7923.field_44687, class_2960.method_60655(MoreMineralBlocks.MOD_ID, "mod_blocks"),
            FabricItemGroup.builder()
                    .method_47320(() -> new class_1799(ModBlocks.GOLD_STAIRS))
                    .method_47321(class_2561.method_43471("itemgroup.moremineralblocks.mod_blocks"))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(class_2246.field_10205);
                        entries.method_45421(ModBlocks.GOLD_STAIRS);
                        entries.method_45421(ModBlocks.GOLD_SLAB);
                        entries.method_45421(ModBlocks.GOLD_FENCE);
                        entries.method_45421(ModBlocks.GOLD_FENCE_GATE);
                        entries.method_45421(ModBlocks.GOLD_WALL);
                        entries.method_45421(ModBlocks.GOLD_DOOR);
                        entries.method_45421(ModBlocks.GOLD_TRAPDOOR);

                        entries.method_45421(ModBlocks.POLISHED_GOLD_BLOCK);
                        entries.method_45421(ModBlocks.POLISHED_GOLD_STAIRS);
                        entries.method_45421(ModBlocks.POLISHED_GOLD_SLAB);
                        entries.method_45421(ModBlocks.POLISHED_GOLD_WALL);
                        entries.method_45421(ModBlocks.POLISHED_GOLD_FENCE);
                        entries.method_45421(ModBlocks.POLISHED_GOLD_FENCE_GATE);

                        entries.method_45421(ModBlocks.GOLD_BRICKS);
                        entries.method_45421(ModBlocks.GOLD_BRICK_STAIRS);
                        entries.method_45421(ModBlocks.GOLD_BRICK_SLAB);
                        entries.method_45421(ModBlocks.GOLD_BRICK_WALL);
                        entries.method_45421(ModBlocks.GOLD_BRICK_FENCE);
                        entries.method_45421(ModBlocks.GOLD_BRICK_FENCE_GATE);

                        entries.method_45421(ModBlocks.CALCIFIED_GOLD_BLOCK);
                        entries.method_45421(ModBlocks.CALCIFIED_GOLD_STAIRS);
                        entries.method_45421(ModBlocks.CALCIFIED_GOLD_SLAB);
                        entries.method_45421(ModBlocks.CALCIFIED_GOLD_WALL);
                        entries.method_45421(ModBlocks.CALCIFIED_GOLD_FENCE);
                        entries.method_45421(ModBlocks.CALCIFIED_GOLD_FENCE_GATE);

                        entries.method_45421(class_2246.field_10201);
                        entries.method_45421(ModBlocks.DIAMOND_STAIRS);
                        entries.method_45421(ModBlocks.DIAMOND_SLAB);
                        entries.method_45421(ModBlocks.DIAMOND_FENCE);
                        entries.method_45421(ModBlocks.DIAMOND_FENCE_GATE);
                        entries.method_45421(ModBlocks.DIAMOND_WALL);
                        entries.method_45421(ModBlocks.DIAMOND_DOOR);
                        entries.method_45421(ModBlocks.DIAMOND_TRAPDOOR);

                        entries.method_45421(ModBlocks.POLISHED_DIAMOND_BLOCK);
                        entries.method_45421(ModBlocks.POLISHED_DIAMOND_STAIRS);
                        entries.method_45421(ModBlocks.POLISHED_DIAMOND_SLAB);
                        entries.method_45421(ModBlocks.POLISHED_DIAMOND_WALL);
                        entries.method_45421(ModBlocks.POLISHED_DIAMOND_FENCE);
                        entries.method_45421(ModBlocks.POLISHED_DIAMOND_FENCE_GATE);

                        entries.method_45421(ModBlocks.DIAMOND_BRICKS);
                        entries.method_45421(ModBlocks.DIAMOND_BRICK_STAIRS);
                        entries.method_45421(ModBlocks.DIAMOND_BRICK_SLAB);
                        entries.method_45421(ModBlocks.DIAMOND_BRICK_WALL);
                        entries.method_45421(ModBlocks.DIAMOND_BRICK_FENCE);
                        entries.method_45421(ModBlocks.DIAMOND_BRICK_FENCE_GATE);

                        entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_BLOCK);
                        entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_STAIRS);
                        entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_SLAB);
                        entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_WALL);
                        entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_FENCE);
                        entries.method_45421(ModBlocks.CALCIFIED_DIAMOND_FENCE_GATE);

                        entries.method_45421(class_2246.field_10085);
                        entries.method_45421(ModBlocks.IRON_STAIRS);
                        entries.method_45421(ModBlocks.IRON_SLAB);
                        entries.method_45421(ModBlocks.IRON_FENCE);
                        entries.method_45421(ModBlocks.IRON_FENCE_GATE);
                        entries.method_45421(ModBlocks.IRON_WALL);

                        entries.method_45421(ModBlocks.POLISHED_IRON_BLOCK);
                        entries.method_45421(ModBlocks.POLISHED_IRON_STAIRS);
                        entries.method_45421(ModBlocks.POLISHED_IRON_SLAB);
                        entries.method_45421(ModBlocks.POLISHED_IRON_WALL);
                        entries.method_45421(ModBlocks.POLISHED_IRON_FENCE);
                        entries.method_45421(ModBlocks.POLISHED_IRON_FENCE_GATE);

                        entries.method_45421(ModBlocks.IRON_BRICKS);
                        entries.method_45421(ModBlocks.IRON_BRICK_STAIRS);
                        entries.method_45421(ModBlocks.IRON_BRICK_SLAB);
                        entries.method_45421(ModBlocks.IRON_BRICK_WALL);
                        entries.method_45421(ModBlocks.IRON_BRICK_FENCE);
                        entries.method_45421(ModBlocks.IRON_BRICK_FENCE_GATE);

                        entries.method_45421(ModBlocks.CALCIFIED_IRON_BLOCK);
                        entries.method_45421(ModBlocks.CALCIFIED_IRON_STAIRS);
                        entries.method_45421(ModBlocks.CALCIFIED_IRON_SLAB);
                        entries.method_45421(ModBlocks.CALCIFIED_IRON_WALL);
                        entries.method_45421(ModBlocks.CALCIFIED_IRON_FENCE);
                        entries.method_45421(ModBlocks.CALCIFIED_IRON_FENCE_GATE);

                        entries.method_45421(class_2246.field_10234);
                        entries.method_45421(ModBlocks.EMERALD_STAIRS);
                        entries.method_45421(ModBlocks.EMERALD_SLAB);
                        entries.method_45421(ModBlocks.EMERALD_FENCE);
                        entries.method_45421(ModBlocks.EMERALD_FENCE_GATE);
                        entries.method_45421(ModBlocks.EMERALD_WALL);
                        entries.method_45421(ModBlocks.EMERALD_DOOR);
                        entries.method_45421(ModBlocks.EMERALD_TRAPDOOR);

                        entries.method_45421(ModBlocks.POLISHED_EMERALD_BLOCK);
                        entries.method_45421(ModBlocks.POLISHED_EMERALD_STAIRS);
                        entries.method_45421(ModBlocks.POLISHED_EMERALD_SLAB);
                        entries.method_45421(ModBlocks.POLISHED_EMERALD_WALL);
                        entries.method_45421(ModBlocks.POLISHED_EMERALD_FENCE);
                        entries.method_45421(ModBlocks.POLISHED_EMERALD_FENCE_GATE);

                        entries.method_45421(ModBlocks.EMERALD_BRICKS);
                        entries.method_45421(ModBlocks.EMERALD_BRICK_STAIRS);
                        entries.method_45421(ModBlocks.EMERALD_BRICK_SLAB);
                        entries.method_45421(ModBlocks.EMERALD_BRICK_WALL);
                        entries.method_45421(ModBlocks.EMERALD_BRICK_FENCE);
                        entries.method_45421(ModBlocks.EMERALD_BRICK_FENCE_GATE);

                        entries.method_45421(ModBlocks.CALCIFIED_EMERALD_BLOCK);
                        entries.method_45421(ModBlocks.CALCIFIED_EMERALD_STAIRS);
                        entries.method_45421(ModBlocks.CALCIFIED_EMERALD_SLAB);
                        entries.method_45421(ModBlocks.CALCIFIED_EMERALD_WALL);
                        entries.method_45421(ModBlocks.CALCIFIED_EMERALD_FENCE);
                        entries.method_45421(ModBlocks.CALCIFIED_EMERALD_FENCE_GATE);

                        entries.method_45421(ModBlocks.CHISELED_EMERALD_BLOCK);
                        entries.method_45421(ModBlocks.CHISELED_EMERALD_STAIRS);
                        entries.method_45421(ModBlocks.CHISELED_EMERALD_SLAB);
                        entries.method_45421(ModBlocks.CHISELED_EMERALD_WALL);
                        entries.method_45421(ModBlocks.CHISELED_EMERALD_FENCE);
                        entries.method_45421(ModBlocks.CHISELED_EMERALD_FENCE_GATE);

                        entries.method_45421(class_2246.field_10441);
                        entries.method_45421(ModBlocks.LAPIS_STAIRS);
                        entries.method_45421(ModBlocks.LAPIS_SLAB);
                        entries.method_45421(ModBlocks.LAPIS_FENCE);
                        entries.method_45421(ModBlocks.LAPIS_FENCE_GATE);
                        entries.method_45421(ModBlocks.LAPIS_WALL);
                        entries.method_45421(ModBlocks.LAPIS_DOOR);
                        entries.method_45421(ModBlocks.LAPIS_TRAPDOOR);

                        entries.method_45421(ModBlocks.POLISHED_LAPIS_BLOCK);
                        entries.method_45421(ModBlocks.POLISHED_LAPIS_STAIRS);
                        entries.method_45421(ModBlocks.POLISHED_LAPIS_SLAB);
                        entries.method_45421(ModBlocks.POLISHED_LAPIS_WALL);
                        entries.method_45421(ModBlocks.POLISHED_LAPIS_FENCE);
                        entries.method_45421(ModBlocks.POLISHED_LAPIS_FENCE_GATE);

                        entries.method_45421(ModBlocks.LAPIS_BRICKS);
                        entries.method_45421(ModBlocks.LAPIS_BRICK_STAIRS);
                        entries.method_45421(ModBlocks.LAPIS_BRICK_SLAB);
                        entries.method_45421(ModBlocks.LAPIS_BRICK_WALL);
                        entries.method_45421(ModBlocks.LAPIS_BRICK_FENCE);
                        entries.method_45421(ModBlocks.LAPIS_BRICK_FENCE_GATE);

                        entries.method_45421(ModBlocks.CALCIFIED_LAPIS_BLOCK);
                        entries.method_45421(ModBlocks.CALCIFIED_LAPIS_STAIRS);
                        entries.method_45421(ModBlocks.CALCIFIED_LAPIS_SLAB);
                        entries.method_45421(ModBlocks.CALCIFIED_LAPIS_WALL);
                        entries.method_45421(ModBlocks.CALCIFIED_LAPIS_FENCE);
                        entries.method_45421(ModBlocks.CALCIFIED_LAPIS_FENCE_GATE);

                        entries.method_45421(class_2246.field_10381);
                        entries.method_45421(ModBlocks.COAL_STAIRS);
                        entries.method_45421(ModBlocks.COAL_SLAB);
                        entries.method_45421(ModBlocks.COAL_FENCE);
                        entries.method_45421(ModBlocks.COAL_FENCE_GATE);
                        entries.method_45421(ModBlocks.COAL_WALL);
                        entries.method_45421(ModBlocks.COAL_DOOR);
                        entries.method_45421(ModBlocks.COAL_TRAPDOOR);

                        entries.method_45421(ModBlocks.POLISHED_COAL_BLOCK);
                        entries.method_45421(ModBlocks.POLISHED_COAL_STAIRS);
                        entries.method_45421(ModBlocks.POLISHED_COAL_SLAB);
                        entries.method_45421(ModBlocks.POLISHED_COAL_WALL);
                        entries.method_45421(ModBlocks.POLISHED_COAL_FENCE);
                        entries.method_45421(ModBlocks.POLISHED_COAL_FENCE_GATE);

                        entries.method_45421(ModBlocks.COAL_BRICKS);
                        entries.method_45421(ModBlocks.COAL_BRICK_STAIRS);
                        entries.method_45421(ModBlocks.COAL_BRICK_SLAB);
                        entries.method_45421(ModBlocks.COAL_BRICK_WALL);
                        entries.method_45421(ModBlocks.COAL_BRICK_FENCE);
                        entries.method_45421(ModBlocks.COAL_BRICK_FENCE_GATE);

                        entries.method_45421(ModBlocks.CALCIFIED_COAL_BLOCK);
                        entries.method_45421(ModBlocks.CALCIFIED_COAL_STAIRS);
                        entries.method_45421(ModBlocks.CALCIFIED_COAL_SLAB);
                        entries.method_45421(ModBlocks.CALCIFIED_COAL_WALL);
                        entries.method_45421(ModBlocks.CALCIFIED_COAL_FENCE);
                        entries.method_45421(ModBlocks.CALCIFIED_COAL_FENCE_GATE);

                        entries.method_45421(class_2246.field_22108);
                        entries.method_45421(ModBlocks.NETHERITE_STAIRS);
                        entries.method_45421(ModBlocks.NETHERITE_SLAB);
                        entries.method_45421(ModBlocks.NETHERITE_FENCE);
                        entries.method_45421(ModBlocks.NETHERITE_FENCE_GATE);
                        entries.method_45421(ModBlocks.NETHERITE_WALL);
                        entries.method_45421(ModBlocks.NETHERITE_DOOR);
                        entries.method_45421(ModBlocks.NETHERITE_TRAPDOOR);

                        entries.method_45421(ModBlocks.POLISHED_NETHERITE_BLOCK);
                        entries.method_45421(ModBlocks.POLISHED_NETHERITE_STAIRS);
                        entries.method_45421(ModBlocks.POLISHED_NETHERITE_SLAB);
                        entries.method_45421(ModBlocks.POLISHED_NETHERITE_WALL);
                        entries.method_45421(ModBlocks.POLISHED_NETHERITE_FENCE);
                        entries.method_45421(ModBlocks.POLISHED_NETHERITE_FENCE_GATE);

                        entries.method_45421(ModBlocks.NETHERITE_BRICKS);
                        entries.method_45421(ModBlocks.NETHERITE_BRICK_STAIRS);
                        entries.method_45421(ModBlocks.NETHERITE_BRICK_SLAB);
                        entries.method_45421(ModBlocks.NETHERITE_BRICK_WALL);
                        entries.method_45421(ModBlocks.NETHERITE_BRICK_FENCE);
                        entries.method_45421(ModBlocks.NETHERITE_BRICK_FENCE_GATE);

                        entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_BLOCK);
                        entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_STAIRS);
                        entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_SLAB);
                        entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_WALL);
                        entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_FENCE);
                        entries.method_45421(ModBlocks.CALCIFIED_NETHERITE_FENCE_GATE);

                        entries.method_45421(class_2246.field_27159);
                        entries.method_45421(ModBlocks.AMETHYST_STAIRS);
                        entries.method_45421(ModBlocks.AMETHYST_SLAB);
                        entries.method_45421(ModBlocks.AMETHYST_FENCE);
                        entries.method_45421(ModBlocks.AMETHYST_FENCE_GATE);
                        entries.method_45421(ModBlocks.AMETHYST_WALL);
                        entries.method_45421(ModBlocks.AMETHYST_DOOR);
                        entries.method_45421(ModBlocks.AMETHYST_TRAPDOOR);

                        entries.method_45421(ModBlocks.POLISHED_AMETHYST_BLOCK);
                        entries.method_45421(ModBlocks.POLISHED_AMETHYST_STAIRS);
                        entries.method_45421(ModBlocks.POLISHED_AMETHYST_SLAB);
                        entries.method_45421(ModBlocks.POLISHED_AMETHYST_WALL);
                        entries.method_45421(ModBlocks.POLISHED_AMETHYST_FENCE);
                        entries.method_45421(ModBlocks.POLISHED_AMETHYST_FENCE_GATE);

                        entries.method_45421(ModBlocks.AMETHYST_BRICKS);
                        entries.method_45421(ModBlocks.AMETHYST_BRICK_STAIRS);
                        entries.method_45421(ModBlocks.AMETHYST_BRICK_SLAB);
                        entries.method_45421(ModBlocks.AMETHYST_BRICK_WALL);
                        entries.method_45421(ModBlocks.AMETHYST_BRICK_FENCE);
                        entries.method_45421(ModBlocks.AMETHYST_BRICK_FENCE_GATE);

                        entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_BLOCK);
                        entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_STAIRS);
                        entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_SLAB);
                        entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_WALL);
                        entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_FENCE);
                        entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_FENCE_GATE);

                        entries.method_45421(class_2246.field_10002);
                        entries.method_45421(ModBlocks.REDSTONE_STAIRS);
                        entries.method_45421(ModBlocks.REDSTONE_SLAB);
                        entries.method_45421(ModBlocks.REDSTONE_FENCE);
                        entries.method_45421(ModBlocks.REDSTONE_FENCE_GATE);
                        entries.method_45421(ModBlocks.REDSTONE_WALL);
                        entries.method_45421(ModBlocks.REDSTONE_DOOR);
                        entries.method_45421(ModBlocks.REDSTONE_TRAPDOOR);

                        entries.method_45421(ModBlocks.POLISHED_REDSTONE_BLOCK);
                        entries.method_45421(ModBlocks.POLISHED_REDSTONE_STAIRS);
                        entries.method_45421(ModBlocks.POLISHED_REDSTONE_SLAB);
                        entries.method_45421(ModBlocks.POLISHED_REDSTONE_WALL);
                        entries.method_45421(ModBlocks.POLISHED_REDSTONE_FENCE);
                        entries.method_45421(ModBlocks.POLISHED_REDSTONE_FENCE_GATE);

                        entries.method_45421(ModBlocks.REDSTONE_BRICKS);
                        entries.method_45421(ModBlocks.REDSTONE_BRICK_STAIRS);
                        entries.method_45421(ModBlocks.REDSTONE_BRICK_SLAB);
                        entries.method_45421(ModBlocks.REDSTONE_BRICK_WALL);
                        entries.method_45421(ModBlocks.REDSTONE_BRICK_FENCE);
                        entries.method_45421(ModBlocks.REDSTONE_BRICK_FENCE_GATE);

                        entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_BLOCK);
                        entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_STAIRS);
                        entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_SLAB);
                        entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_WALL);
                        entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_FENCE);
                        entries.method_45421(ModBlocks.CALCIFIED_REDSTONE_FENCE_GATE);

                        entries.method_45421(class_2246.field_27114);
                        entries.method_45421(ModBlocks.CALCITE_STAIRS);
                        entries.method_45421(ModBlocks.CALCITE_SLAB);
                        entries.method_45421(ModBlocks.CALCITE_FENCE);
                        entries.method_45421(ModBlocks.CALCITE_FENCE_GATE);
                        entries.method_45421(ModBlocks.CALCITE_WALL);

                        entries.method_45421(class_2246.field_10540);
                        entries.method_45421(ModBlocks.OBSIDIAN_STAIRS);
                        entries.method_45421(ModBlocks.OBSIDIAN_SLAB);
                        entries.method_45421(ModBlocks.OBSIDIAN_FENCE);
                        entries.method_45421(ModBlocks.OBSIDIAN_FENCE_GATE);
                        entries.method_45421(ModBlocks.OBSIDIAN_WALL);

                        entries.method_45421(class_2246.field_9987);
                        entries.method_45421(ModBlocks.BEDROCK_STAIRS);
                        entries.method_45421(ModBlocks.BEDROCK_SLAB);
                        entries.method_45421(ModBlocks.BEDROCK_FENCE);
                        entries.method_45421(ModBlocks.BEDROCK_FENCE_GATE);
                        entries.method_45421(ModBlocks.BEDROCK_WALL);

                        entries.method_45421(class_2246.field_37568);
                        entries.method_45421(ModBlocks.SCULK_STAIRS);
                        entries.method_45421(ModBlocks.SCULK_SLAB);
                        entries.method_45421(ModBlocks.SCULK_FENCE);
                        entries.method_45421(ModBlocks.SCULK_FENCE_GATE);
                        entries.method_45421(ModBlocks.SCULK_WALL);

                        entries.method_45421(class_2246.field_10225);
                        entries.method_45421(ModBlocks.PACKED_ICE_STAIRS);
                        entries.method_45421(ModBlocks.PACKED_ICE_SLAB);
                        entries.method_45421(ModBlocks.PACKED_ICE_FENCE);
                        entries.method_45421(ModBlocks.PACKED_ICE_FENCE_GATE);
                        entries.method_45421(ModBlocks.PACKED_ICE_WALL);

                        entries.method_45421(class_2246.field_10384);
                        entries.method_45421(ModBlocks.BLUE_ICE_STAIRS);
                        entries.method_45421(ModBlocks.BLUE_ICE_SLAB);
                        entries.method_45421(ModBlocks.BLUE_ICE_FENCE);
                        entries.method_45421(ModBlocks.BLUE_ICE_FENCE_GATE);
                        entries.method_45421(ModBlocks.BLUE_ICE_WALL);

                        entries.method_45421(class_2246.field_10295);
                        entries.method_45421(ModBlocks.ICE_STAIRS);
                        entries.method_45421(ModBlocks.ICE_SLAB);
                        entries.method_45421(ModBlocks.ICE_FENCE);
                        entries.method_45421(ModBlocks.ICE_FENCE_GATE);
                        entries.method_45421(ModBlocks.ICE_WALL);

//                        entries.add(Blocks.DEEPSLATE_EMERALD_ORE);
//                        entries.add(ModBlocks.DEEPSLATE_EMERALD_ORE_STAIRS);
//                        entries.add(ModBlocks.DEEPSLATE_EMERALD_ORE_SLAB);
//                        entries.add(ModBlocks.DEEPSLATE_EMERALD_ORE_FENCE);
//                        entries.add(ModBlocks.DEEPSLATE_EMERALD_ORE_FENCE_GATE);
//                        entries.add(ModBlocks.DEEPSLATE_EMERALD_ORE_WALL);

                        entries.method_45421(ModBlocks.PRISMARINE_BRICK_WALL);
                        entries.method_45421(ModBlocks.DARK_PRISMARINE_WALL);
                    })
                    .method_47324());

    /*public static final ItemGroup PINK_GARNET_BLOCKS_GROUP = Registry.register(Registries.ITEM_GROUP, Identifier.of(MoreMineralBlocks.MOD_ID, "pink_garnet_blocks"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(ModBlocks.PINK_GARNET_BLOCK))
                    .displayName(Text.translatable("itemgroup.moremineralblocks.pink_garnet_blocks"))
                    .entries((displayContext, entries) -> {
                        //entries.add(ModBlocks.PINK_GARNET_BLOCK);
                        //entries.add(ModBlocks.RAW_PINK_GARNET_BLOCK);
                        //entries.add(ModBlocks.PINK_GARNET_ORE);
                        //entries.add(ModBlocks.PINK_GARNET_DEEPSLATE_ORE);
                        //entries.add(ModBlocks.MAGIC_BLOCK);

                        //entries.add(ModBlocks.PINK_GARNET_STAIRS);
                        //entries.add(ModBlocks.PINK_GARNET_SLAB);
                        //entries.add(ModBlocks.PINK_GARNET_BUTTON);
                        //entries.add(ModBlocks.PINK_GARNET_PRESSURE_PLATE);
                        //entries.add(ModBlocks.PINK_GARNET_FENCE);
                        //entries.add(ModBlocks.PINK_GARNET_FENCE_GATE);
                        //entries.add(ModBlocks.PINK_GARNET_WALL);

                        entries.add(ModBlocks.GOLD_STAIRS);
                        entries.add(ModBlocks.GOLD_SLAB);
                        entries.add(ModBlocks.GOLD_FENCE);
                        entries.add(ModBlocks.GOLD_FENCE_GATE);
                        entries.add(ModBlocks.GOLD_WALL);
                        entries.add(ModBlocks.GOLD_TEST);
                    })
                    .build());*/

    public static void registerItemGroups() {
        MoreMineralBlocks.LOGGER.info("Registering Item Groups for " + MoreMineralBlocks.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            entries.method_45421(ModItems.CHAOS_ORB);
        });
    }
}
