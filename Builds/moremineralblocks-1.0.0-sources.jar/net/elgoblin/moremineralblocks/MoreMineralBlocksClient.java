package net.elgoblin.moremineralblocks;

import net.elgoblin.moremineralblocks.block.ModBlocks;
//import net.elgoblin.moremineralblocks.client.InfiniteItemRenderer;
import net.elgoblin.moremineralblocks.entity.ModEntities;
//import net.elgoblin.moremineralblocks.entity.client.DevilmonModel;
//import net.elgoblin.moremineralblocks.entity.client.MantisModel;
//import net.elgoblin.moremineralblocks.entity.client.MantisRenderer;
//import net.elgoblin.moremineralblocks.entity.client.DevilmonRenderer;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.elgoblin.moremineralblocks.networking.LegendaryToolsSwitchEnchantmentPayload;
import net.elgoblin.moremineralblocks.particle.ModParticles;
import net.elgoblin.moremineralblocks.particle.custom.ChaosOrbFeedbackParticle;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_11515;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_953;
import org.lwjgl.glfw.GLFW;


public class MoreMineralBlocksClient implements ClientModInitializer {

//    private static KeyBinding switchEnchantments = KeyBindingHelper.registerKeyBinding(new KeyBinding(
//            "key.moremineralblocks.switch_enchantments",
//            InputUtil.Type.KEYSYM,
//            GLFW.GLFW_KEY_K,
//            "category.moremineralblocks.moremineralblocks"
//    ));

    //public TypedActionResult<ItemStack> advanceEnchantments(PlayerEntity user) {
        //return user.getMainHandStack().getItem().
    //};

    private static class_304 keyBinding;

    @Override
    public void onInitializeClient() {
        class_304.class_11900 LEGENDARY_TOOLS = class_304.class_11900.method_74698(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "legendary_tools"));
        class_304 switchEnchantments = KeyBindingHelper.registerKeyBinding(
                new class_304("key.moremineralblocks.switch_enchantments", class_3675.class_307.field_1668, GLFW.GLFW_KEY_K, LEGENDARY_TOOLS));

        BlockRenderLayerMap.putBlock(ModBlocks.GOLD_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.GOLD_TRAPDOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.AMETHYST_DOOR, class_11515.field_60926);
        BlockRenderLayerMap.putBlock(ModBlocks.AMETHYST_TRAPDOOR, class_11515.field_60926);
        BlockRenderLayerMap.putBlock(ModBlocks.DIAMOND_DOOR, class_11515.field_60926);
        BlockRenderLayerMap.putBlock(ModBlocks.DIAMOND_TRAPDOOR, class_11515.field_60926);
        BlockRenderLayerMap.putBlock(ModBlocks.EMERALD_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.EMERALD_TRAPDOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.NETHERITE_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.NETHERITE_TRAPDOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.LAPIS_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.LAPIS_TRAPDOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.COAL_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.COAL_TRAPDOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.REDSTONE_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.REDSTONE_TRAPDOOR, class_11515.field_60925);

        EntityRendererRegistry.register(ModEntities.CHAOS_ORB, class_953::new);


        ClientTickEvents.END_CLIENT_TICK.register(minecraftClient -> {
            while (switchEnchantments.method_1436()) {
//                if (minecraftClient.player != null) {
//                    minecraftClient.player.sendMessage(Text.of("asd"), false);
//                }
                ClientPlayNetworking.send(new LegendaryToolsSwitchEnchantmentPayload());
            }
        });

//        BuiltinItemRendererRegistry.INSTANCE.register(ModItems.INFINITE_ITEMSTACK, new InfiniteItemRenderer());

//        ClientTickEvents.END_CLIENT_TICK.register(client -> {
//
////            if (switchEnchantments.wasPressed()) {
////                    if (client.player.getMainHandStack().getItem() == ModItems.LEGENDARY_PICKAXE) {
////                        //advanceEnchantments(client.player);
////                    }
////            }
//        });

//        EntityModelLayerRegistry.registerModelLayer(MantisModel.MANTIS, MantisModel::getTexturedModelData);
//        EntityRendererRegistry.register(ModEntities.MANTIS, MantisRenderer::new);
//
//        EntityModelLayerRegistry.registerModelLayer(DevilmonModel.DEVILMON, DevilmonModel::getTexturedModelData);
//        EntityRendererRegistry.register(ModEntities.DEVILMON, DevilmonRenderer::new);

        ParticleFactoryRegistry.getInstance().register(ModParticles.PICKAXE_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_HASTE_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_JUMP_BOOST_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_REGENERATION_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_RESISTANCE_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_SPEED_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_STRENGTH_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_COUNTER_BLINK_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_BLINKING_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_FRAGILE_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
    }
}
