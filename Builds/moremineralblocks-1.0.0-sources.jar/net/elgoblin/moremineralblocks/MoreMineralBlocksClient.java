package net.elgoblin.moremineralblocks;

import net.elgoblin.moremineralblocks.block.ModBlocks;
//import net.elgoblin.moremineralblocks.client.InfiniteItemRenderer;
import net.elgoblin.moremineralblocks.client.ClientEvents;
import net.elgoblin.moremineralblocks.client.InfiniteItemClientCache;
import net.elgoblin.moremineralblocks.client.InfiniteItemstackOverlay;
import net.elgoblin.moremineralblocks.component.ModDataComponentTypes;
import net.elgoblin.moremineralblocks.entity.ModEntities;
//import net.elgoblin.moremineralblocks.entity.client.DevilmonModel;
//import net.elgoblin.moremineralblocks.entity.client.MantisModel;
//import net.elgoblin.moremineralblocks.entity.client.MantisRenderer;
//import net.elgoblin.moremineralblocks.entity.client.DevilmonRenderer;
import net.elgoblin.moremineralblocks.item.ModItems;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_11515;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_953;
import net.elgoblin.moremineralblocks.particle.ModParticles;
import net.elgoblin.moremineralblocks.particle.custom.ChaosOrbFeedbackParticle;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import org.lwjgl.glfw.GLFW;


public class MoreMineralBlocksClient implements ClientModInitializer {

    public static final class_304.class_11900 LEGENDARY_TOOLS = class_304.class_11900.method_74698(class_2960.method_60655(MoreMineralBlocks.MOD_ID, "legendary_tools"));
    public static class_304 switchEnchantments_toggleSafeMode;
    public static class_304 intraGroupScroll;
    public static class_304 interGroupScroll;

    @Override
    public void onInitializeClient() {
        switchEnchantments_toggleSafeMode = KeyBindingHelper.registerKeyBinding(
                new class_304("key.moremineralblocks.switch_enchantments_toggle_safe_mode", class_3675.class_307.field_1668, GLFW.GLFW_KEY_K, LEGENDARY_TOOLS));
        intraGroupScroll = KeyBindingHelper.registerKeyBinding(
                new class_304("key.moremineralblocks.intra_group_scroll", class_3675.class_307.field_1668, GLFW.GLFW_KEY_TAB, LEGENDARY_TOOLS));
        interGroupScroll = KeyBindingHelper.registerKeyBinding(
                new class_304("key.moremineralblocks.inter_group_scroll", class_3675.class_307.field_1668, GLFW.GLFW_KEY_GRAVE_ACCENT, LEGENDARY_TOOLS));

        BlockRenderLayerMap.putBlock(ModBlocks.GOLD_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.GOLD_TRAPDOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.AMETHYST_DOOR, class_11515.field_60926);
        BlockRenderLayerMap.putBlock(ModBlocks.AMETHYST_TRAPDOOR, class_11515.field_60926);
        BlockRenderLayerMap.putBlock(ModBlocks.DIAMOND_DOOR, class_11515.field_60926);
        BlockRenderLayerMap.putBlock(ModBlocks.DIAMOND_TRAPDOOR, class_11515.field_60926);
        BlockRenderLayerMap.putBlock(ModBlocks.EMERALD_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.EMERALD_TRAPDOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.NETHERITE_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.NETHERITE_TRAPDOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.LAPIS_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.LAPIS_TRAPDOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.COAL_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.COAL_TRAPDOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.REDSTONE_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.REDSTONE_TRAPDOOR, class_11515.field_60925);

        EntityRendererRegistry.register(ModEntities.CHAOS_ORB, class_953::new);
        InfiniteItemstackOverlay.register();
        ClientEvents.register();

//        BuiltinItemRendererRegistry.INSTANCE.register(ModItems.INFINITE_ITEMSTACK, new InfiniteItemRenderer());

//        EntityModelLayerRegistry.registerModelLayer(MantisModel.MANTIS, MantisModel::getTexturedModelData);
//        EntityRendererRegistry.register(ModEntities.MANTIS, MantisRenderer::new);
//
//        EntityModelLayerRegistry.registerModelLayer(DevilmonModel.DEVILMON, DevilmonModel::getTexturedModelData);
//        EntityRendererRegistry.register(ModEntities.DEVILMON, DevilmonRenderer::new);

        ParticleFactoryRegistry.getInstance().register(ModParticles.PICKAXE_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_HASTE_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_JUMP_BOOST_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_REGENERATION_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_RESISTANCE_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_SPEED_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_STRENGTH_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_COUNTER_BLINK_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_BLINKING_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.CHAOS_ORB_FRAGILE_PARTICLE, ChaosOrbFeedbackParticle.Factory::new);

        HudRenderCallback.EVENT.register(((drawContext, renderTickCounter) -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null) {return;}

            class_1799 mainHoldedStack = client.field_1724.method_6047();
            class_1799 offHoldedStack = client.field_1724.method_6079();

            if (mainHoldedStack.method_31574(ModItems.DIMENSIONAL_POCKET)) {
                renderSelectedStack(drawContext, client, client.field_1724.method_6047());
            }
            else if (offHoldedStack.method_31574(ModItems.DIMENSIONAL_POCKET)) {
                renderSelectedStack(drawContext, client, client.field_1724.method_6079());
            }
        }));
    }

    private void renderSelectedStack(class_332 drawContext, class_310 client, class_1799 stack) {
        class_2338 storagePos = stack.method_58694(ModDataComponentTypes.LINKED_CHEST);
        class_2960 dimension = stack.method_58694(ModDataComponentTypes.SERVERWORLD);

        if (storagePos == null || dimension == null) {
            return;
        }
        class_1799 selectedStack = InfiniteItemClientCache.mainStack;
        int stackCount = InfiniteItemClientCache.mainCount;

        if (!selectedStack.method_7960() && client.field_1724 != null) {
            int width = client.method_22683().method_4486();
            int height = client.method_22683().method_4502();

            int hotbarLeftX = width / 2 - 90;
            int selectedSlot = client.field_1724.method_31548().method_67532();
            int x = hotbarLeftX + (selectedSlot * 20) + 2;
            int y = height - 22 + 3;

            if (client.field_1724.method_6079() == stack) {
                x = (width / 2) - 90 - 29 + 2;
            }


            drawContext.method_51427(selectedStack, x, y);
            drawContext.method_51432(
                    client.field_1772,
                    selectedStack,
                    x,
                    y,
                    String.valueOf(stackCount));

        }
    }
}
