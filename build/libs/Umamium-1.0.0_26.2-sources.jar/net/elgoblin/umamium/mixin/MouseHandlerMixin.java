package net.elgoblin.umamium.mixin;

import net.elgoblin.umamium.client.ClientEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public class MouseHandlerMixin {

    @Shadow
    @Final
    private Minecraft minecraft;

    @Inject(
            method = "onScroll",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        double delta = (this.minecraft.options.discreteMouseScroll().get() ? Math.signum(vertical) : vertical)
                * this.minecraft.options.mouseWheelSensitivity().get();

        if (ClientEvents.onScroll(delta)) {
            ci.cancel();
        }
    }
}