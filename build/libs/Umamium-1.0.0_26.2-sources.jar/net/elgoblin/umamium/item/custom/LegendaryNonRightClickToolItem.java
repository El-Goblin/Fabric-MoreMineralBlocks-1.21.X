package net.elgoblin.umamium.item.custom;

import net.elgoblin.umamium.util.LegendaryItemUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.entity.BlockEntity;

import java.util.function.Consumer;

public class LegendaryNonRightClickToolItem extends Item {
    public LegendaryNonRightClickToolItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        BlockPos position = context.getClickedPos();

        if (!context.getLevel().isClientSide()) {
            BlockEntity blockEntity = context.getLevel().getBlockEntity(position);
            boolean linked = LegendaryItemUtils.linkOrUnlinkContainer(context, position, blockEntity);
            return linked ? InteractionResult.SUCCESS : InteractionResult.FAIL;
        }

        if (context.getLevel().getBlockEntity(position) instanceof Container inventory) {
            return InteractionResult.PASS;
        }
        return super.useOn(context);
    }

    @Override
    public void appendHoverText(ItemStack itemStack, TooltipContext context, TooltipDisplay display, Consumer<Component> builder, TooltipFlag tooltipFlag) {
        LegendaryItemUtils.appendTooltip(itemStack, builder);
        super.appendHoverText(itemStack, context, display, builder, tooltipFlag);
    }
}
